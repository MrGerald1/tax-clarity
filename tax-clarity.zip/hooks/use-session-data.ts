"use client"

import { useEffect, useState } from "react"
import { getSessionData, saveCalculationToSession } from "@/lib/session-manager"
import type { SessionData } from "@/lib/session-manager"

export interface SessionState {
  isLoading: boolean
  data: SessionData | null
  hasData: boolean
  module1Data: any
  module2Data: any
  module3Data: any
}

/**
 * Hook to manage session data across pages
 * Handles loading, caching, and updates to session state
 */
export function useSessionData(): SessionState {
  const [sessionState, setSessionState] = useState<SessionState>({
    isLoading: true,
    data: null,
    hasData: false,
    module1Data: null,
    module2Data: null,
    module3Data: null,
  })

  useEffect(() => {
    if (typeof window === "undefined") return

    const data = getSessionData()
    setSessionState({
      isLoading: false,
      data,
      hasData: !!data,
      module1Data: data?.module1?.input || null,
      module2Data: data?.module2?.input || null,
      module3Data: data?.module3?.input || null,
    })
  }, [])

  return sessionState
}

/**
 * Hook to save data to session
 */
export function useSaveToSession() {
  return (moduleId: number, inputData: any, resultData: any) => {
    saveCalculationToSession(moduleId, inputData, resultData)
  }
}
