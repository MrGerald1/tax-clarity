"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { Navbar } from "@/components/shared/navbar"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { calculateOldSystemTax } from "@/lib/calculations/tax-old"
import { calculateNewSystemTax } from "@/lib/calculations/tax-new"
import { determineModule2Outcome } from "@/lib/state-machines/module2-outcomes"
import { saveCalculationToSession, getSessionData } from "@/lib/session-manager"
import { ArrowRight, ArrowLeft, Zap } from "lucide-react"

interface CompareTaxInput {
  incomeType: "salary" | "freelance" | "business" | "multiple"
  incomeAmount: number
  incomeEntryMethod: "exact" | "band"
  incomeBand?: string
  pensionContribution: number
  rentAmount: number
  housingStatus: "homeowner" | "renting" | "other"
  businessExpenses: number
  employerFlexibility: "NONE" | "PARTIAL" | "FULL"
  nsfContribution: number
  nhisContribution: number
  lifeAssurancePremium: number
}

type Step = "income-type" | "income-amount" | "deductions" | "details" | "result"

const INCOME_BANDS = [
  { min: 800000, max: 1500000, label: "₦800k - ₦1.5M" },
  { min: 1500000, max: 2500000, label: "₦1.5M - ₦2.5M" },
  { min: 2500000, max: 5000000, label: "₦2.5M - ₦5M" },
  { min: 5000000, max: 10000000, label: "₦5M - ₦10M" },
  { min: 10000000, max: Number.POSITIVE_INFINITY, label: "₦10M+" },
]

export default function CompareTax() {
  const router = useRouter()
  const [step, setStep] = useState<Step>("income-type")
  const [input, setInput] = useState<Partial<CompareTaxInput>>({
    incomeType: "salary",
    incomeEntryMethod: "exact",
    housingStatus: "other",
    employerFlexibility: "NONE",
  })
  const [hasSessionData, setHasSessionData] = useState(false)

  useEffect(() => {
    const sessionData = getSessionData()
    if (sessionData && sessionData.module1) {
      const module1Result = sessionData.module1
      setInput((prev) => ({
        ...prev,
        incomeType: module1Result.input.incomeType,
        incomeAmount: module1Result.input.incomeAmount || 2000000,
      }))
      setHasSessionData(true)
      setStep("deductions")
    }
  }, [])

  const steps: Step[] = hasSessionData
    ? ["deductions", "details", "result"]
    : ["income-type", "income-amount", "deductions", "details", "result"]

  const currentStepIndex = steps.indexOf(step)
  const progress = ((currentStepIndex + 1) / steps.length) * 100

  const handleInputChange = (key: keyof CompareTaxInput, value: any) => {
    setInput((prev) => ({ ...prev, [key]: value }))
  }

  const canProceed = (): boolean => {
    switch (step) {
      case "income-type":
        return !!input.incomeType
      case "income-amount":
        return input.incomeEntryMethod === "exact" ? (input.incomeAmount || 0) > 0 : !!input.incomeBand
      case "deductions":
        return true
      case "details":
        return true
      case "result":
        return false
      default:
        return false
    }
  }

  const handleSubmit = () => {
    if (!input.incomeAmount || input.incomeAmount === 0) return

    let finalIncome = input.incomeAmount || 0
    if (input.incomeEntryMethod === "band" && input.incomeBand) {
      const band = INCOME_BANDS.find((b) => b.label === input.incomeBand)
      if (band) {
        finalIncome = (band.min + band.max) / 2
      }
    }

    const oldTaxResult = calculateOldSystemTax({
      grossAnnualIncome: finalIncome,
      pensionContribution: input.pensionContribution || 0,
      rentRelief: input.rentAmount || 0,
      otherDeductions: input.businessExpenses || 0,
      nsfContribution: input.nsfContribution || 0,
      nhisContribution: input.nhisContribution || 0,
      lifeAssurancePremium: input.lifeAssurancePremium || 0,
    })

    const newTaxResult = calculateNewSystemTax({
      grossAnnualIncome: finalIncome,
      incomeType: input.incomeType || "salary",
      pensionContribution: input.pensionContribution || 0,
      rentAmount: input.rentAmount || 0,
      businessExpenses: input.businessExpenses || 0,
      housingStatus: input.housingStatus || "other",
      nsfContribution: input.nsfContribution || 0,
      nhisContribution: input.nhisContribution || 0,
      lifeAssurancePremium: input.lifeAssurancePremium || 0,
    })

    const outcome = determineModule2Outcome({
      oldTax: oldTaxResult.tax,
      newTax: newTaxResult.tax,
      income: finalIncome,
      incomeType: input.incomeType || "salary",
      employerFlexibility: input.employerFlexibility,
      hasDeductionOpportunities: (input.businessExpenses || 0) > 0 || (input.pensionContribution || 0) === 0,
    })

    const calculationId = saveCalculationToSession(
      2,
      { ...input, finalIncome },
      {
        oldTax: oldTaxResult,
        newTax: newTaxResult,
        outcome,
      },
    )

    router.push(`/compare-tax/result/${calculationId}`)
  }

  const handleNext = () => {
    if (step === "details") {
      handleSubmit()
      return
    }
    const nextIndex = currentStepIndex + 1
    if (nextIndex < steps.length) {
      setStep(steps[nextIndex])
    }
  }

  const handleBack = () => {
    if (currentStepIndex > 0) {
      setStep(steps[currentStepIndex - 1])
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-background to-muted/20">
      <Navbar />

      <div className="container max-w-2xl mx-auto px-4 py-8 sm:py-16">
        <div className="mb-8">
          <h1 className="text-3xl font-bold mb-2">Am I Better or Worse Off?</h1>
          <p className="text-muted-foreground">
            Compare your tax under the old vs new system. {steps.length} quick steps.
          </p>
        </div>

        <div className="mb-8">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm font-medium text-muted-foreground">
              Step {currentStepIndex + 1} of {steps.length}
            </span>
            <span className="text-sm font-medium text-primary">{Math.round(progress)}%</span>
          </div>
          <Progress value={progress} className="h-2" />
        </div>

        <Card className="p-6 sm:p-8 mb-8 bg-card">
          {step === "income-type" && (
            <div>
              <h2 className="text-xl sm:text-2xl font-semibold mb-2">What's your primary income type?</h2>
              <p className="text-muted-foreground text-sm mb-6">
                Select your primary income source. Choose "Multiple Roles" if you combine employment, freelance work, or
                business income.
              </p>
              <div className="space-y-2">
                {(["salary", "freelance", "business", "multiple"] as const).map((type) => (
                  <Button
                    key={type}
                    variant={input.incomeType === type ? "default" : "outline"}
                    onClick={() => handleInputChange("incomeType", type)}
                    className="w-full justify-start h-auto py-3 px-4 text-left"
                  >
                    <div>
                      <div className="font-medium capitalize">
                        {type === "salary"
                          ? "Salary from Employer"
                          : type === "freelance"
                            ? "Freelance / Self-Employed"
                            : type === "business"
                              ? "Business Owner"
                              : "Multiple Roles"}
                      </div>
                      <div className="text-xs text-muted-foreground mt-1">
                        {type === "salary"
                          ? "Primary income from employment"
                          : type === "freelance"
                            ? "Income from contract or self-employed work"
                            : type === "business"
                              ? "Revenue from business operations"
                              : "Combination of employed, self-employed, or business income"}
                      </div>
                    </div>
                  </Button>
                ))}
              </div>
            </div>
          )}

          {step === "income-amount" && (
            <div>
              <h2 className="text-xl sm:text-2xl font-semibold mb-2">What's your annual GROSS income?</h2>
              <p className="text-muted-foreground text-sm mb-6">
                Enter your total income BEFORE any deductions. This is the amount before taxes, pension, or other
                deductions.
              </p>
              <div className="space-y-4 mb-6">
                <div className="flex gap-2 mb-4">
                  <Button
                    variant={input.incomeEntryMethod === "exact" ? "default" : "outline"}
                    onClick={() => handleInputChange("incomeEntryMethod", "exact")}
                    className="flex-1"
                  >
                    Exact Amount
                  </Button>
                  <Button
                    variant={input.incomeEntryMethod === "band" ? "default" : "outline"}
                    onClick={() => handleInputChange("incomeEntryMethod", "band")}
                    className="flex-1"
                  >
                    Select Range
                  </Button>
                </div>

                {input.incomeEntryMethod === "exact" && (
                  <div className="flex items-center gap-2">
                    <span className="text-lg font-medium text-muted-foreground">₦</span>
                    <input
                      type="number"
                      value={input.incomeAmount || ""}
                      onChange={(e) => handleInputChange("incomeAmount", Number.parseInt(e.target.value) || 0)}
                      placeholder="2,000,000"
                      className="flex-1 px-4 py-3 border border-border rounded-lg bg-background text-foreground text-lg"
                    />
                  </div>
                )}

                {input.incomeEntryMethod === "band" && (
                  <div className="space-y-2">
                    {INCOME_BANDS.map((band) => (
                      <Button
                        key={band.label}
                        variant={input.incomeBand === band.label ? "default" : "outline"}
                        onClick={() => {
                          handleInputChange("incomeBand", band.label)
                          handleInputChange("incomeAmount", (band.min + band.max) / 2)
                        }}
                        className="w-full justify-start h-auto py-3 px-4"
                      >
                        <span className="font-medium">{band.label}</span>
                      </Button>
                    ))}
                  </div>
                )}
              </div>
            </div>
          )}

          {step === "deductions" && (
            <div>
              <h2 className="text-xl sm:text-2xl font-semibold mb-2">Any tax deductions?</h2>
              <p className="text-muted-foreground text-sm mb-6">Optional. Leave blank if none apply.</p>
              <div className="space-y-4">
                <div>
                  <label className="text-sm font-medium block mb-2">Housing Status</label>
                  <div className="grid grid-cols-3 gap-2">
                    {(["homeowner", "renting", "other"] as const).map((status) => (
                      <Button
                        key={status}
                        variant={input.housingStatus === status ? "default" : "outline"}
                        onClick={() => handleInputChange("housingStatus", status)}
                        className="h-auto py-2 text-xs sm:text-sm"
                      >
                        <span className="capitalize">
                          {status === "homeowner" ? "Own" : status === "renting" ? "Rent" : "Other"}
                        </span>
                      </Button>
                    ))}
                  </div>
                </div>

                {input.housingStatus === "renting" && (
                  <div>
                    <label className="text-sm font-medium block mb-2">Annual Rent</label>
                    <div className="flex items-center gap-2">
                      <span className="text-muted-foreground">₦</span>
                      <input
                        type="number"
                        value={input.rentAmount || ""}
                        onChange={(e) => handleInputChange("rentAmount", Number.parseInt(e.target.value) || 0)}
                        placeholder="1,200,000"
                        className="flex-1 px-4 py-2 border border-border rounded-lg bg-background text-foreground"
                      />
                    </div>
                    <p className="text-xs text-muted-foreground mt-1">Relief: min(20% of rent, ₦500k)</p>
                  </div>
                )}

                <div>
                  <label className="text-sm font-medium block mb-2">Pension Contribution (NPS)</label>
                  <div className="flex items-center gap-2">
                    <span className="text-muted-foreground">₦</span>
                    <input
                      type="number"
                      value={input.pensionContribution || ""}
                      onChange={(e) => handleInputChange("pensionContribution", Number.parseInt(e.target.value) || 0)}
                      placeholder="120,000"
                      className="flex-1 px-4 py-2 border border-border rounded-lg bg-background text-foreground"
                    />
                  </div>
                  <p className="text-xs text-muted-foreground mt-1">Max 8% of income</p>
                </div>

                <div>
                  <label className="text-sm font-medium block mb-2">National Housing Fund (NHF)</label>
                  <div className="flex items-center gap-2">
                    <span className="text-muted-foreground">₦</span>
                    <input
                      type="number"
                      value={input.nsfContribution || ""}
                      onChange={(e) => handleInputChange("nsfContribution", Number.parseInt(e.target.value) || 0)}
                      placeholder="20,000"
                      className="flex-1 px-4 py-2 border border-border rounded-lg bg-background text-foreground"
                    />
                  </div>
                  <p className="text-xs text-muted-foreground mt-1">Typically 2% of income</p>
                </div>

                <div>
                  <label className="text-sm font-medium block mb-2">National Health Insurance Scheme (NHIS)</label>
                  <div className="flex items-center gap-2">
                    <span className="text-muted-foreground">₦</span>
                    <input
                      type="number"
                      value={input.nhisContribution || ""}
                      onChange={(e) => handleInputChange("nhisContribution", Number.parseInt(e.target.value) || 0)}
                      placeholder="50,000"
                      className="flex-1 px-4 py-2 border border-border rounded-lg bg-background text-foreground"
                    />
                  </div>
                  <p className="text-xs text-muted-foreground mt-1">Typically 5% of income</p>
                </div>

                <div>
                  <label className="text-sm font-medium block mb-2">Life Assurance Premium</label>
                  <div className="flex items-center gap-2">
                    <span className="text-muted-foreground">₦</span>
                    <input
                      type="number"
                      value={input.lifeAssurancePremium || ""}
                      onChange={(e) => handleInputChange("lifeAssurancePremium", Number.parseInt(e.target.value) || 0)}
                      placeholder="30,000"
                      className="flex-1 px-4 py-2 border border-border rounded-lg bg-background text-foreground"
                    />
                  </div>
                  <p className="text-xs text-muted-foreground mt-1">Up to 3% of income</p>
                </div>

                {(input.incomeType === "freelance" ||
                  input.incomeType === "business" ||
                  input.incomeType === "multiple") && (
                  <div>
                    <label className="text-sm font-medium block mb-2">Business Expenses</label>
                    <div className="flex items-center gap-2">
                      <span className="text-muted-foreground">₦</span>
                      <input
                        type="number"
                        value={input.businessExpenses || ""}
                        onChange={(e) => handleInputChange("businessExpenses", Number.parseInt(e.target.value) || 0)}
                        placeholder="300,000"
                        className="flex-1 px-4 py-2 border border-border rounded-lg bg-background text-foreground"
                      />
                    </div>
                    <p className="text-xs text-muted-foreground mt-1">Travel, equipment, professional fees</p>
                  </div>
                )}
              </div>
            </div>
          )}

          {step === "details" && (
            <div>
              <h2 className="text-xl sm:text-2xl font-semibold mb-2">Final details</h2>
              <p className="text-muted-foreground text-sm mb-6">Help us suggest relevant actions.</p>
              <div className="space-y-4">
                {input.incomeType === "salary" && (
                  <div>
                    <label className="text-sm font-medium block mb-2">Employer Flexibility</label>
                    <p className="text-xs text-muted-foreground mb-3">
                      Can your employer adjust salary components without increasing gross cost?
                    </p>
                    <div className="space-y-2">
                      {(["NONE", "PARTIAL", "FULL"] as const).map((flex) => (
                        <Button
                          key={flex}
                          variant={input.employerFlexibility === flex ? "default" : "outline"}
                          onClick={() => handleInputChange("employerFlexibility", flex)}
                          className="w-full justify-start h-auto py-3 px-4 text-left"
                        >
                          <div>
                            <div className="font-medium">
                              {flex === "NONE"
                                ? "No Flexibility"
                                : flex === "PARTIAL"
                                  ? "Some Flexibility"
                                  : "Full Flexibility"}
                            </div>
                            <div className="text-xs text-muted-foreground mt-1">
                              {flex === "NONE"
                                ? "Fixed salary structure"
                                : flex === "PARTIAL"
                                  ? "Can adjust some components"
                                  : "Can restructure compensation"}
                            </div>
                          </div>
                        </Button>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </div>
          )}

          <div className="flex gap-3 mt-8">
            <Button
              variant="outline"
              onClick={handleBack}
              disabled={currentStepIndex === 0}
              className="flex-1 bg-transparent"
            >
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back
            </Button>
            <Button onClick={handleNext} disabled={!canProceed()} className="flex-1">
              {step === "details" ? (
                <>
                  Calculate <Zap className="w-4 h-4 ml-2" />
                </>
              ) : (
                <>
                  Next <ArrowRight className="w-4 h-4 ml-2" />
                </>
              )}
            </Button>
          </div>
        </Card>
      </div>
    </div>
  )
}
