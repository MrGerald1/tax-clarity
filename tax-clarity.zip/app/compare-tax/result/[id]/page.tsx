"use client"

import type React from "react"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { Navbar } from "@/components/shared/navbar"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { getCalculationFromSession } from "@/lib/session-manager"
import { formatNaira, formatPercent } from "@/lib/formatters"
import { TaxBreakdownDetails } from "@/components/shared/tax-breakdown-details"
import { ArrowRight, TrendingUp, TrendingDown, AlertCircle, Mail } from "lucide-react"

export default function Module2Result({ params }: { params: { id: string } }) {
  const router = useRouter()
  const [calculation, setCalculation] = useState<any>(null)
  const [loading, setLoading] = useState(true)
  const [email, setEmail] = useState("")
  const [emailCollected, setEmailCollected] = useState(false)
  const [showEmailPrompt, setShowEmailPrompt] = useState(false)

  useEffect(() => {
    const calc = getCalculationFromSession(params.id)
    if (calc) {
      setCalculation(calc)
      setShowEmailPrompt(true)
    }
    setLoading(false)
  }, [params.id])

  const handleEmailSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (email) {
      setEmailCollected(true)
      setShowEmailPrompt(false)
    }
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <div className="w-8 h-8 rounded-full border-2 border-primary border-t-transparent animate-spin mx-auto mb-4"></div>
          <p className="text-muted-foreground">Calculating impact...</p>
        </div>
      </div>
    )
  }

  if (!calculation) {
    return (
      <div className="min-h-screen bg-background">
        <Navbar />
        <div className="container max-w-3xl mx-auto px-4 py-16">
          <Card className="p-8 text-center">
            <p className="text-muted-foreground mb-4">Result not found. Please start over.</p>
            <Button onClick={() => router.push("/compare-tax")}>Start Over</Button>
          </Card>
        </div>
      </div>
    )
  }

  const oldResult = calculation.resultData.oldTax
  const newResult = calculation.resultData.newTax
  const outcome = calculation.resultData.outcome
  const deltaAmount = outcome.deltaAmount
  const deltaPercent = outcome.deltaPercent

  const isWorsOff = deltaAmount > 0
  const isBetterOff = deltaAmount < 0

  return (
    <div className="min-h-screen bg-gradient-to-b from-background to-muted/20">
      <Navbar />

      <div className="container max-w-3xl mx-auto px-4 py-8 sm:py-16">
        {showEmailPrompt && !emailCollected && (
          <Card className="p-6 mb-8 bg-blue-50 dark:bg-blue-950 border border-blue-200 dark:border-blue-800">
            <div className="flex gap-4">
              <Mail className="w-5 h-5 text-blue-600 dark:text-blue-400 flex-shrink-0 mt-0.5" />
              <div className="flex-1">
                <h3 className="font-semibold text-blue-900 dark:text-blue-100 mb-2">Stay Updated</h3>
                <p className="text-sm text-blue-800 dark:text-blue-200 mb-3">
                  Get alerts when Nigeria Revenue Service (NRS) updates tax rules. We'll never spam you.
                </p>
                <form onSubmit={handleEmailSubmit} className="flex gap-2">
                  <input
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="your@email.com"
                    className="flex-1 px-3 py-2 border border-blue-300 dark:border-blue-700 rounded bg-white dark:bg-blue-900 text-sm"
                    optional
                  />
                  <Button type="submit" size="sm" variant="default">
                    Subscribe
                  </Button>
                  <Button type="button" size="sm" variant="ghost" onClick={() => setShowEmailPrompt(false)}>
                    Skip
                  </Button>
                </form>
              </div>
            </div>
          </Card>
        )}

        {/* Main Result Card */}
        <Card
          className={`p-8 mb-8 border-2 ${isBetterOff ? "bg-green-50 dark:bg-green-950 border-green-200 dark:border-green-800" : isWorsOff ? "bg-red-50 dark:bg-red-950 border-red-200 dark:border-red-800" : "bg-blue-50 dark:bg-blue-950 border-blue-200 dark:border-blue-800"}`}
        >
          <div className="flex items-start gap-4 mb-6">
            {isBetterOff ? (
              <TrendingDown className="w-8 h-8 text-green-600 flex-shrink-0 mt-1" />
            ) : (
              <TrendingUp className="w-8 h-8 text-red-600 flex-shrink-0 mt-1" />
            )}
            <div className="flex-1">
              <h1
                className={`text-3xl font-bold mb-2 ${isBetterOff ? "text-green-700 dark:text-green-300" : isWorsOff ? "text-red-700 dark:text-red-300" : "text-blue-700 dark:text-blue-300"}`}
              >
                {isBetterOff
                  ? `Your Take-Home Improves by ${formatNaira(Math.abs(deltaAmount))}`
                  : isWorsOff
                    ? `Your Take-Home Reduces by ${formatNaira(deltaAmount)}`
                    : "No Change in Take-Home"}
              </h1>
              <p className="text-foreground text-lg">{outcome.explanation}</p>
            </div>
          </div>

          <div className="mt-6 p-4 bg-white/50 dark:bg-black/20 rounded border border-muted/50">
            <p className="text-xs text-muted-foreground flex gap-2">
              <AlertCircle className="w-4 h-4 flex-shrink-0 mt-0.5" />
              <span>
                These calculations are approximations based on stated tax rules. Actual amounts may vary based on
                individual circumstances. Always consult a tax professional for accurate guidance.
              </span>
            </p>
          </div>
        </Card>

        {/* Comparison Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
          {/* Old System */}
          <Card className="p-6 bg-card">
            <h3 className="font-semibold mb-4 text-muted-foreground">Old Tax System</h3>
            <div className="space-y-3 mb-4">
              <div>
                <p className="text-sm text-muted-foreground">Annual Tax</p>
                <p className="text-2xl font-bold text-foreground">{formatNaira(oldResult.tax)}</p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Monthly Tax</p>
                <p className="text-lg font-semibold text-foreground">{formatNaira(oldResult.monthlyTax)}</p>
              </div>
              <div className="pt-3 border-t border-border">
                <p className="text-sm text-muted-foreground">Annual Take-Home</p>
                <p className="text-lg font-semibold text-foreground">{formatNaira(oldResult.takeHome)}</p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Monthly Take-Home</p>
                <p className="text-lg font-semibold text-foreground">{formatNaira(oldResult.monthlyTakeHome)}</p>
              </div>
            </div>
          </Card>

          {/* New System */}
          <Card className="p-6 bg-card border-2 border-primary">
            <h3 className="font-semibold mb-4 text-primary">New Tax System</h3>
            <div className="space-y-3 mb-4">
              <div>
                <p className="text-sm text-muted-foreground">Annual Tax</p>
                <p className="text-2xl font-bold text-foreground">{formatNaira(newResult.tax)}</p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Monthly Tax</p>
                <p className="text-lg font-semibold text-foreground">{formatNaira(newResult.monthlyTax)}</p>
              </div>
              <div className="pt-3 border-t border-border">
                <p className="text-sm text-muted-foreground">Annual Take-Home</p>
                <p className="text-lg font-semibold text-foreground">{formatNaira(newResult.takeHome)}</p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Monthly Take-Home</p>
                <p className="text-lg font-semibold text-foreground">{formatNaira(newResult.monthlyTakeHome)}</p>
              </div>
            </div>
          </Card>
        </div>

        <Card className="p-6 mb-8 bg-card">
          <h3 className="font-semibold mb-4">Your Take-Home Impact</h3>
          <p className="text-sm text-muted-foreground mb-4">
            Monitor your next few months' salary to confirm this impact. Your actual take-home depends on exact salary
            structure and deductions applied by your employer.
          </p>
          <div className="grid grid-cols-2 gap-6">
            <div>
              <p className="text-sm text-muted-foreground">Annual Difference</p>
              <p
                className={`text-3xl font-bold ${isBetterOff ? "text-green-600" : isWorsOff ? "text-red-600" : "text-gray-600"}`}
              >
                {isBetterOff ? "+" : ""}
                {formatNaira(deltaAmount)}
              </p>
            </div>
            <div>
              <p className="text-sm text-muted-foreground">% of Gross Income</p>
              <p
                className={`text-3xl font-bold ${isBetterOff ? "text-green-600" : isWorsOff ? "text-red-600" : "text-gray-600"}`}
              >
                {isBetterOff ? "+" : ""}
                {formatPercent(deltaPercent)}
              </p>
            </div>
          </div>
        </Card>

        <TaxBreakdownDetails oldTaxBreakdown={oldResult} newTaxBreakdown={newResult} />

        <Card className="p-6 my-8 bg-muted/30 border-muted">
          <h3 className="font-semibold mb-3 flex items-center gap-2">
            <AlertCircle className="w-5 h-5 text-blue-600" />
            Learn More
          </h3>
          <p className="text-sm text-muted-foreground mb-3">
            For official tax rules and updates, visit the Nigeria Revenue Service (NRS) website:
          </p>
          <a
            href="https://www.nrs.gov.ng/"
            target="_blank"
            rel="noopener noreferrer"
            className="text-primary font-medium hover:underline text-sm"
          >
            www.nrs.gov.ng →
          </a>
        </Card>

        {/* Action Buttons */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mt-8 mb-8">
          <Button onClick={() => router.push("/compare-tax")} variant="outline" className="h-12">
            Adjust Scenario
          </Button>
          <Button onClick={() => router.push("/optimize-income")} className="h-12 gap-2">
            See Action Plan
            <ArrowRight className="w-4 h-4" />
          </Button>
        </div>

        {/* Back to Hub */}
        <div className="text-center">
          <Button variant="ghost" onClick={() => router.push("/")} className="text-muted-foreground">
            Back to All Modules
          </Button>
        </div>
      </div>
    </div>
  )
}
