"use client"

import { Navbar } from "@/components/shared/navbar"
import { Footer } from "@/components/shared/footer"
import { LiveCounter } from "@/components/shared/live-counter"
import { ComparisonInsights } from "@/components/shared/comparison-insights"
import { FAQSection } from "@/components/shared/faq-section"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import Link from "next/link"
import { ArrowRight, CheckCircle2 } from "lucide-react"

export default function Home() {
  return (
    <div className="min-h-screen bg-background">
      <Navbar />

      {/* Hero Section */}
      <section className="container max-w-6xl mx-auto px-4 py-16 sm:py-24">
        <div className="text-center mb-12 space-y-4">
          <h1 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-foreground text-balance">
            Understand Your Tax Situation
          </h1>
          <p className="text-lg sm:text-xl text-muted-foreground max-w-2xl mx-auto text-balance">
            Free tools to help you understand how Nigeria's new tax law affects your take-home. No signup required.
          </p>
        </div>

        {/* Live Counter */}
        <div className="mb-16">
          <LiveCounter />
        </div>

        {/* Feature Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
          {/* Feature 1 */}
          <Link href="/tax-exposure-check">
            <Card className="h-full p-8 hover:shadow-xl hover:border-primary transition-all cursor-pointer">
              <div className="flex items-start justify-between mb-6">
                <div className="w-14 h-14 rounded-lg bg-primary/20 flex items-center justify-center">
                  <span className="text-primary font-bold text-xl">1</span>
                </div>
              </div>
              <h3 className="text-xl font-bold mb-3 text-foreground">Tax Exposure Check</h3>
              <p className="text-muted-foreground mb-6 text-sm leading-relaxed">
                Quick questionnaire to understand your tax responsibility and initial exposure.
              </p>
              <ul className="space-y-3 text-sm">
                <li className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-secondary flex-shrink-0" />
                  <span className="text-foreground">2-3 minute questionnaire</span>
                </li>
                <li className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-secondary flex-shrink-0" />
                  <span className="text-foreground">Clear responsibility outcome</span>
                </li>
                <li className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-secondary flex-shrink-0" />
                  <span className="text-foreground">Shareable results</span>
                </li>
              </ul>
            </Card>
          </Link>

          {/* Feature 2 */}
          <Link href="/tax-impact-calculator">
            <Card className="h-full p-8 hover:shadow-xl hover:border-primary transition-all cursor-pointer">
              <div className="flex items-start justify-between mb-6">
                <div className="w-14 h-14 rounded-lg bg-secondary/20 flex items-center justify-center">
                  <span className="text-secondary-foreground font-bold text-xl">2</span>
                </div>
              </div>
              <h3 className="text-xl font-bold mb-3 text-foreground">Tax Impact Calculator</h3>
              <p className="text-muted-foreground mb-6 text-sm leading-relaxed">
                Compare old vs new system. See your exact naira impact on your take-home.
              </p>
              <ul className="space-y-3 text-sm">
                <li className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-secondary flex-shrink-0" />
                  <span className="text-foreground">Old vs new comparison</span>
                </li>
                <li className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-secondary flex-shrink-0" />
                  <span className="text-foreground">Multiple income sources</span>
                </li>
                <li className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-secondary flex-shrink-0" />
                  <span className="text-foreground">Detailed breakdowns</span>
                </li>
              </ul>
            </Card>
          </Link>

          {/* Feature 3 */}
          <Link href="/tax-optimization">
            <Card className="h-full p-8 hover:shadow-xl hover:border-primary transition-all cursor-pointer">
              <div className="flex items-start justify-between mb-6">
                <div className="w-14 h-14 rounded-lg bg-accent/20 flex items-center justify-center">
                  <span className="text-accent font-bold text-xl">3</span>
                </div>
              </div>
              <h3 className="text-xl font-bold mb-3 text-foreground">Tax Optimization</h3>
              <p className="text-muted-foreground mb-6 text-sm leading-relaxed">
                Get role-specific actions to reduce your tax legally and improve your situation.
              </p>
              <ul className="space-y-3 text-sm">
                <li className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-secondary flex-shrink-0" />
                  <span className="text-foreground">Role-specific actions</span>
                </li>
                <li className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-secondary flex-shrink-0" />
                  <span className="text-foreground">Implementation guides</span>
                </li>
                <li className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-secondary flex-shrink-0" />
                  <span className="text-foreground">Export & share plans</span>
                </li>
              </ul>
            </Card>
          </Link>
        </div>

        {/* CTA Buttons */}
        <div className="flex flex-col sm:flex-row gap-4 justify-center mb-16">
          <Link href="/tax-exposure-check">
            <Button size="lg" className="w-full sm:w-auto">
              Start Tax Exposure Check <ArrowRight className="ml-2 w-4 h-4" />
            </Button>
          </Link>
          <Link href="/tax-guide">
            <Button size="lg" variant="outline" className="w-full sm:w-auto bg-transparent">
              Learn About Changes
            </Button>
          </Link>
        </div>
      </section>

      {/* Comparison Insights */}
      <section className="bg-card py-16">
        <div className="container max-w-6xl mx-auto px-4">
          <ComparisonInsights />
        </div>
      </section>

      {/* FAQ Section */}
      <section className="container max-w-6xl mx-auto px-4 py-16">
        <FAQSection />
      </section>

      <Footer />
    </div>
  )
}
