"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { Navbar } from "@/components/shared/navbar"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { ShareButtons } from "@/components/shared/share-buttons"
import { getSessionData, saveCalculationToSession } from "@/lib/session-manager"
import { formatCurrency } from "@/lib/formatters"
import { ArrowRight, AlertCircle, FileText, Users, Briefcase, Download } from "lucide-react"
import Link from "next/link"

interface Action {
  id: string
  title: string
  description: string
  impact: number
  effort: "Low" | "Medium" | "High"
  actor: string
  timeline: string
  steps: string[]
}

const SALARY_EARNER_ACTIONS: Action[] = [
  {
    id: "salary-negotiation",
    title: "Negotiate Gross Increase",
    description: "Work with your HR to increase your gross salary to offset tax loss.",
    impact: 0,
    effort: "Medium",
    actor: "You & HR",
    timeline: "1-2 weeks",
    steps: [
      "Calculate required gross increase using tax delta",
      "Prepare negotiation document with NRS justification",
      "Schedule meeting with HR/Finance",
      "Present business case and timeline",
    ],
  },
  {
    id: "allowance-restructure",
    title: "Restructure Allowances",
    description: "Shift compensation to tax-advantaged allowances (housing, transport, meal).",
    impact: 0,
    effort: "Low",
    actor: "You & HR",
    timeline: "Immediate",
    steps: [
      "Identify non-taxable allowances you currently receive",
      "Propose shift to housing, transport, or meal allowances",
      "Recalculate take-home with new structure",
      "Submit HR request",
    ],
  },
  {
    id: "maximize-deductions",
    title: "Maximize Deductions",
    description: "Ensure all eligible deductions are captured (pension, insurance, etc.).",
    impact: 0,
    effort: "Low",
    actor: "You",
    timeline: "Immediate",
    steps: [
      "Review your payslip for all deductions",
      "Confirm pension contributions are at maximum allowed",
      "Check life insurance premium eligibility",
      "Request HR to adjust withholdings if needed",
    ],
  },
  {
    id: "monthly-monitoring",
    title: "Monitor Monthly Changes",
    description: "Track your actual take-home over the next few months to verify calculations.",
    impact: 0,
    effort: "Low",
    actor: "You",
    timeline: "Ongoing",
    steps: [
      "Keep copies of March, April, May payslips",
      "Calculate actual vs expected tax withholding",
      "Flag discrepancies for HR review",
      "Recalculate impact with actual figures",
    ],
  },
]

const FREELANCER_ACTIONS: Action[] = [
  {
    id: "deduction-optimization",
    title: "Claim All Allowable Deductions",
    description: "Identify and claim all business expenses to reduce taxable income.",
    impact: 0,
    effort: "Medium",
    actor: "You",
    timeline: "Before filing",
    steps: [
      "Internet & phone bills",
      "Software subscriptions",
      "Workspace rent / home office",
      "Professional development courses",
      "Transport & travel",
      "Equipment & tools",
      "Professional fees (accountant, lawyer)",
    ],
  },
  {
    id: "record-keeping",
    title: "Improve Record Keeping",
    description: "Maintain receipts and documentation for all deductions claimed.",
    impact: 0,
    effort: "High",
    actor: "You",
    timeline: "Ongoing",
    steps: [
      "Create digital folder for receipts",
      "Use expense tracking app",
      "Store invoices for all suppliers",
      "Maintain bank statements showing payments",
      "Keep emails confirming expenses",
    ],
  },
  {
    id: "filing-preparation",
    title: "Prepare for Filing",
    description: "Get ready to file by 31 March with all required documents.",
    impact: 0,
    effort: "Medium",
    actor: "You",
    timeline: "By 31 Jan",
    steps: [
      "Calculate net profit (income - expenses)",
      "Complete income & expenses schedule",
      "Register with NRS if not already done",
      "Gather all supporting documents",
      "Submit before deadline",
    ],
  },
]

const BUSINESS_ACTIONS: Action[] = [
  {
    id: "registration-check",
    title: "Verify Registration Status",
    description: "Ensure your business is registered with NRS and TIN is current.",
    impact: 0,
    effort: "Low",
    actor: "You",
    timeline: "Immediate",
    steps: [
      "Check your TIN validity at NRS portal",
      "Verify business registration documents",
      "Update profile if details changed",
      "Download current tax clearance",
    ],
  },
  {
    id: "profit-tracking",
    title: "Track Profit Accurately",
    description: "Distinguish between cash flow and taxable income to avoid panic.",
    impact: 0,
    effort: "Medium",
    actor: "You",
    timeline: "Ongoing",
    steps: [
      "Keep detailed income records",
      "Track all business expenses",
      "Reconcile bank statements monthly",
      "Calculate profit quarterly",
      "Plan tax payments accordingly",
    ],
  },
]

const HR_ACTIONS: Action[] = [
  {
    id: "payroll-analysis",
    title: "Analyze Team Impact",
    description: "Determine how many employees are affected and by how much.",
    impact: 0,
    effort: "Low",
    actor: "HR/Finance",
    timeline: "Immediate",
    steps: [
      "Export payroll data for all employees",
      "Run tax comparison (old vs new)",
      "Identify high-impact employees",
      "Calculate total team cost increase",
      "Present findings to management",
    ],
  },
  {
    id: "adjustment-planning",
    title: "Plan Salary Adjustments",
    description: "Develop strategy to address tax impact across your organization.",
    impact: 0,
    effort: "High",
    actor: "Management & HR",
    timeline: "1-2 weeks",
    steps: [
      "Choose adjustment strategy (across-the-board, targeted, structural)",
      "Model financial impact",
      "Get board/management approval",
      "Prepare communication for employees",
      "Implement changes with clear timeline",
    ],
  },
  {
    id: "employee-communication",
    title: "Communicate Impact & Plan",
    description: "Ensure employees understand the change and your response.",
    impact: 0,
    effort: "Medium",
    actor: "HR & Management",
    timeline: "Before payroll change",
    steps: [
      "Send explanation email to team",
      "Host Q&A session or webinar",
      "Provide individual impact letters",
      "Share company response/adjustments",
      "Create FAQ document",
    ],
  },
]

export default function TaxOptimization() {
  const router = useRouter()
  const [userRole, setUserRole] = useState<"salary" | "freelancer" | "business" | "hr" | null>(null)
  const [selectedRole, setSelectedRole] = useState<"salary" | "freelancer" | "business" | "hr" | null>(null)
  const [selectedAction, setSelectedAction] = useState<string | null>(null)
  const [expanded, setExpanded] = useState<string | null>(null)

  // Load role from session if available
  useEffect(() => {
    const sessionData = getSessionData()
    if (sessionData?.module1) {
      const incomeType = (sessionData.module1 as any).incomeType
      if (incomeType === "salary") setUserRole("salary")
      else if (incomeType === "freelance") setUserRole("freelancer")
      else if (incomeType === "business") setUserRole("business")
    }
  }, [])

  const getActions = () => {
    const role = selectedRole || userRole
    if (role === "salary") return SALARY_EARNER_ACTIONS
    if (role === "freelancer") return FREELANCER_ACTIONS
    if (role === "business") return BUSINESS_ACTIONS
    if (role === "hr") return HR_ACTIONS
    return []
  }

  if (!userRole && !selectedRole) {
    return (
      <div className="min-h-screen bg-background">
        <Navbar />
        <div className="container max-w-2xl mx-auto px-4 py-12">
          <div className="mb-8">
            <h1 className="text-3xl font-bold text-foreground mb-2">Tax Optimisation & Action Planner</h1>
            <p className="text-muted-foreground">
              Get specific, actionable recommendations based on your role.
            </p>
          </div>

          <Card className="p-8">
            <h2 className="text-xl font-bold text-foreground mb-6">Who are you?</h2>
            <div className="space-y-3">
              <button
                onClick={() => setSelectedRole("salary")}
                className="w-full text-left p-4 rounded-lg border-2 border-border hover:border-primary/50 hover:bg-primary/5 transition-all"
              >
                <p className="font-semibold text-foreground">Salary Earner</p>
                <p className="text-sm text-muted-foreground">Employed with fixed salary</p>
              </button>
              <button
                onClick={() => setSelectedRole("freelancer")}
                className="w-full text-left p-4 rounded-lg border-2 border-border hover:border-primary/50 hover:bg-primary/5 transition-all"
              >
                <p className="font-semibold text-foreground">Freelancer / Contractor</p>
                <p className="text-sm text-muted-foreground">Self-employed, project-based income</p>
              </button>
              <button
                onClick={() => setSelectedRole("business")}
                className="w-full text-left p-4 rounded-lg border-2 border-border hover:border-primary/50 hover:bg-primary/5 transition-all"
              >
                <p className="font-semibold text-foreground">Business Owner</p>
                <p className="text-sm text-muted-foreground">Own a registered business</p>
              </button>
              <button
                onClick={() => setSelectedRole("hr")}
                className="w-full text-left p-4 rounded-lg border-2 border-border hover:border-primary/50 hover:bg-primary/5 transition-all"
              >
                <p className="font-semibold text-foreground">Employer / HR Manager</p>
                <p className="text-sm text-muted-foreground">Responsible for payroll</p>
              </button>
            </div>
          </Card>
        </div>
      </div>
    )
  }

  const actions = getActions()
  const role = selectedRole || userRole
  const roleLabel = role === "salary" ? "Salary Earner" : role === "freelancer" ? "Freelancer" : role === "business" ? "Business Owner" : "Employer"

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <div className="container max-w-4xl mx-auto px-4 py-12">
        <div className="mb-8">
          <button
            onClick={() => { setSelectedRole(null); setUserRole(null); }}
            className="text-primary hover:underline text-sm mb-4 flex items-center gap-2"
          >
            ← Change role
          </button>
          <h1 className="text-3xl font-bold text-foreground mb-2">Actions for {roleLabel}s</h1>
          <p className="text-muted-foreground">
            Specific, actionable steps to optimize your taxes under the new law.
          </p>
        </div>

        {/* Alert */}
        <Alert className="mb-8 border-amber-200 bg-amber-50">
          <AlertCircle className="h-4 w-4 text-amber-600" />
          <AlertDescription className="text-amber-900">
            <strong>Important:</strong> These recommendations are general guidance. For your specific situation, consult a qualified tax professional. Monitor your actual salary/income to verify the impact.
          </AlertDescription>
        </Alert>

        {/* Actions */}
        <div className="space-y-4">
          {actions.map((action) => (
            <Card
              key={action.id}
              className={`p-6 cursor-pointer transition-all border-2 ${
                expanded === action.id ? "border-primary bg-primary/5" : "border-border hover:border-primary/30"
              }`}
              onClick={() => setExpanded(expanded === action.id ? null : action.id)}
            >
              <div className="flex items-start justify-between mb-4">
                <div className="flex-1">
                  <h3 className="text-lg font-bold text-foreground mb-1">{action.title}</h3>
                  <p className="text-muted-foreground text-sm">{action.description}</p>
                </div>
                <div className="ml-4 flex-shrink-0">
                  <span className={`inline-block px-3 py-1 rounded-full text-xs font-medium ${
                    action.effort === "Low" ? "bg-green-100 text-green-700" :
                    action.effort === "Medium" ? "bg-amber-100 text-amber-700" :
                    "bg-red-100 text-red-700"
                  }`}>
                    {action.effort} Effort
                  </span>
                </div>
              </div>

              {expanded === action.id && (
                <div className="space-y-4 pt-4 border-t border-border">
                  <div className="grid grid-cols-3 gap-4 text-sm">
                    <div>
                      <p className="text-muted-foreground font-medium">Actor</p>
                      <p className="text-foreground">{action.actor}</p>
                    </div>
                    <div>
                      <p className="text-muted-foreground font-medium">Timeline</p>
                      <p className="text-foreground">{action.timeline}</p>
                    </div>
                    <div>
                      <p className="text-muted-foreground font-medium">Impact</p>
                      <p className="text-foreground">{action.impact === 0 ? "Varies" : formatCurrency(action.impact)}</p>
                    </div>
                  </div>

                  <div>
                    <p className="font-semibold text-foreground mb-3">Implementation Steps:</p>
                    <ol className="space-y-2">
                      {action.steps.map((step, idx) => (
                        <li key={idx} className="flex gap-3 text-sm">
                          <span className="font-bold text-primary flex-shrink-0">{idx + 1}.</span>
                          <span className="text-foreground">{step}</span>
                        </li>
                      ))}
                    </ol>
                  </div>

                  <Button className="w-full bg-transparent" variant="outline">
                    <Download className="w-4 h-4 mr-2" />
                    Download Action Guide
                  </Button>
                </div>
              )}
            </Card>
          ))}
        </div>

        {/* Share Section */}
        <Card className="mt-12 p-8">
          <h2 className="text-lg font-bold text-foreground mb-4">Share Your Action Plan</h2>
          <ShareButtons 
            title="My Tax Optimization Plan"
            description={`I've explored my tax optimization as a ${roleLabel} under Nigeria's new tax law`}
          />
        </Card>

        {/* Next Steps */}
        <div className="mt-12 text-center">
          <p className="text-muted-foreground mb-4">
            Need professional help with your specific situation?
          </p>
          <Button variant="outline">
            Find a Tax Professional
          </Button>
        </div>
      </div>
    </div>
  )
}
