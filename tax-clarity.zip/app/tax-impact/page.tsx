'use client'

import { useState, useEffect } from 'react'
import { Navbar } from '@/components/shared/navbar'
import { Button } from '@/components/ui/button'
import { Card } from '@/components/ui/card'
import { Progress } from '@/components/ui/progress'
import { determineResponsibilityState, type Module1Input } from '@/lib/state-machines/module1-branching'
import { calculateNewTax, calculateOldTax } from '@/lib/calculations/tax-new'
import { saveCalculationToSession } from '@/lib/session-manager'
import { formatNaira, formatCurrency } from '@/lib/formatters'
import { ArrowRight, ArrowLeft, CheckCircle2, Info } from 'lucide-react'

interface IncomeSource {
  type: string
  amount: number
}

interface FormData extends Module1Input {
  incomeAmount: number
  businessTurnover?: number
  businessAssets?: boolean
  incomeAmountUSD?: number
  exchangeRate?: number
  pensionAmount?: number
  rentReliefAmount?: number
  nhfAmount?: number
  nhisAmount?: number
  lifeAssuranceAmount?: number
}

type Step = 'status' | 'income' | 'deductions' | 'results'

export default function TaxImpact() {
  const [step, setStep] = useState<Step>('status')
  const [formData, setFormData] = useState<Partial<FormData>>({
    hasIncome: null,
    incomeType: '',
    employmentStatus: '',
    incomeAmount: 0,
  })
  const [result, setResult] = useState<any>(null)
  const [calculation, setCalculation] = useState<any>(null)
  const [showResults, setShowResults] = useState(false)

  const handleStatusAnswer = (answer: boolean) => {
    if (!answer) {
      setFormData({ ...formData, hasIncome: false })
      setResult({ state: 'NO_TAX_ACTION_REQUIRED', explanation: 'You have indicated you have no income in Nigeria.' })
      setShowResults(true)
    } else {
      setFormData({ ...formData, hasIncome: true })
      setStep('income')
    }
  }

  const handleIncomeInput = (field: string, value: any) => {
    setFormData({ ...formData, [field]: value })
  }

  const handleContinueToDeductions = () => {
    // Determine status
    const statusResult = determineResponsibilityState(formData as Module1Input)
    setResult(statusResult)
    saveCalculationToSession('module1', formData, statusResult)
    setStep('deductions')
  }

  const handleCalculateTax = () => {
    const grossIncome = formData.incomeAmount || 0
    
    const oldResult = calculateOldTax({
      grossAnnualIncome: grossIncome,
      pensionContribution: formData.pensionAmount || 0,
      rentRelief: formData.rentReliefAmount || 0,
      nsfContribution: formData.nhfAmount || 0,
      nhisContribution: formData.nhisAmount || 0,
      lifeAssurancePremium: formData.lifeAssuranceAmount || 0,
    })

    const newResult = calculateNewTax({
      grossAnnualIncome: grossIncome,
      incomeType: (formData.incomeType as "salary" | "freelance" | "business" | "multiple") || "salary",
      pensionContribution: formData.pensionAmount || 0,
      rentAmount: formData.rentReliefAmount || 0,
      nsfContribution: formData.nhfAmount || 0,
      nhisContribution: formData.nhisAmount || 0,
      lifeAssurancePremium: formData.lifeAssuranceAmount || 0,
    })

    const oldTax = oldResult.tax
    const newTax = newResult.tax
    const taxableIncome = newResult.taxableIncome

    const delta = ((newTax - oldTax) / grossIncome) * 100
    
    setCalculation({
      grossIncome,
      taxableIncome,
      oldTax,
      newTax,
      delta,
      monthlyOldTax: oldTax / 12,
      monthlyNewTax: newTax / 12,
      monthlyDifference: (newTax - oldTax) / 12,
    })

    saveCalculationToSession('module2', formData, { oldTax, newTax, delta })
    setShowResults(true)
  }

  // Step 1: Status Determination
  if (!showResults && step === 'status') {
    return (
      <div className="min-h-screen bg-background">
        <Navbar />
        <div className="flex flex-col min-h-[calc(100vh-4rem)]">
          <div className="container max-w-2xl mx-auto px-4 py-8 sm:py-12 flex-1 flex flex-col justify-center">
            <Card className="p-6 sm:p-8">
              <div className="mb-8">
                <h1 className="text-2xl sm:text-3xl font-bold text-foreground mb-2">Tax Impact Assessment</h1>
                <p className="text-sm sm:text-base text-muted-foreground">
                  Let's determine your tax situation and compare old vs new system impact.
                </p>
              </div>

              <div className="space-y-4">
                <h2 className="text-lg sm:text-xl font-semibold text-foreground">Do you have income in Nigeria?</h2>
                <p className="text-sm text-muted-foreground mb-6">
                  This includes salary, freelance work, business income, or investments.
                </p>

                <div className="flex flex-col sm:flex-row gap-3">
                  <Button
                    className="flex-1 h-12 sm:h-11 text-sm sm:text-base"
                    onClick={() => handleStatusAnswer(true)}
                  >
                    Yes, I have income
                  </Button>
                  <Button
                    variant="outline"
                    className="flex-1 h-12 sm:h-11 text-sm sm:text-base bg-transparent"
                    onClick={() => handleStatusAnswer(false)}
                  >
                    No income
                  </Button>
                </div>
              </div>
            </Card>
          </div>
        </div>
      </div>
    )
  }

  // Step 2: Income Information
  if (!showResults && step === 'income') {
    return (
      <div className="min-h-screen bg-background">
        <Navbar />
        <div className="container max-w-2xl mx-auto px-4 py-8 sm:py-12">
          <Card className="p-6 sm:p-8">
            <div className="mb-8">
              <Progress value={33} className="h-2 mb-4" />
              <h1 className="text-2xl sm:text-3xl font-bold text-foreground mb-2">Your Income</h1>
              <p className="text-sm sm:text-base text-muted-foreground">
                Help us understand your primary income source and amount.
              </p>
            </div>

            <div className="space-y-6">
              {/* Income Type */}
              <div>
                <label className="block text-sm font-medium text-foreground mb-3">Primary Income Type</label>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  {[
                    { value: 'salary', label: 'Salary (PAYE)', desc: 'From employer' },
                    { value: 'freelance', label: 'Freelance', desc: 'Self-employed' },
                    { value: 'business', label: 'Business', desc: 'Own business' },
                    { value: 'multiple', label: 'Multiple', desc: 'Combined income' },
                  ].map((option) => (
                    <button
                      key={option.value}
                      onClick={() => handleIncomeInput('incomeType', option.value)}
                      className={`p-3 rounded-lg border-2 transition-all text-left text-sm ${
                        formData.incomeType === option.value
                          ? 'border-primary bg-primary/5'
                          : 'border-border hover:border-primary/50'
                      }`}
                    >
                      <p className="font-medium text-foreground">{option.label}</p>
                      <p className="text-xs text-muted-foreground mt-1">{option.desc}</p>
                    </button>
                  ))}
                </div>
              </div>

              {/* Gross Annual Income */}
              <div>
                <label className="block text-sm font-medium text-foreground mb-3">
                  Gross Annual Income
                </label>
                <div className="relative">
                  <span className="absolute left-4 top-3 text-foreground text-sm">₦</span>
                  <input
                    type="number"
                    placeholder="Enter amount"
                    value={formData.incomeAmount || ''}
                    onChange={(e) => handleIncomeInput('incomeAmount', parseFloat(e.target.value) || 0)}
                    className="w-full pl-8 pr-4 py-3 rounded-lg border border-border bg-card text-foreground placeholder-muted-foreground text-sm focus:outline-none focus:ring-2 focus:ring-primary"
                  />
                </div>
                <p className="text-xs text-muted-foreground mt-2">
                  Before tax, pension, or deductions
                </p>
              </div>

              {/* Navigation */}
              <div className="flex gap-3 pt-4">
                <Button
                  variant="outline"
                  onClick={() => setStep('status')}
                  className="flex-1 bg-transparent"
                >
                  <ArrowLeft className="w-4 h-4 mr-2" /> Back
                </Button>
                <Button
                  onClick={handleContinueToDeductions}
                  disabled={!formData.incomeType || !formData.incomeAmount}
                  className="flex-1"
                >
                  Continue <ArrowRight className="w-4 h-4 ml-2" />
                </Button>
              </div>
            </div>
          </Card>
        </div>
      </div>
    )
  }

  // Step 3: Deductions
  if (!showResults && step === 'deductions') {
    return (
      <div className="min-h-screen bg-background">
        <Navbar />
        <div className="container max-w-2xl mx-auto px-4 py-8 sm:py-12">
          <Card className="p-6 sm:p-8">
            <div className="mb-8">
              <Progress value={66} className="h-2 mb-4" />
              <h1 className="text-2xl sm:text-3xl font-bold text-foreground mb-2">Deductions</h1>
              <p className="text-sm sm:text-base text-muted-foreground">
                Tell us about deductions from your gross income (optional).
              </p>
            </div>

            <div className="space-y-6">
              {/* Pension Contribution */}
              <div className="space-y-3">
                <label className="flex items-center gap-3 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={!!formData.pensionAmount}
                    onChange={(e) => handleIncomeInput('pensionAmount', e.target.checked ? 0 : undefined)}
                    className="w-4 h-4"
                  />
                  <span className="text-sm font-medium text-foreground">Pension Contribution (NPS)</span>
                </label>
                {formData.pensionAmount !== undefined && (
                  <div className="relative ml-7">
                    <span className="absolute left-4 top-3 text-foreground text-sm">₦</span>
                    <input
                      type="number"
                      placeholder="Amount"
                      value={formData.pensionAmount || ''}
                      onChange={(e) => handleIncomeInput('pensionAmount', parseFloat(e.target.value) || 0)}
                      className="w-full pl-8 pr-4 py-2 rounded-lg border border-border bg-card text-foreground text-sm focus:outline-none focus:ring-2 focus:ring-primary"
                    />
                  </div>
                )}
              </div>

              {/* Rent Relief */}
              <div className="space-y-3">
                <label className="flex items-center gap-3 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={!!formData.rentReliefAmount}
                    onChange={(e) => handleIncomeInput('rentReliefAmount', e.target.checked ? 0 : undefined)}
                    className="w-4 h-4"
                  />
                  <span className="text-sm font-medium text-foreground">Rent Relief</span>
                </label>
                {formData.rentReliefAmount !== undefined && (
                  <div className="relative ml-7">
                    <span className="absolute left-4 top-3 text-foreground text-sm">₦</span>
                    <input
                      type="number"
                      placeholder="Annual rent"
                      value={formData.rentReliefAmount || ''}
                      onChange={(e) => handleIncomeInput('rentReliefAmount', parseFloat(e.target.value) || 0)}
                      className="w-full pl-8 pr-4 py-2 rounded-lg border border-border bg-card text-foreground text-sm focus:outline-none focus:ring-2 focus:ring-primary"
                    />
                    <p className="text-xs text-muted-foreground mt-2">
                      Cap: 20% of rent or ₦500k, whichever is lower
                    </p>
                  </div>
                )}
              </div>

              {/* NHF Contribution */}
              <div className="space-y-3">
                <label className="flex items-center gap-3 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={!!formData.nhfAmount}
                    onChange={(e) => handleIncomeInput('nhfAmount', e.target.checked ? 0 : undefined)}
                    className="w-4 h-4"
                  />
                  <span className="text-sm font-medium text-foreground">NHF Contribution</span>
                </label>
                {formData.nhfAmount !== undefined && (
                  <div className="relative ml-7">
                    <span className="absolute left-4 top-3 text-foreground text-sm">₦</span>
                    <input
                      type="number"
                      placeholder="Amount"
                      value={formData.nhfAmount || ''}
                      onChange={(e) => handleIncomeInput('nhfAmount', parseFloat(e.target.value) || 0)}
                      className="w-full pl-8 pr-4 py-2 rounded-lg border border-border bg-card text-foreground text-sm focus:outline-none focus:ring-2 focus:ring-primary"
                    />
                  </div>
                )}
              </div>

              {/* NHIS Contribution */}
              <div className="space-y-3">
                <label className="flex items-center gap-3 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={!!formData.nhisAmount}
                    onChange={(e) => handleIncomeInput('nhisAmount', e.target.checked ? 0 : undefined)}
                    className="w-4 h-4"
                  />
                  <span className="text-sm font-medium text-foreground">NHIS Contribution</span>
                </label>
                {formData.nhisAmount !== undefined && (
                  <div className="relative ml-7">
                    <span className="absolute left-4 top-3 text-foreground text-sm">₦</span>
                    <input
                      type="number"
                      placeholder="Amount"
                      value={formData.nhisAmount || ''}
                      onChange={(e) => handleIncomeInput('nhisAmount', parseFloat(e.target.value) || 0)}
                      className="w-full pl-8 pr-4 py-2 rounded-lg border border-border bg-card text-foreground text-sm focus:outline-none focus:ring-2 focus:ring-primary"
                    />
                  </div>
                )}
              </div>

              {/* Life Assurance */}
              <div className="space-y-3">
                <label className="flex items-center gap-3 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={!!formData.lifeAssuranceAmount}
                    onChange={(e) => handleIncomeInput('lifeAssuranceAmount', e.target.checked ? 0 : undefined)}
                    className="w-4 h-4"
                  />
                  <span className="text-sm font-medium text-foreground">Life Assurance Premium</span>
                </label>
                {formData.lifeAssuranceAmount !== undefined && (
                  <div className="relative ml-7">
                    <span className="absolute left-4 top-3 text-foreground text-sm">₦</span>
                    <input
                      type="number"
                      placeholder="Amount"
                      value={formData.lifeAssuranceAmount || ''}
                      onChange={(e) => handleIncomeInput('lifeAssuranceAmount', parseFloat(e.target.value) || 0)}
                      className="w-full pl-8 pr-4 py-2 rounded-lg border border-border bg-card text-foreground text-sm focus:outline-none focus:ring-2 focus:ring-primary"
                    />
                  </div>
                )}
              </div>

              {/* Navigation */}
              <div className="flex gap-3 pt-4">
                <Button
                  variant="outline"
                  onClick={() => setStep('income')}
                  className="flex-1 bg-transparent"
                >
                  <ArrowLeft className="w-4 h-4 mr-2" /> Back
                </Button>
                <Button
                  onClick={handleCalculateTax}
                  className="flex-1"
                >
                  Calculate Tax <ArrowRight className="w-4 h-4 ml-2" />
                </Button>
              </div>
            </div>
          </Card>
        </div>
      </div>
    )
  }

  // Results Page
  if (showResults) {
    return (
      <div className="min-h-screen bg-background">
        <Navbar />
        <div className="container max-w-4xl mx-auto px-4 py-8 sm:py-12">
          {/* Status Section */}
          {result && !calculation && (
            <Card className="p-6 sm:p-8 mb-6">
              <h1 className="text-2xl sm:text-3xl font-bold text-foreground mb-6">Your Tax Status</h1>
              <div className="bg-gradient-to-br from-primary/10 to-secondary/10 border border-primary/20 rounded-xl p-6 sm:p-8 mb-6">
                <p className="text-sm text-muted-foreground mb-2">Status</p>
                <h2 className="text-2xl sm:text-3xl font-bold text-primary mb-4">
                  {typeof result.state === 'string' ? result.state.replace(/_/g, ' ') : 'Unable to determine'}
                </h2>
                <p className="text-sm sm:text-base text-muted-foreground leading-relaxed max-w-2xl">
                  {typeof result.explanation === 'string'
                    ? result.explanation
                    : 'Based on your income information, we have determined your tax classification.'}
                </p>
              </div>

              <div className="space-y-3 mb-8">
                <Button className="w-full sm:w-auto" onClick={() => setStep('income')}>
                  View Tax Calculations <ArrowRight className="w-4 h-4 ml-2" />
                </Button>
              </div>
            </Card>
          )}

          {/* Calculation Results */}
          {calculation && (
            <div className="space-y-6">
              {/* Summary Card */}
              <Card className="p-6 sm:p-8">
                <h1 className="text-2xl sm:text-3xl font-bold text-foreground mb-6">Your Tax Comparison</h1>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-8">
                  <div className="bg-muted/50 rounded-lg p-4 sm:p-6">
                    <p className="text-xs sm:text-sm text-muted-foreground mb-2">Gross Annual Income</p>
                    <p className="text-xl sm:text-2xl font-bold text-foreground">
                      {formatNaira(calculation.grossIncome)}
                    </p>
                  </div>

                  <div className="bg-muted/50 rounded-lg p-4 sm:p-6">
                    <p className="text-xs sm:text-sm text-muted-foreground mb-2">Tax Under Old System</p>
                    <p className="text-xl sm:text-2xl font-bold text-foreground">
                      {formatNaira(calculation.oldTax)}
                    </p>
                  </div>

                  <div className="bg-muted/50 rounded-lg p-4 sm:p-6">
                    <p className="text-xs sm:text-sm text-muted-foreground mb-2">Tax Under New System</p>
                    <p className="text-xl sm:text-2xl font-bold text-foreground">
                      {formatNaira(calculation.newTax)}
                    </p>
                  </div>
                </div>

                {/* Impact */}
                <div className={`p-6 rounded-xl border-2 ${
                  calculation.delta < -5
                    ? 'bg-green-50 border-green-200'
                    : calculation.delta > 5
                      ? 'bg-red-50 border-red-200'
                      : 'bg-blue-50 border-blue-200'
                }`}>
                  <p className="text-sm font-medium text-foreground mb-2">Impact</p>
                  <p className={`text-2xl sm:text-3xl font-bold ${
                    calculation.delta < -5
                      ? 'text-green-700'
                      : calculation.delta > 5
                        ? 'text-red-700'
                        : 'text-blue-700'
                  }`}>
                    {calculation.delta < 0 ? '✓ You save' : calculation.delta > 0 ? '⚠ You pay more' : 'No change'}
                    {' '}
                    {formatNaira(Math.abs(calculation.newTax - calculation.oldTax))}
                    {' '}
                    ({calculation.delta.toFixed(1)}%)
                  </p>
                  <p className="text-xs sm:text-sm text-muted-foreground mt-2">
                    Monthly difference: {formatNaira(Math.abs(calculation.monthlyDifference))}
                  </p>
                </div>

                {/* Monthly Breakdown */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mt-8">
                  <div className="bg-card border border-border rounded-lg p-4">
                    <p className="text-sm font-medium text-foreground mb-3">Old System (Monthly)</p>
                    <p className="text-xl sm:text-2xl font-bold text-foreground">
                      {formatNaira(calculation.monthlyOldTax)}
                    </p>
                  </div>

                  <div className="bg-card border border-border rounded-lg p-4">
                    <p className="text-sm font-medium text-foreground mb-3">New System (Monthly)</p>
                    <p className="text-xl sm:text-2xl font-bold text-foreground">
                      {formatNaira(calculation.monthlyNewTax)}
                    </p>
                  </div>
                </div>
              </Card>

              {/* Next Steps */}
              <Card className="p-6 sm:p-8 bg-blue-50 border border-blue-200">
                <div className="flex gap-4">
                  <Info className="w-5 h-5 text-blue-600 flex-shrink-0 mt-1" />
                  <div>
                    <h3 className="font-semibold text-blue-900 mb-2">Disclaimer</h3>
                    <p className="text-sm text-blue-800 mb-3">
                      These calculations are approximations based on the information provided. They are not exact tax advice and should not be treated as such. Please consult with a qualified tax professional for precise calculations tailored to your specific situation.
                    </p>
                    <a href="https://www.nrs.gov.ng/" target="_blank" rel="noopener noreferrer" className="text-sm font-medium text-blue-600 hover:underline">
                      Learn more from NRS
                    </a>
                  </div>
                </div>
              </Card>

              {/* Action Buttons */}
              <div className="flex flex-col sm:flex-row gap-3">
                <Button
                  variant="outline"
                  className="flex-1 bg-transparent"
                  onClick={() => {
                    setStep('status')
                    setShowResults(false)
                    setResult(null)
                    setCalculation(null)
                  }}
                >
                  Start Over
                </Button>
                <Button className="flex-1">
                  Get Action Plan <ArrowRight className="w-4 h-4 ml-2" />
                </Button>
              </div>
            </div>
          )}
        </div>
      </div>
    )
  }

  return null
}
