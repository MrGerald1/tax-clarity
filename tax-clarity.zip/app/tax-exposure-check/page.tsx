"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Navbar } from "@/components/shared/navbar"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { determineResponsibilityState, type Module1Input } from "@/lib/state-machines/module1-branching"
import { saveCalculationToSession } from "@/lib/session-manager"
import { ArrowRight, ArrowLeft, Info } from "lucide-react"

type QuestionKey =
  | "hasIncome"
  | "incomeType"
  | "incomeAmount"
  | "employmentStatus"
  | "businessTurnover"
  | "businessAssets"

interface Question {
  id: QuestionKey
  question: string
  description: string
  type: "yes-no" | "select" | "number"
  options?: Array<{ value: string; label: string; description?: string }>
  unit?: string
  showIf?: (answers: Partial<Module1Input>) => boolean
}

const QUESTIONS: Question[] = [
  {
    id: "hasIncome",
    question: "Do you have any income in Nigeria?",
    description: "This includes salary, freelance income, business profit, or investments.",
    type: "yes-no",
  },
  {
    id: "incomeType",
    question: "What is your primary income type?",
    description: "Select the main source of your income.",
    type: "select",
    showIf: (ans) => ans.hasIncome === true,
    options: [
      { value: "salary", label: "Salary from employer (PAYE)", description: "Fixed or variable salary from an employer" },
      { value: "freelance", label: "Freelance or contract work", description: "Income from clients/projects, not employed" },
      { value: "business", label: "Business ownership", description: "Own a registered or unregistered business" },
      { value: "pos", label: "POS merchant commission", description: "Earn from point-of-sale transactions" },
      { value: "multiple", label: "Multiple roles (employed + self-employed, etc.)", description: "Combine salary with freelance, business, or POS income" },
    ],
  },
  {
    id: "employmentStatus",
    question: "What best describes your employment situation?",
    description: "This helps us understand your tax responsibilities.",
    type: "select",
    showIf: (ans) => ans.incomeType === "salary" || ans.incomeType === "multiple",
    options: [
      { value: "employed", label: "Employed full-time", description: "Single employer, regular salary" },
      { value: "multiemployed", label: "Multiple employers", description: "Work for more than one employer" },
      { value: "contractual", label: "Contract/temporary employment", description: "Fixed-term contract role" },
    ],
  },
  {
    id: "incomeAmount",
    question: "What is your gross annual income from all sources?",
    description: "Enter your total gross income (before tax and deductions). The ₦800,000 threshold determines if you must file.",
    type: "number",
    unit: "₦",
    showIf: (ans) => ans.hasIncome === true,
  },
  {
    id: "businessTurnover",
    question: "What is your business turnover?",
    description: "Total income before expenses (relevant if you're a business owner).",
    type: "number",
    unit: "₦",
    showIf: (ans) => ans.incomeType === "business" || ans.incomeType === "multiple",
  },
  {
    id: "businessAssets",
    question: "Do you own business assets worth over ₦250 million?",
    description: "This affects your tax category.",
    type: "yes-no",
    showIf: (ans) => ans.incomeType === "business" || ans.incomeType === "multiple",
  },
]

export default function TaxExposureCheck() {
  const router = useRouter()
  const [currentStep, setCurrentStep] = useState(0)
  const [answers, setAnswers] = useState<Partial<Module1Input>>({})
  const [showResult, setShowResult] = useState(false)
  const [result, setResult] = useState<string | null>(null)

  const visibleQuestions = QUESTIONS.filter(
    (q) => !q.showIf || q.showIf(answers)
  )
  const currentQuestion = visibleQuestions[currentStep]
  const progress = ((currentStep + 1) / visibleQuestions.length) * 100

  const handleAnswer = (value: any) => {
    const newAnswers = { ...answers, [currentQuestion.id]: value }
    setAnswers(newAnswers)

    if (currentStep < visibleQuestions.length - 1) {
      setCurrentStep(currentStep + 1)
    } else {
      // Calculate result
      const outcome = determineResponsibilityState(newAnswers as Module1Input)
      setResult(outcome)
      saveCalculationToSession("module1", newAnswers, outcome)
      setShowResult(true)
    }
  }

  const handleBack = () => {
    if (currentStep > 0) {
      setCurrentStep(currentStep - 1)
    }
  }

  if (showResult && result) {
    return (
      <div className="min-h-screen bg-background">
        <Navbar />
        <div className="container max-w-3xl mx-auto px-4 py-12">
          <Card className="p-8 md:p-12">
            <div className="text-center mb-8">
              <h1 className="text-3xl font-bold text-foreground mb-4">Your Tax Exposure</h1>
              <p className="text-muted-foreground">
                Based on your income and situation, here's what we found:
              </p>
            </div>

            <div className="bg-gradient-to-br from-primary/10 to-secondary/10 border border-primary/20 rounded-xl p-8 mb-8 text-center">
              <p className="text-sm text-muted-foreground mb-2">Your Status</p>
              <p className="text-3xl font-bold text-primary mb-4">{result}</p>
              <p className="text-muted-foreground max-w-2xl mx-auto leading-relaxed">
                {result === "EMPLOYER_HANDLES_TAX" && "Your employer withholds and remits your tax. You may not need to file separately unless you have other income sources."}
                {result === "NO_TAX_ACTION_REQUIRED" && "Your income is below the taxable threshold. You have no filing obligations unless circumstances change."}
                {result === "MUST_FILE_ANNUALLY" && "You must file a tax return by 31 March each year. This applies to self-employed, business owners, and those with additional income."}
                {result === "EXEMPT_BUT_SHOULD_REGISTER" && "While exempt from tax, you should register with NRS for compliance and future-proofing."}
                {result === "AT_RISK_OF_NON_COMPLIANCE" && "Your situation requires immediate attention. Consider filing or regularizing your status to avoid penalties."}
              </p>
            </div>

            <div className="space-y-4 mb-8">
              <h2 className="text-lg font-semibold text-foreground">Next Steps</h2>
              <Button 
                className="w-full" 
                onClick={() => router.push("/tax-impact-calculator")}
              >
                See Your Tax Impact (Old vs New) <ArrowRight className="ml-2 w-4 h-4" />
              </Button>
              <Button 
                variant="outline" 
                className="w-full bg-transparent"
                onClick={() => router.push("/tax-optimization")}
              >
                Get Action Plan <ArrowRight className="ml-2 w-4 h-4" />
              </Button>
            </div>

            <div className="bg-blue-50 border border-blue-200 rounded-lg p-6">
              <div className="flex gap-3">
                <Info className="w-5 h-5 text-blue-600 flex-shrink-0 mt-0.5" />
                <div className="text-sm text-blue-900">
                  <p className="font-semibold mb-1">Learn More</p>
                  <p>Visit <a href="https://www.nrs.gov.ng/" target="_blank" rel="noopener noreferrer" className="underline font-medium hover:no-underline">Nigeria Revenue Service (NRS)</a> for official tax rules and deadlines.</p>
                </div>
              </div>
            </div>
          </Card>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <div className="container max-w-3xl mx-auto px-4 py-12">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-foreground mb-2">Tax Exposure Check</h1>
          <p className="text-muted-foreground">
            Quick questionnaire to understand your tax situation. ~2-3 minutes.
          </p>
        </div>

        <Card className="p-8">
          {/* Progress */}
          <div className="mb-8">
            <div className="flex justify-between items-center mb-3">
              <span className="text-sm font-medium text-muted-foreground">
                Question {currentStep + 1} of {visibleQuestions.length}
              </span>
              <span className="text-sm font-medium text-muted-foreground">
                {Math.round(progress)}%
              </span>
            </div>
            <Progress value={progress} className="h-2" />
          </div>

          {/* Question */}
          <div className="mb-8">
            <h2 className="text-2xl font-bold text-foreground mb-2">{currentQuestion.question}</h2>
            <p className="text-muted-foreground">{currentQuestion.description}</p>
          </div>

          {/* Answer Options */}
          <div className="space-y-3 mb-8">
            {currentQuestion.type === "yes-no" && (
              <div className="flex gap-3">
                <Button
                  variant={answers[currentQuestion.id] === true ? "default" : "outline"}
                  className="flex-1"
                  onClick={() => handleAnswer(true)}
                >
                  Yes
                </Button>
                <Button
                  variant={answers[currentQuestion.id] === false ? "default" : "outline"}
                  className="flex-1"
                  onClick={() => handleAnswer(false)}
                >
                  No
                </Button>
              </div>
            )}

            {currentQuestion.type === "select" && currentQuestion.options && (
              <div className="space-y-2">
                {currentQuestion.options.map((opt) => (
                  <button
                    key={opt.value}
                    onClick={() => handleAnswer(opt.value)}
                    className={`w-full text-left p-4 rounded-lg border-2 transition-all ${
                      answers[currentQuestion.id] === opt.value
                        ? "border-primary bg-primary/5"
                        : "border-border hover:border-primary/50 bg-card"
                    }`}
                  >
                    <p className="font-semibold text-foreground">{opt.label}</p>
                    {opt.description && (
                      <p className="text-sm text-muted-foreground mt-1">{opt.description}</p>
                    )}
                  </button>
                ))}
              </div>
            )}

            {currentQuestion.type === "number" && (
              <div className="space-y-3">
                <input
                  type="number"
                  placeholder="Enter amount"
                  value={answers[currentQuestion.id] || ""}
                  onChange={(e) => setAnswers({ ...answers, [currentQuestion.id]: parseFloat(e.target.value) || 0 })}
                  className="w-full px-4 py-3 rounded-lg border border-border bg-card text-foreground placeholder-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary"
                />
                {currentQuestion.unit && (
                  <p className="text-sm text-muted-foreground">{currentQuestion.unit}</p>
                )}
                <Button
                  className="w-full"
                  onClick={() => handleAnswer(answers[currentQuestion.id])}
                  disabled={!answers[currentQuestion.id]}
                >
                  Continue
                </Button>
              </div>
            )}
          </div>

          {/* Navigation */}
          <div className="flex gap-3">
            <Button
              variant="outline"
              onClick={handleBack}
              disabled={currentStep === 0}
              className="flex-1 bg-transparent"
            >
              <ArrowLeft className="w-4 h-4 mr-2" /> Back
            </Button>
          </div>
        </Card>
      </div>
    </div>
  )
}
