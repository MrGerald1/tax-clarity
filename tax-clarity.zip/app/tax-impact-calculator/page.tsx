"use client"

import { useState, useEffect, Suspense } from "react"
import { useRouter } from "next/navigation"
import { Navbar } from "@/components/shared/navbar"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { ShareButtons } from "@/components/shared/share-buttons"
import { MultiSourceIncomeInput } from "@/components/shared/multi-source-income-input"
import { SessionBootstrapModal } from "@/components/shared/session-bootstrap-modal"
import { TaxBreakdownDetails } from "@/components/shared/tax-breakdown-details"
import { calculateNewSystemMultiSource, calculateOldSystemMultiSource } from "@/lib/calculations/multi-source-calculator"
import { getSessionData, saveCalculationToSession } from "@/lib/session-manager"
import { formatNaira } from "@/lib/formatters"
import { IncomeSource, IncomeSourceType, TaxCalculationInput } from "@/lib/types/income"
import { ArrowRight, AlertCircle, ArrowLeft } from "lucide-react"
import Link from "next/link"

interface TaxComparison {
  newSystem: { tax: number; effectiveRate: number; breakdown: any[] }
  oldSystem: { tax: number; effectiveRate: number }
  delta: number
  status: "BETTER_OFF" | "WORSE_OFF" | "UNAFFECTED"
}

export default function TaxImpactCalculator() {
  const router = useRouter()
  const [step, setStep] = useState<"input" | "result" | "details">("input")
  const [needsBootstrap, setNeedsBootstrap] = useState(false)
  const [comparison, setComparison] = useState<TaxComparison | null>(null)
  const [selectedRoles, setSelectedRoles] = useState<IncomeSourceType[]>([])
  const [incomeSources, setIncomeSources] = useState<IncomeSource[]>([])
  const [deductions, setDeductions] = useState({
    rent: 0,
    nhf: 0,
    nhis: 0,
    lifeInsurance: 0,
  })

  // Load session data on mount
  useEffect(() => {
    const sessionData = getSessionData()
    if (sessionData?.module1?.input) {
      const module1 = sessionData.module1.input
      const roles = module1.incomeType ? ([module1.incomeType] as IncomeSourceType[]) : []
      if (module1.businessTurnover && !roles.includes("business")) {
        roles.push("business")
      }
      setSelectedRoles(roles)

      const sources: IncomeSource[] = []
      if (module1.incomeAmount) {
        sources.push({
          id: "primary",
          type: (module1.incomeType as IncomeSourceType) || "salary",
          label: module1.incomeType === "salary" ? "Primary Salary" : "Primary Income",
          annualAmount: module1.incomeAmount,
          details: {},
        })
      }
      setIncomeSources(sources)
    } else {
      // Bootstrap required
      setNeedsBootstrap(true)
    }
  }, [])

  const handleBootstrapComplete = (data: { grossAnnualIncome: number; roles: string[] }) => {
    setSelectedRoles(data.roles as IncomeSourceType[])
    const sources: IncomeSource[] = data.roles.map((role, idx) => ({
      id: `${role}-${idx}`,
      type: role as IncomeSourceType,
      label: role.charAt(0).toUpperCase() + role.slice(1),
      annualAmount: idx === 0 ? data.grossAnnualIncome : 0,
      details: {},
    }))
    setIncomeSources(sources)
    setNeedsBootstrap(false)
  }

  const handleCalculate = () => {
    if (incomeSources.length === 0 || incomeSources.every((s) => s.annualAmount === 0)) {
      alert("Please enter at least one income amount")
      return
    }

    const input: TaxCalculationInput = {
      grossAnnualIncome: incomeSources.reduce((sum, s) => sum + s.annualAmount, 0),
      incomeSources: incomeSources.filter((s) => s.annualAmount > 0),
      deductions,
    }

    const newResult = calculateNewSystemMultiSource(input)
    const oldResult = calculateOldSystemMultiSource(input)

    const delta = newResult.tax - oldResult.tax
    let status: "BETTER_OFF" | "WORSE_OFF" | "UNAFFECTED" = "UNAFFECTED"
    const deltaPercent = (delta / input.grossAnnualIncome) * 100

    if (deltaPercent < -5) status = "BETTER_OFF"
    else if (deltaPercent > 5) status = "WORSE_OFF"

    const result: TaxComparison = {
      newSystem: {
        tax: newResult.tax,
        effectiveRate: newResult.effectiveRate,
        breakdown: newResult.breakdown,
      },
      oldSystem: {
        tax: oldResult.tax,
        effectiveRate: oldResult.effectiveRate,
      },
      delta,
      status,
    }

    setComparison(result)
    saveCalculationToSession(2, input, result)
    setStep("result")
  }

  if (needsBootstrap) {
    return (
      <>
        <Navbar />
        <SessionBootstrapModal
          title="Let's determine your tax impact"
          description="We need your income details to compare the old vs new tax system."
          onComplete={handleBootstrapComplete}
        />
      </>
    )
  }

  if (step === "result" && comparison) {
    const monthlyNew = comparison.newSystem.tax / 12
    const monthlyOld = comparison.oldSystem.tax / 12
    const monthlyDelta = comparison.delta / 12

    return (
      <div className="min-h-screen bg-background">
        <Navbar />
        <div className="container max-w-4xl mx-auto px-4 py-12">
          <Button variant="ghost" className="mb-6" onClick={() => setStep("input")}>
            <ArrowLeft className="w-4 h-4 mr-2" /> Back to Calculator
          </Button>

          <div className="mb-8">
            <h1 className="text-3xl font-bold text-foreground mb-2">Your Tax Impact</h1>
            <p className="text-muted-foreground">Old system vs new system comparison</p>
          </div>

          {/* Main Comparison Card */}
          <Card className="p-8 mb-8">
            <div
              className={`rounded-xl p-8 text-center mb-8 ${
                comparison.status === "BETTER_OFF"
                  ? "bg-green-100 border border-green-300"
                  : comparison.status === "WORSE_OFF"
                    ? "bg-orange-100 border border-orange-300"
                    : "bg-blue-100 border border-blue-300"
              }`}
            >
              <p className="text-sm font-medium mb-2">Your Annual Impact</p>
              <p
                className={`text-4xl font-bold mb-4 ${
                  comparison.status === "BETTER_OFF"
                    ? "text-green-700"
                    : comparison.status === "WORSE_OFF"
                      ? "text-orange-700"
                      : "text-blue-700"
                }`}
              >
                {comparison.status === "BETTER_OFF" ? "Saving" : "Paying more"} {formatNaira(Math.abs(comparison.delta))}
              </p>
              <p
                className={`text-sm ${
                  comparison.status === "BETTER_OFF"
                    ? "text-green-600"
                    : comparison.status === "WORSE_OFF"
                      ? "text-orange-600"
                      : "text-blue-600"
                }`}
              >
                ({formatNaira(Math.abs(monthlyDelta))} per month)
              </p>
            </div>

            {/* Comparison Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
              <div>
                <p className="text-sm font-medium text-muted-foreground mb-2">Old System (Annual)</p>
                <p className="text-3xl font-bold text-foreground mb-1">{formatNaira(comparison.oldSystem.tax)}</p>
                <p className="text-xs text-muted-foreground">{comparison.oldSystem.effectiveRate.toFixed(2)}% effective rate</p>
                <p className="text-sm font-medium text-muted-foreground mt-4">Monthly: {formatNaira(monthlyOld)}</p>
              </div>
              <div>
                <p className="text-sm font-medium text-muted-foreground mb-2">New System (Annual)</p>
                <p className="text-3xl font-bold text-foreground mb-1">{formatNaira(comparison.newSystem.tax)}</p>
                <p className="text-xs text-muted-foreground">{comparison.newSystem.effectiveRate.toFixed(2)}% effective rate</p>
                <p className="text-sm font-medium text-muted-foreground mt-4">Monthly: {formatNaira(monthlyNew)}</p>
              </div>
            </div>

            {/* Disclaimer */}
            <Alert className="mb-8 border-amber-200 bg-amber-50">
              <AlertCircle className="h-4 w-4 text-amber-600" />
              <AlertDescription className="text-amber-900">
                <strong>Important:</strong> These calculations are approximations. For precise figures, consult a tax advisor. Monitor your actual salary in the coming months to verify accuracy.
              </AlertDescription>
            </Alert>

            {/* Tax Breakdown */}
            <div className="mb-8">
              <TaxBreakdownDetails breakdown={comparison.newSystem.breakdown} system="new" />
            </div>

            {/* Share Section */}
            <div className="bg-muted/30 rounded-lg p-6 mb-8">
              <h2 className="text-lg font-bold text-foreground mb-4">Share Your Results</h2>
              <ShareButtons
                title="My Tax Impact Analysis"
                description={`I just calculated my tax impact: ${comparison.status === "BETTER_OFF" ? "Saving" : "Paying more"} ${formatNaira(Math.abs(comparison.delta))} annually under Nigeria's new tax law`}
              />
            </div>

            {/* Next Actions */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <Link href="/tax-optimization" className="w-full">
                <Button className="w-full" size="lg">
                  Get Your Action Plan <ArrowRight className="ml-2 w-4 h-4" />
                </Button>
              </Link>
              <Button variant="outline" className="w-full bg-transparent" size="lg" onClick={() => setStep("input")}>
                Recalculate
              </Button>
            </div>
          </Card>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <div className="container max-w-3xl mx-auto px-4 py-12">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-foreground mb-2">Tax Impact Calculator</h1>
          <p className="text-muted-foreground">Compare your tax under the old vs new system</p>
        </div>

        <Card className="p-8">
          <form
            onSubmit={(e) => {
              e.preventDefault()
              handleCalculate()
            }}
            className="space-y-8"
          >
            {/* Income Sources */}
            <div>
              <h2 className="text-lg font-semibold text-foreground mb-4">Your Income Sources</h2>
              <MultiSourceIncomeInput
                selectedRoles={selectedRoles}
                incomeSources={incomeSources}
                onSourcesChange={setIncomeSources}
              />
            </div>

            {/* Deductions */}
            <div className="border-t border-border pt-8">
              <h2 className="text-lg font-semibold text-foreground mb-4">Deductions & Contributions</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 space-y-4">
                <div>
                  <label className="block text-sm font-medium text-foreground mb-2">Rent Relief (₦)</label>
                  <input
                    type="number"
                    value={deductions.rent}
                    onChange={(e) => setDeductions({ ...deductions, rent: parseFloat(e.target.value) || 0 })}
                    placeholder="Annual rent (capped at 20% or ₦500k)"
                    className="w-full px-4 py-2 text-sm border border-border rounded bg-card text-foreground"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-foreground mb-2">NHF (₦)</label>
                  <input
                    type="number"
                    value={deductions.nhf}
                    onChange={(e) => setDeductions({ ...deductions, nhf: parseFloat(e.target.value) || 0 })}
                    placeholder="0"
                    className="w-full px-4 py-2 text-sm border border-border rounded bg-card text-foreground"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-foreground mb-2">NHIS (₦)</label>
                  <input
                    type="number"
                    value={deductions.nhis}
                    onChange={(e) => setDeductions({ ...deductions, nhis: parseFloat(e.target.value) || 0 })}
                    placeholder="0"
                    className="w-full px-4 py-2 text-sm border border-border rounded bg-card text-foreground"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-foreground mb-2">Life Insurance (₦)</label>
                  <input
                    type="number"
                    value={deductions.lifeInsurance}
                    onChange={(e) => setDeductions({ ...deductions, lifeInsurance: parseFloat(e.target.value) || 0 })}
                    placeholder="0"
                    className="w-full px-4 py-2 text-sm border border-border rounded bg-card text-foreground"
                  />
                </div>
              </div>
            </div>

            {/* Submit */}
            <div className="flex gap-3 pt-4">
              <Button type="submit" size="lg" className="flex-1">
                Calculate Impact <ArrowRight className="ml-2 w-4 h-4" />
              </Button>
            </div>
          </form>
        </Card>
      </div>
    </div>
  )
}
