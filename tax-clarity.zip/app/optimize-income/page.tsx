"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { Navbar } from "@/components/shared/navbar"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { generateActions } from "@/lib/actions/action-generator"
import { saveCalculationToSession, getSessionData } from "@/lib/session-manager"
import { ArrowRight, ArrowLeft } from "lucide-react"
import type { ActionRole } from "@/lib/actions/action-generator"

type Step = "role-select" | "outcome-select" | "income-select" | "result"

export default function OptimizeIncome() {
  const router = useRouter()
  const [step, setStep] = useState<Step>("role-select")
  const [selectedRole, setSelectedRole] = useState<ActionRole | null>(null)
  const [selectedOutcome, setSelectedOutcome] = useState<string | null>(null)
  const [income, setIncome] = useState<number>(0)
  const [hasModule2Data, setHasModule2Data] = useState(false)
  const [stepsToShow, setStepsToShow] = useState<Step[]>(["role-select", "outcome-select", "income-select", "result"])

  useEffect(() => {
    const sessionData = getSessionData()

    if (sessionData && sessionData.module2) {
      const module2Result = sessionData.module2
      const module2Outcome = module2Result.resultData.outcome

      // Pre-fill data from Module 2
      setSelectedOutcome(module2Outcome.state)
      setIncome(module2Result.input.finalIncome || 0)
      setHasModule2Data(true)

      // Skip to role selection (user still needs to select their role/persona)
      setStepsToShow(["role-select", "result"])
      setStep("role-select")
    }
  }, [])

  const roles: Array<{ value: ActionRole; label: string; description: string }> = [
    {
      value: "salary_earner",
      label: "Salary Earner",
      description: "Employed with fixed salary and benefits",
    },
    {
      value: "freelancer",
      label: "Freelancer / Self-Employed",
      description: "Contract work or independent service provider",
    },
    {
      value: "business_owner",
      label: "Business Owner",
      description: "Own and operate a business",
    },
    {
      value: "employer_hr",
      label: "HR / Employer",
      description: "Managing employee payroll and tax",
    },
  ]

  const outcomes = [
    { value: "UNAFFECTED_AND_COMPLIANT", label: "Unaffected (No change)" },
    { value: "NET_BENEFICIARY", label: "Better Off (Saving money)" },
    { value: "WORSE_OFF_EMPLOYER_CAN_FIX", label: "Worse Off - Employer Can Help" },
    { value: "WORSE_OFF_SELF_OPTIMIZATION_POSSIBLE", label: "Worse Off - I Can Optimize" },
    { value: "OVERPAYING", label: "Overpaying Tax" },
    { value: "AT_RISK", label: "At Risk of Non-Compliance" },
  ]

  const currentStepIndex = stepsToShow.indexOf(step)
  const progress = ((currentStepIndex + 1) / stepsToShow.length) * 100

  const handleNext = () => {
    if (step === "role-select" && selectedRole) {
      if (hasModule2Data) {
        // Skip directly to result generation
        generateAndNavigate()
      } else {
        setStep("outcome-select")
      }
    } else if (step === "outcome-select" && selectedOutcome) {
      setStep("income-select")
    } else if (step === "income-select" && income > 0 && selectedRole && selectedOutcome) {
      generateAndNavigate()
    }
  }

  const generateAndNavigate = () => {
    if (!selectedRole || !selectedOutcome || income === 0) return

    const actionsResult = generateActions(selectedRole, selectedOutcome as any, income, 0, 0, {
      employerFlexibility: "PARTIAL",
    })

    const calculationId = saveCalculationToSession(
      3,
      { role: selectedRole, outcome: selectedOutcome, income },
      actionsResult,
    )

    router.push(`/optimize-income/result/${calculationId}`)
  }

  const handleBack = () => {
    if (currentStepIndex > 0) {
      setStep(stepsToShow[currentStepIndex - 1])
    }
  }

  const canProceed = (): boolean => {
    switch (step) {
      case "role-select":
        return !!selectedRole
      case "outcome-select":
        return !!selectedOutcome
      case "income-select":
        return income > 0
      default:
        return false
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-background to-muted/20">
      <Navbar />

      <div className="container max-w-2xl mx-auto px-4 py-8 sm:py-16">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold mb-2">What Should I Do?</h1>
          <p className="text-muted-foreground">
            Get personalized action recommendations. {stepsToShow.length} quick{" "}
            {stepsToShow.length === 1 ? "step" : "steps"}.
          </p>
          {hasModule2Data && (
            <p className="text-sm text-teal-600 dark:text-teal-400 mt-2">
              ✓ We've carried over your tax outcome and income from Module 2
            </p>
          )}
        </div>

        {/* Progress */}
        <div className="mb-8">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm font-medium text-muted-foreground">
              Step {currentStepIndex + 1} of {stepsToShow.length}
            </span>
            <span className="text-sm font-medium text-primary">{Math.round(progress)}%</span>
          </div>
          <Progress value={progress} className="h-2" />
        </div>

        {/* Step Content */}
        <Card className="p-6 sm:p-8 mb-8 bg-card">
          {/* Role Selection */}
          {step === "role-select" && (
            <div>
              <h2 className="text-xl sm:text-2xl font-semibold mb-2">What's your situation?</h2>
              <p className="text-muted-foreground text-sm mb-6">We'll customize recommendations for you.</p>
              <div className="space-y-2">
                {roles.map((role) => (
                  <Button
                    key={role.value}
                    variant={selectedRole === role.value ? "default" : "outline"}
                    onClick={() => setSelectedRole(role.value)}
                    className="w-full justify-start h-auto py-3 px-4 text-left"
                  >
                    <div>
                      <div className="font-medium">{role.label}</div>
                      <div className="text-xs text-muted-foreground mt-1">{role.description}</div>
                    </div>
                  </Button>
                ))}
              </div>
            </div>
          )}

          {/* Outcome Selection */}
          {step === "outcome-select" && (
            <div>
              <h2 className="text-xl sm:text-2xl font-semibold mb-2">What's your tax outcome?</h2>
              <p className="text-muted-foreground text-sm mb-6">From Module 2, or your estimate.</p>
              <div className="space-y-2">
                {outcomes.map((outcome) => (
                  <Button
                    key={outcome.value}
                    variant={selectedOutcome === outcome.value ? "default" : "outline"}
                    onClick={() => setSelectedOutcome(outcome.value)}
                    className="w-full justify-start h-auto py-3 px-4 text-left"
                  >
                    <span className="font-medium">{outcome.label}</span>
                  </Button>
                ))}
              </div>
            </div>
          )}

          {/* Income Selection */}
          {step === "income-select" && (
            <div>
              <h2 className="text-xl sm:text-2xl font-semibold mb-2">What's your approximate annual income?</h2>
              <p className="text-muted-foreground text-sm mb-6">
                For better personalized recommendations. Estimate if needed.
              </p>
              <div className="flex items-center gap-2">
                <span className="text-lg font-medium text-muted-foreground">₦</span>
                <input
                  type="number"
                  value={income || ""}
                  onChange={(e) => setIncome(Number.parseInt(e.target.value) || 0)}
                  placeholder="2,000,000"
                  className="flex-1 px-4 py-3 border border-border rounded-lg bg-background text-foreground text-lg"
                />
              </div>
            </div>
          )}

          {/* Navigation */}
          <div className="flex gap-3 mt-8">
            <Button
              variant="outline"
              onClick={handleBack}
              disabled={currentStepIndex === 0}
              className="flex-1 bg-transparent"
            >
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back
            </Button>
            <Button onClick={handleNext} disabled={!canProceed()} className="flex-1">
              {step === "income-select" || (step === "role-select" && hasModule2Data) ? (
                <>
                  Get Actions <ArrowRight className="w-4 h-4 ml-2" />
                </>
              ) : (
                <>
                  Next <ArrowRight className="w-4 h-4 ml-2" />
                </>
              )}
            </Button>
          </div>
        </Card>
      </div>
    </div>
  )
}
