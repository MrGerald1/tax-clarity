"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { Navbar } from "@/components/shared/navbar"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { getCalculationFromSession } from "@/lib/session-manager"
import { Share2, ArrowRight, AlertCircle, Zap, Target } from "lucide-react"
import type { Action } from "@/lib/actions/action-generator"

const effortColors = {
  low: "bg-green-100 text-green-700 dark:bg-green-950 dark:text-green-300",
  medium: "bg-yellow-100 text-yellow-700 dark:bg-yellow-950 dark:text-yellow-300",
  high: "bg-red-100 text-red-700 dark:bg-red-950 dark:text-red-300",
}

const actorIcons = {
  user: "👤",
  employer: "🏢",
  accountant: "📊",
}

export default function Module3Result({ params }: { params: { id: string } }) {
  const router = useRouter()
  const [calculation, setCalculation] = useState<any>(null)
  const [loading, setLoading] = useState(true)
  const [expandedActions, setExpandedActions] = useState<Set<string>>(new Set())

  useEffect(() => {
    const calc = getCalculationFromSession(params.id)
    if (calc) {
      setCalculation(calc)
    }
    setLoading(false)
  }, [params.id])

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <div className="w-8 h-8 rounded-full border-2 border-primary border-t-transparent animate-spin mx-auto mb-4"></div>
          <p className="text-muted-foreground">Generating your action plan...</p>
        </div>
      </div>
    )
  }

  if (!calculation) {
    return (
      <div className="min-h-screen bg-background">
        <Navbar />
        <div className="container max-w-3xl mx-auto px-4 py-16">
          <Card className="p-8 text-center">
            <p className="text-muted-foreground mb-4">Result not found. Please start over.</p>
            <Button onClick={() => router.push("/optimize-income")}>Start Over</Button>
          </Card>
        </div>
      </div>
    )
  }

  const result = calculation.resultData
  const actions: Action[] = result.actions || []
  const urgency = result.urgency

  const urgencyColors = {
    low: "bg-green-50 dark:bg-green-950 border-green-200 dark:border-green-800",
    medium: "bg-yellow-50 dark:bg-yellow-950 border-yellow-200 dark:border-yellow-800",
    high: "bg-red-50 dark:bg-red-950 border-red-200 dark:border-red-800",
  }

  const urgencyText = {
    low: "No urgent action needed",
    medium: "Review and plan within 30 days",
    high: "Immediate action recommended",
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-background to-muted/20">
      <Navbar />

      <div className="container max-w-3xl mx-auto px-4 py-8 sm:py-16">
        {/* Header */}
        <Card className={`p-8 mb-8 border-2 ${urgencyColors[urgency]}`}>
          <div className="flex items-start gap-4">
            {urgency === "high" && <AlertCircle className="w-8 h-8 text-red-600 flex-shrink-0 mt-1" />}
            {urgency === "medium" && <Zap className="w-8 h-8 text-yellow-600 flex-shrink-0 mt-1" />}
            {urgency === "low" && <Target className="w-8 h-8 text-green-600 flex-shrink-0 mt-1" />}
            <div>
              <h1 className="text-3xl font-bold mb-2">Your Action Plan</h1>
              <p className="text-foreground text-lg">{urgencyText[urgency]}</p>
            </div>
          </div>
        </Card>

        {/* Actions List */}
        <div className="space-y-4 mb-8">
          {actions.map((action, idx) => {
            const isExpanded = expandedActions.has(action.id)

            return (
              <Card key={action.id} className="overflow-hidden bg-card">
                <button
                  onClick={() => {
                    const newExpanded = new Set(expandedActions)
                    if (isExpanded) {
                      newExpanded.delete(action.id)
                    } else {
                      newExpanded.add(action.id)
                    }
                    setExpandedActions(newExpanded)
                  }}
                  className="w-full text-left p-6 hover:bg-muted/50 transition-colors"
                >
                  <div className="flex items-start gap-4">
                    <div className="flex-1">
                      <div className="flex items-center gap-3 mb-2">
                        <span className="text-2xl">{actorIcons[action.actor]}</span>
                        <div>
                          <h3 className="font-semibold text-lg">{action.title}</h3>
                          <p className="text-sm text-muted-foreground">{action.description}</p>
                        </div>
                      </div>
                      <div className="flex gap-2 mt-3 flex-wrap">
                        <span className={`px-2 py-1 rounded text-xs font-medium ${effortColors[action.effort]}`}>
                          {action.effort === "low"
                            ? "Quick (1-2 hours)"
                            : action.effort === "medium"
                              ? "Medium (1-2 days)"
                              : "Complex (1+ week)"}
                        </span>
                        <span className="px-2 py-1 rounded text-xs font-medium bg-blue-100 text-blue-700 dark:bg-blue-950 dark:text-blue-300">
                          {action.timeline}
                        </span>
                      </div>
                    </div>
                    <div className="text-muted-foreground flex-shrink-0 text-2xl">{isExpanded ? "−" : "+"}</div>
                  </div>
                </button>

                {isExpanded && (
                  <div className="border-t border-border px-6 py-4 bg-muted/30">
                    <div className="space-y-4">
                      <div>
                        <h4 className="font-semibold text-sm mb-2">Impact</h4>
                        <p className="text-foreground text-sm">{action.impact}</p>
                      </div>
                      <div>
                        <h4 className="font-semibold text-sm mb-2">How to Implement</h4>
                        <p className="text-foreground text-sm">{action.implementation}</p>
                      </div>
                      {action.documentation && (
                        <div>
                          <h4 className="font-semibold text-sm mb-2">Documentation</h4>
                          <Button variant="outline" size="sm" className="w-full sm:w-auto bg-transparent">
                            View Guide
                          </Button>
                        </div>
                      )}
                    </div>
                  </div>
                )}
              </Card>
            )
          })}
        </div>

        {/* Action Buttons */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-8">
          <Button
            variant="outline"
            onClick={() => {
              const shareText = `I just got a personalized action plan for my Nigerian taxes. ${actions.length} actions tailored to my situation. Check yours free at TaxClarity NG`
              navigator.share?.({ title: "My Tax Action Plan", text: shareText, url: window.location.href })
            }}
            className="h-12 gap-2"
          >
            <Share2 className="w-4 h-4" />
            Share Plan
          </Button>
          <Button onClick={() => router.push("/")} className="h-12 gap-2">
            Back to Hub
            <ArrowRight className="w-4 h-4" />
          </Button>
        </div>

        {/* Next Steps CTA */}
        <Card className="p-6 bg-primary/10 border border-primary/20">
          <h3 className="font-semibold mb-3">Next Steps</h3>
          <ul className="space-y-2 text-sm">
            <li className="flex gap-2">
              <span className="font-bold text-primary flex-shrink-0">1.</span>
              <span>Review the actions above and prioritize by effort/impact</span>
            </li>
            <li className="flex gap-2">
              <span className="font-bold text-primary flex-shrink-0">2.</span>
              <span>Take the first action this week</span>
            </li>
            <li className="flex gap-2">
              <span className="font-bold text-primary flex-shrink-0">3.</span>
              <span>Share this plan with relevant people (HR, accountant, family)</span>
            </li>
          </ul>
        </Card>
      </div>
    </div>
  )
}
