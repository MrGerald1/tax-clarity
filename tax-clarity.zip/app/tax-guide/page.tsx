"use client"

import { Navbar } from "@/components/shared/navbar"
import { Footer } from "@/components/shared/footer"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import Link from "next/link"
import { ArrowRight, CheckCircle2, Users, Zap, Briefcase, TrendingUp, TrendingDown } from "lucide-react"

export default function TaxGuide() {
  return (
    <div className="min-h-screen bg-background">
      <Navbar />

      <section className="container max-w-6xl mx-auto px-4 py-16 sm:py-24">
        <div className="text-center mb-16 space-y-4">
          <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold text-foreground text-balance tracking-tight">
            Nigeria's New Tax Law Explained
          </h1>
          <p className="text-lg sm:text-xl text-muted-foreground max-w-3xl mx-auto text-balance leading-relaxed">
            Understand exactly what changed between the old and new tax systems.
          </p>
        </div>

        {/* What Changed? Section */}
        <div className="mb-20 bg-card border border-border rounded-xl p-6 sm:p-8 md:p-12">
          <h2 className="text-2xl sm:text-3xl font-bold mb-8 text-foreground">What Changed?</h2>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b-2 border-border">
                  <th className="text-left py-4 px-4 font-semibold text-foreground">Area</th>
                  <th className="text-left py-4 px-4 font-semibold text-foreground">Old System</th>
                  <th className="text-left py-4 px-4 font-semibold text-foreground">New System</th>
                </tr>
              </thead>
              <tbody>
                <tr className="border-b border-border hover:bg-muted/50 transition-colors">
                  <td className="py-4 px-4 font-medium text-foreground">CRA (Relief Allowance)</td>
                  <td className="py-4 px-4 text-muted-foreground">Applied to all</td>
                  <td className="py-4 px-4">
                    <span className="inline-block bg-red-100 text-red-700 px-3 py-1 rounded-full text-xs font-medium">
                      Removed
                    </span>
                  </td>
                </tr>
                <tr className="border-b border-border hover:bg-muted/50 transition-colors">
                  <td className="py-4 px-4 font-medium text-foreground">Rent Relief</td>
                  <td className="py-4 px-4 text-muted-foreground">Not available</td>
                  <td className="py-4 px-4">
                    <span className="inline-block bg-green-100 text-green-700 px-3 py-1 rounded-full text-xs font-medium">
                      20% cap, max ₦500k
                    </span>
                  </td>
                </tr>
                <tr className="border-b border-border hover:bg-muted/50 transition-colors">
                  <td className="py-4 px-4 font-medium text-foreground">Tax-Free Threshold</td>
                  <td className="py-4 px-4 text-muted-foreground">Unclear</td>
                  <td className="py-4 px-4">
                    <span className="inline-block bg-blue-100 text-blue-700 px-3 py-1 rounded-full text-xs font-medium">
                      ₦800,000 clear
                    </span>
                  </td>
                </tr>
                <tr className="border-b border-border hover:bg-muted/50 transition-colors">
                  <td className="py-4 px-4 font-medium text-foreground">Small Business Exemption</td>
                  <td className="py-4 px-4 text-muted-foreground">Ambiguous</td>
                  <td className="py-4 px-4">
                    <span className="inline-block bg-blue-100 text-blue-700 px-3 py-1 rounded-full text-xs font-medium">
                      Explicit rules
                    </span>
                  </td>
                </tr>
                <tr className="hover:bg-muted/50 transition-colors">
                  <td className="py-4 px-4 font-medium text-foreground">Enforcement</td>
                  <td className="py-4 px-4 text-muted-foreground">Relaxed</td>
                  <td className="py-4 px-4">
                    <span className="inline-block bg-orange-100 text-orange-700 px-3 py-1 rounded-full text-xs font-medium">
                      Stricter
                    </span>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>

        {/* Who Is Affected? */}
        <div className="mb-20">
          <h2 className="text-2xl sm:text-3xl font-bold mb-8 text-foreground">Who Is Affected?</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 lg:gap-6">
            {/* Salary Earners */}
            <Card className="p-6 border border-border">
              <div className="flex items-start justify-between mb-4">
                <div className="w-12 h-12 rounded-lg bg-primary/15 flex items-center justify-center">
                  <Users className="w-6 h-6 text-primary" />
                </div>
                <TrendingDown className="w-5 h-5 text-green-600" />
              </div>
              <h3 className="font-semibold text-foreground mb-2 text-lg">Salary Earners</h3>
              <p className="text-sm text-muted-foreground leading-relaxed">
                Most likely see lower tax, but depends on allowances and deductions. Rent relief is a new benefit.
              </p>
            </Card>

            {/* Freelancers */}
            <Card className="p-6 border border-border">
              <div className="flex items-start justify-between mb-4">
                <div className="w-12 h-12 rounded-lg bg-secondary/15 flex items-center justify-center">
                  <Zap className="w-6 h-6 text-secondary" />
                </div>
                <TrendingDown className="w-5 h-5 text-green-600" />
              </div>
              <h3 className="font-semibold text-foreground mb-2 text-lg">Freelancers & Contractors</h3>
              <p className="text-sm text-muted-foreground leading-relaxed">
                More deductions available. Rent relief is a key benefit. Clearer filing requirements.
              </p>
            </Card>

            {/* Small Businesses */}
            <Card className="p-6 border border-border">
              <div className="flex items-start justify-between mb-4">
                <div className="w-12 h-12 rounded-lg bg-accent/15 flex items-center justify-center">
                  <Briefcase className="w-6 h-6 text-accent" />
                </div>
                <TrendingUp className="w-5 h-5 text-orange-600" />
              </div>
              <h3 className="font-semibold text-foreground mb-2 text-lg">Small Businesses</h3>
              <p className="text-sm text-muted-foreground leading-relaxed">
                Exemptions up to ₦25m in turnover. Removal of CRA may benefit some. Clearer registration thresholds.
              </p>
            </Card>

            {/* POS Agents */}
            <Card className="p-6 border border-border">
              <div className="flex items-start justify-between mb-4">
                <div className="w-12 h-12 rounded-lg bg-green-600/15 flex items-center justify-center">
                  <TrendingUp className="w-6 h-6 text-green-600" />
                </div>
                <TrendingDown className="w-5 h-5 text-green-600" />
              </div>
              <h3 className="font-semibold text-foreground mb-2 text-lg">POS Agents</h3>
              <p className="text-sm text-muted-foreground leading-relaxed">
                Tax on commission only, not on transaction volume. Clearer compliance requirements.
              </p>
            </Card>

            {/* Investors */}
            <Card className="p-6 border border-border">
              <div className="flex items-start justify-between mb-4">
                <div className="w-12 h-12 rounded-lg bg-blue-600/15 flex items-center justify-center">
                  <TrendingUp className="w-6 h-6 text-blue-600" />
                </div>
                <TrendingDown className="w-5 h-5 text-orange-600" />
              </div>
              <h3 className="font-semibold text-foreground mb-2 text-lg">Investment Income</h3>
              <p className="text-sm text-muted-foreground leading-relaxed">
                Foreign income taxation rules clarified. Exchange rate conversion rules defined.
              </p>
            </Card>

            {/* Employers */}
            <Card className="p-6 border border-border">
              <div className="flex items-start justify-between mb-4">
                <div className="w-12 h-12 rounded-lg bg-purple-600/15 flex items-center justify-center">
                  <Users className="w-6 h-6 text-purple-600" />
                </div>
                <TrendingUp className="w-5 h-5 text-orange-600" />
              </div>
              <h3 className="font-semibold text-foreground mb-2 text-lg">Employers & HR</h3>
              <p className="text-sm text-muted-foreground leading-relaxed">
                Payroll impact varies across team. New deduction rules to implement. Stricter compliance.
              </p>
            </Card>
          </div>
        </div>

        {/* Key Dates Section */}
        <div className="mb-20 bg-amber-50 border border-amber-200 rounded-xl p-6 sm:p-8">
          <h2 className="text-2xl font-bold mb-8 text-foreground">Important Deadlines</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            <div className="flex gap-4">
              <div className="flex-shrink-0">
                <div className="w-3 h-3 rounded-full bg-accent mt-2"></div>
              </div>
              <div>
                <p className="font-semibold text-foreground">Personal Income Tax Filing</p>
                <p className="text-sm text-muted-foreground">31 March annually</p>
              </div>
            </div>
            <div className="flex gap-4">
              <div className="flex-shrink-0">
                <div className="w-3 h-3 rounded-full bg-accent mt-2"></div>
              </div>
              <div>
                <p className="font-semibold text-foreground">PAYE Remittance (Employers)</p>
                <p className="text-sm text-muted-foreground">By 10th of following month</p>
              </div>
            </div>
            <div className="flex gap-4">
              <div className="flex-shrink-0">
                <div className="w-3 h-3 rounded-full bg-accent mt-2"></div>
              </div>
              <div>
                <p className="font-semibold text-foreground">Company Income Tax Filing</p>
                <p className="text-sm text-muted-foreground">Last working day of 6th month after year-end</p>
              </div>
            </div>
          </div>
        </div>

        {/* Call to Action */}
        <div className="text-center mb-16">
          <h2 className="text-2xl sm:text-3xl font-bold mb-6 text-foreground">Ready to Understand Your Impact?</h2>
          <p className="text-muted-foreground mb-8 max-w-2xl mx-auto">
            Use our tax calculators to see exactly how you're affected and get personalized recommendations.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link href="/tax-exposure-check">
              <Button size="lg">
                Start Tax Exposure Check <ArrowRight className="ml-2 w-4 h-4" />
              </Button>
            </Link>
            <Link href="/tax-impact-calculator">
              <Button size="lg" variant="outline">
                Compare Old vs New System
              </Button>
            </Link>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  )
}
