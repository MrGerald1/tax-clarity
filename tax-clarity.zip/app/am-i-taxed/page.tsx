"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Navbar } from "@/components/shared/navbar"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { determineResponsibilityState, type Module1Input } from "@/lib/state-machines/module1-branching"
import { saveCalculationToSession } from "@/lib/session-manager"
import { ArrowRight, ArrowLeft } from "lucide-react"

type QuestionKey =
  | "hasIncome"
  | "incomeType"
  | "incomeAmount"
  | "employmentStatus"
  | "businessTurnover"
  | "businessAssets"

interface Question {
  id: QuestionKey
  question: string
  description: string
  type: "yes-no" | "select" | "number"
  options?: Array<{ value: string; label: string }>
  unit?: string
  showIf?: (answers: Partial<Module1Input>) => boolean
}

const QUESTIONS: Question[] = [
  {
    id: "hasIncome",
    question: "Do you have any income in Nigeria?",
    description: "This includes salary, freelance income, business profit, or investments.",
    type: "yes-no",
  },
  {
    id: "incomeType",
    question: "What is your primary income type?",
    description: "Select the main source of your income.",
    type: "select",
    showIf: (ans) => ans.hasIncome === true,
    options: [
      { value: "salary", label: "Salary from employer (PAYE)" },
      { value: "freelance", label: "Freelance or contract work" },
      { value: "business", label: "Business ownership" },
      { value: "foreign", label: "Foreign income" },
      { value: "multiple", label: "Multiple income sources" },
    ],
  },
  {
    id: "employmentStatus",
    question: "What is your employment status?",
    description: "This helps us understand your tax situation better.",
    type: "select",
    showIf: (ans) => ans.hasIncome === true,
    options: [
      { value: "employed", label: "Employed by a company" },
      { value: "self_employed", label: "Self-employed / Freelancer" },
      { value: "business_owner", label: "Business owner" },
      { value: "multiple", label: "Multiple roles" },
    ],
  },
  {
    id: "incomeAmount",
    question: "What is your approximate annual income?",
    description: "Include salary, net business profit, or freelance earnings. Estimate if needed.",
    type: "number",
    showIf: (ans) => ans.hasIncome === true && ans.incomeType !== "business",
    unit: "₦",
  },
  {
    id: "businessTurnover",
    question: "What is your business annual turnover?",
    description: "Total revenue before expenses.",
    type: "number",
    showIf: (ans) => ans.incomeType === "business" || ans.employmentStatus === "business_owner",
    unit: "₦",
  },
  {
    id: "businessAssets",
    question: "What is your approximate business asset value?",
    description: "Equipment, inventory, vehicles, property used in the business.",
    type: "number",
    showIf: (ans) => ans.incomeType === "business" || ans.employmentStatus === "business_owner",
    unit: "₦",
  },
]

export default function TaxResponsibilityFinder() {
  const router = useRouter()
  const [answers, setAnswers] = useState<Partial<Module1Input>>({})
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0)

  const visibleQuestions = QUESTIONS.filter((q) => !q.showIf || q.showIf(answers))
  const currentQuestion = visibleQuestions[currentQuestionIndex]
  const progress = ((currentQuestionIndex + 1) / visibleQuestions.length) * 100

  const handleAnswer = (key: QuestionKey, value: any) => {
    setAnswers((prev) => ({ ...prev, [key]: value }))
  }

  const handleNext = () => {
    if (currentQuestionIndex < visibleQuestions.length - 1) {
      setCurrentQuestionIndex(currentQuestionIndex + 1)
    } else {
      // Submit questionnaire
      const result = determineResponsibilityState(answers as Module1Input)
      const calculationId = saveCalculationToSession(1, answers, result)
      router.push(`/am-i-taxed/result/${calculationId}`)
    }
  }

  const handleBack = () => {
    if (currentQuestionIndex > 0) {
      setCurrentQuestionIndex(currentQuestionIndex - 1)
    }
  }

  const canAdvance = () => {
    const key = currentQuestion.id
    return answers[key] !== undefined && answers[key] !== null
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-background to-muted/20">
      <Navbar />

      <div className="container max-w-2xl mx-auto px-4 py-8 sm:py-16">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold mb-2">Am I Taxed?</h1>
          <p className="text-muted-foreground">
            Let's determine your tax responsibility status. {visibleQuestions.length} quick questions.
          </p>
        </div>

        {/* Progress */}
        <div className="mb-8">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm font-medium text-muted-foreground">
              Question {currentQuestionIndex + 1} of {visibleQuestions.length}
            </span>
            <span className="text-sm font-medium text-primary">{Math.round(progress)}%</span>
          </div>
          <Progress value={progress} className="h-2" />
        </div>

        {/* Question Card */}
        <Card className="p-6 sm:p-8 mb-8 bg-card">
          <div className="mb-6">
            <h2 className="text-xl sm:text-2xl font-semibold mb-2">{currentQuestion.question}</h2>
            <p className="text-muted-foreground text-sm">{currentQuestion.description}</p>
          </div>

          {/* Question Input */}
          <div className="space-y-4 mb-8">
            {currentQuestion.type === "yes-no" && (
              <div className="flex gap-3">
                <Button
                  variant={answers[currentQuestion.id] === true ? "default" : "outline"}
                  onClick={() => handleAnswer(currentQuestion.id, true)}
                  className="flex-1 h-12"
                >
                  Yes
                </Button>
                <Button
                  variant={answers[currentQuestion.id] === false ? "default" : "outline"}
                  onClick={() => handleAnswer(currentQuestion.id, false)}
                  className="flex-1 h-12"
                >
                  No
                </Button>
              </div>
            )}

            {currentQuestion.type === "select" && currentQuestion.options && (
              <div className="space-y-2">
                {currentQuestion.options.map((opt) => (
                  <Button
                    key={opt.value}
                    variant={answers[currentQuestion.id] === opt.value ? "default" : "outline"}
                    onClick={() => handleAnswer(currentQuestion.id, opt.value)}
                    className="w-full justify-start h-auto py-3 px-4 text-left"
                  >
                    <div>
                      <div className="font-medium">{opt.label}</div>
                    </div>
                  </Button>
                ))}
              </div>
            )}

            {currentQuestion.type === "number" && (
              <div className="flex items-center gap-2">
                <span className="text-lg font-medium text-muted-foreground">{currentQuestion.unit}</span>
                <input
                  type="number"
                  value={answers[currentQuestion.id] || ""}
                  onChange={(e) => handleAnswer(currentQuestion.id, Number.parseInt(e.target.value) || 0)}
                  placeholder="0"
                  className="flex-1 px-4 py-3 border border-border rounded-lg bg-background text-foreground text-lg"
                />
              </div>
            )}
          </div>

          {/* Navigation */}
          <div className="flex gap-3">
            <Button
              variant="outline"
              onClick={handleBack}
              disabled={currentQuestionIndex === 0}
              className="flex-1 bg-transparent"
            >
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back
            </Button>
            <Button onClick={handleNext} disabled={!canAdvance()} className="flex-1">
              {currentQuestionIndex === visibleQuestions.length - 1 ? (
                <>
                  See Results <ArrowRight className="w-4 h-4 ml-2" />
                </>
              ) : (
                <>
                  Next <ArrowRight className="w-4 h-4 ml-2" />
                </>
              )}
            </Button>
          </div>
        </Card>
      </div>
    </div>
  )
}
