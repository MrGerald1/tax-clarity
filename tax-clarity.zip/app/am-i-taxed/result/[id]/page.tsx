"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { Navbar } from "@/components/shared/navbar"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { getCalculationFromSession } from "@/lib/session-manager"
import { getStateRecommendations, type TaxResponsibilityState } from "@/lib/state-machines/module1-branching"
import { CheckCircle2, AlertCircle, Share2, ArrowRight } from "lucide-react"

const STATE_COLORS: Record<TaxResponsibilityState, { bg: string; border: string; icon: string }> = {
  NO_TAX_ACTION_REQUIRED: {
    bg: "bg-green-50 dark:bg-green-950",
    border: "border-green-200 dark:border-green-800",
    icon: "text-green-600",
  },
  EMPLOYER_HANDLES_TAX: {
    bg: "bg-blue-50 dark:bg-blue-950",
    border: "border-blue-200 dark:border-blue-800",
    icon: "text-blue-600",
  },
  MUST_FILE_ANNUALLY: {
    bg: "bg-yellow-50 dark:bg-yellow-950",
    border: "border-yellow-200 dark:border-yellow-800",
    icon: "text-yellow-600",
  },
  EXEMPT_BUT_SHOULD_REGISTER: {
    bg: "bg-orange-50 dark:bg-orange-950",
    border: "border-orange-200 dark:border-orange-800",
    icon: "text-orange-600",
  },
  AT_RISK_OF_NON_COMPLIANCE: {
    bg: "bg-red-50 dark:bg-red-950",
    border: "border-red-200 dark:border-red-800",
    icon: "text-red-600",
  },
}

export default function Module1Result({ params }: { params: { id: string } }) {
  const router = useRouter()
  const [calculation, setCalculation] = useState<any>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const calc = getCalculationFromSession(params.id)
    if (calc) {
      setCalculation(calc)
    }
    setLoading(false)
  }, [params.id])

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <div className="w-8 h-8 rounded-full border-2 border-primary border-t-transparent animate-spin mx-auto mb-4"></div>
          <p className="text-muted-foreground">Loading your result...</p>
        </div>
      </div>
    )
  }

  if (!calculation) {
    return (
      <div className="min-h-screen bg-background">
        <Navbar />
        <div className="container max-w-2xl mx-auto px-4 py-16">
          <Card className="p-8 text-center">
            <p className="text-muted-foreground mb-4">Result not found. Please start over.</p>
            <Button onClick={() => router.push("/am-i-taxed")}>Start Over</Button>
          </Card>
        </div>
      </div>
    )
  }

  const result = calculation.resultData
  const state = result.state as TaxResponsibilityState
  const colors = STATE_COLORS[state]
  const recommendations = getStateRecommendations(state)

  const stateLabels: Record<TaxResponsibilityState, string> = {
    NO_TAX_ACTION_REQUIRED: "No Tax Action Required",
    EMPLOYER_HANDLES_TAX: "Employer Handles Tax",
    MUST_FILE_ANNUALLY: "Must File Annually",
    EXEMPT_BUT_SHOULD_REGISTER: "Exempt But Should Register",
    AT_RISK_OF_NON_COMPLIANCE: "At Risk of Non-Compliance",
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-background to-muted/20">
      <Navbar />

      <div className="container max-w-3xl mx-auto px-4 py-8 sm:py-16">
        {/* Result Card */}
        <Card className={`p-8 mb-8 ${colors.bg} border-2 ${colors.border}`}>
          <div className="flex items-start gap-4 mb-6">
            <CheckCircle2 className={`w-8 h-8 ${colors.icon} flex-shrink-0 mt-1`} />
            <div>
              <h1 className="text-3xl font-bold mb-2">{stateLabels[state]}</h1>
              <p className="text-foreground text-lg">{result.explanation}</p>
            </div>
          </div>
        </Card>

        {/* Risk Level Indicator */}
        <Card className="p-6 mb-8 bg-card">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-semibold">Risk Level</h3>
            <span
              className={`px-3 py-1 rounded-full text-sm font-medium ${
                result.riskLevel === "low"
                  ? "bg-green-100 text-green-700 dark:bg-green-950 dark:text-green-300"
                  : result.riskLevel === "medium"
                    ? "bg-yellow-100 text-yellow-700 dark:bg-yellow-950 dark:text-yellow-300"
                    : "bg-red-100 text-red-700 dark:bg-red-950 dark:text-red-300"
              }`}
            >
              {result.riskLevel.charAt(0).toUpperCase() + result.riskLevel.slice(1)}
            </span>
          </div>
          <div className="h-2 bg-muted rounded-full overflow-hidden">
            <div
              className={`h-full transition-all ${
                result.riskLevel === "low"
                  ? "bg-green-500 w-1/3"
                  : result.riskLevel === "medium"
                    ? "bg-yellow-500 w-2/3"
                    : "bg-red-500 w-full"
              }`}
            ></div>
          </div>
        </Card>

        {/* Recommendations */}
        <Card className="p-6 mb-8 bg-card">
          <h3 className="font-semibold mb-4 flex items-center gap-2">
            <AlertCircle className="w-5 h-5 text-primary" />
            Recommended Next Steps
          </h3>
          <ul className="space-y-3">
            {recommendations.map((rec, idx) => (
              <li key={idx} className="flex gap-3">
                <span className="font-bold text-primary flex-shrink-0">{idx + 1}.</span>
                <span className="text-foreground">{rec}</span>
              </li>
            ))}
          </ul>
        </Card>

        {/* Action Buttons */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-8">
          <Button
            variant="outline"
            onClick={() => {
              const shareText = `I just discovered my tax status: ${stateLabels[state]}. Check yours free at TaxClarity NG - no signup needed.`
              navigator.share?.({ title: "My Tax Status", text: shareText, url: window.location.href })
            }}
            className="h-12 gap-2"
          >
            <Share2 className="w-4 h-4" />
            Share Result
          </Button>
          {result.proceedToModule2 && (
            <Button onClick={() => router.push("/compare-tax")} className="h-12 gap-2">
              See Tax Impact
              <ArrowRight className="w-4 h-4" />
            </Button>
          )}
          {!result.proceedToModule2 && (
            <Button onClick={() => router.push("/am-i-taxed")} variant="outline" className="h-12">
              Start Over
            </Button>
          )}
        </div>

        {/* Back to Hub */}
        <div className="text-center">
          <Button variant="ghost" onClick={() => router.push("/")} className="text-muted-foreground">
            Back to All Modules
          </Button>
        </div>
      </div>
    </div>
  )
}
