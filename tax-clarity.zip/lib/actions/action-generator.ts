/**
 * Module 3: Action Generator
 * Creates role-specific, actionable recommendations based on Module 2 outcome
 */

import { calculateRequiredGrossIncrease } from "@/lib/calculations/tax-new"
import type { Module2OutcomeState } from "@/lib/state-machines/module2-outcomes"

export interface Action {
  id: string
  title: string
  description: string
  impact: string
  actor: "user" | "employer" | "accountant"
  effort: "low" | "medium" | "high"
  timeline: string
  implementation: string
  documentation?: string
}

export type ActionRole = "salary_earner" | "freelancer" | "business_owner" | "employer_hr"

export interface ActionsResult {
  role: ActionRole
  outcome: Module2OutcomeState
  actions: Action[]
  summary: string
  urgency: "low" | "medium" | "high"
}

/**
 * Generate actions for salary earners
 */
function generateSalaryEarnerActions(
  outcome: Module2OutcomeState,
  income: number,
  oldTax: number,
  newTax: number,
  employerFlexibility: string,
): Action[] {
  const actions: Action[] = []

  if (outcome === "UNAFFECTED_AND_COMPLIANT") {
    actions.push(
      {
        id: "salary-1",
        title: "Ensure Timely Tax Filing",
        description: "Submit your annual tax return to FIRS by March 31 deadline.",
        impact: "Avoid penalties and keep compliance status clean",
        actor: "user",
        effort: "low",
        timeline: "By March 31 annually",
        implementation: "Gather documents (payslips, receipts) and file with FIRS online portal",
      },
      {
        id: "salary-2",
        title: "Review PAYE Withholding",
        description: "Verify that your employer is withholding tax correctly each month.",
        impact: "Prevent overpayment or underpayment",
        actor: "user",
        effort: "low",
        timeline: "Quarterly review",
        implementation: "Compare your payslip withholding to calculated tax using this tool",
      },
    )
  }

  if (outcome === "NET_BENEFICIARY") {
    actions.push(
      {
        id: "salary-benefit-1",
        title: "Optimize Your Take-Home",
        description: "Explore additional deduction opportunities to maximize savings.",
        impact: `Save additional naira beyond the ₦${Math.abs(Math.round(newTax - oldTax)).toLocaleString()} you're already saving`,
        actor: "user",
        effort: "medium",
        timeline: "Next quarter",
        implementation: "Consider increasing pension contributions or exploring non-taxable benefits",
      },
      {
        id: "salary-benefit-2",
        title: "Update Budget Expectations",
        description: "Adjust your monthly budget with updated take-home amount.",
        impact: "Better financial planning with accurate numbers",
        actor: "user",
        effort: "low",
        timeline: "Immediately",
        implementation: `Your new monthly take-home: ₦${Math.round(income - newTax) / 12}`,
      },
    )
  }

  if (outcome === "WORSE_OFF_EMPLOYER_CAN_FIX" && employerFlexibility !== "NONE") {
    const requiredIncrease = calculateRequiredGrossIncrease(income, oldTax, newTax, {
      grossAnnualIncome: income,
      incomeType: "salary",
    })

    actions.push(
      {
        id: "salary-negotiate-1",
        title: "Calculate Negotiation Target",
        description: `Request a ₦${Math.round(requiredIncrease).toLocaleString()} annual increase (₦${Math.round(requiredIncrease / 12).toLocaleString()}/month) to neutralize tax impact.`,
        impact: `Restore your take-home to previous level`,
        actor: "user",
        effort: "low",
        timeline: "Immediately",
        implementation: "Use the gross increase calculator in this app",
      },
      {
        id: "salary-negotiate-2",
        title: "HR Meeting Preparation",
        description: "Prepare a proposal to discuss with your HR or manager.",
        impact: "Increase likelihood of approved adjustment",
        actor: "user",
        effort: "medium",
        timeline: "Within 1 week",
        implementation: "Use the HR script generator below to create a professional proposal with specific numbers",
      },
      {
        id: "salary-negotiate-3",
        title: "Alternative Compensation Structure",
        description: "Propose reallocating salary components without increasing gross.",
        impact: "Achieve adjustment without additional cost to employer",
        actor: "employer",
        effort: "medium",
        timeline: "Within 1 month",
        implementation: "Shift basic salary to housing/transport allowances, increase non-taxable benefits",
      },
    )
  }

  if (outcome === "WORSE_OFF_SELF_OPTIMIZATION_POSSIBLE") {
    actions.push(
      {
        id: "salary-optimize-1",
        title: "Increase Pension Contribution",
        description: "Increase your pension contribution to reduce taxable income.",
        impact: `Each ₦100k increase saves ~₦24k in tax`,
        actor: "user",
        effort: "low",
        timeline: "Next month",
        implementation: "Contact your employer to increase monthly pension deduction",
      },
      {
        id: "salary-optimize-2",
        title: "Claim Housing Relief Correctly",
        description: "Ensure you're claiming maximum housing relief (₦500k cap).",
        impact: `Reduce taxable income by up to ₦500,000`,
        actor: "user",
        effort: "low",
        timeline: "Next filing",
        implementation: "Provide rent receipts/lease to HR; claim relief on annual return",
      },
    )
  }

  if (outcome === "OVERPAYING") {
    actions.push(
      {
        id: "salary-overpay-1",
        title: "Review Deduction Accuracy",
        description: "Immediately review all deductions being applied.",
        impact: "Identify and correct overpayment",
        actor: "user",
        effort: "medium",
        timeline: "This week",
        implementation: "Cross-check your payslip components vs. tax calculation",
      },
      {
        id: "salary-overpay-2",
        title: "HR Correction Request",
        description: "Submit written request to HR to correct tax withholding.",
        impact: "Recover overpaid tax in future months",
        actor: "employer",
        effort: "medium",
        timeline: "Within 2 weeks",
        implementation: "Provide HR with corrected tax calculation and evidence",
      },
    )
  }

  return actions
}

/**
 * Generate actions for freelancers/self-employed
 */
function generateFreelancerActions(outcome: Module2OutcomeState, income: number): Action[] {
  const actions: Action[] = []

  actions.push({
    id: "freelance-1",
    title: "Organize Allowable Expenses",
    description: "Compile receipts for: travel, equipment, software subscriptions, professional fees, home office.",
    impact: `Each ₦100k in deductions saves ~₦24k in tax`,
    actor: "user",
    effort: "medium",
    timeline: "Quarterly",
    implementation: "Create a folder system for receipts; use spreadsheet to track",
  })

  actions.push({
    id: "freelance-2",
    title: "Set Aside Quarterly Tax",
    description: "Calculate and set aside ₦X each quarter for estimated tax payments.",
    impact: "Avoid surprise tax bill at year-end",
    actor: "user",
    effort: "low",
    timeline: "Monthly",
    implementation: `Estimated quarterly: ₦${Math.round((income - income * 0.2) * 0.24) / 4}`,
  })

  actions.push({
    id: "freelance-3",
    title: "File Annual Tax Return",
    description: "Submit complete tax return to FIRS by March 31.",
    impact: "Maintain compliance status",
    actor: "user",
    effort: "medium",
    timeline: "By March 31",
    implementation: "Prepare: income statement, expense receipts, bank statements, deduction documentation",
  })

  if (outcome === "NET_BENEFICIARY") {
    actions.push({
      id: "freelance-benefit-1",
      title: "Maximize Deduction Claims",
      description: "Explore additional legitimate business expenses you may have missed.",
      impact: "Further reduce tax liability",
      actor: "user",
      effort: "medium",
      timeline: "Next quarter",
      implementation: "Review FIRS guidance on allowable business deductions",
    })
  }

  if (outcome === "WORSE_OFF_SELF_OPTIMIZATION_POSSIBLE") {
    actions.push({
      id: "freelance-optimize-1",
      title: "Pension Contribution Strategy",
      description: "Establish a pension plan to reduce taxable income each year.",
      impact: `Each ₦100k contribution saves ~₦24k in tax`,
      actor: "user",
      effort: "medium",
      timeline: "Next quarter",
      implementation: "Open retirement savings account; contribute ₦5-10k monthly",
    })
  }

  return actions
}

/**
 * Generate actions for business owners
 */
function generateBusinessOwnerActions(outcome: Module2OutcomeState, turnover: number, assets: number): Action[] {
  const actions: Action[] = []

  if (turnover >= 100000000) {
    actions.push({
      id: "business-1",
      title: "Ensure Mandatory Registration",
      description: `Your turnover (₦${Math.round(turnover).toLocaleString()}) exceeds ₦100M registration threshold.`,
      impact: "Compliance with FIRS and BIR requirements",
      actor: "user",
      effort: "high",
      timeline: "URGENT - Within 30 days if not yet registered",
      implementation: "Contact FIRS for Large Taxpayer Office enrollment and obtain LTIN",
    })
  }

  if (assets >= 250000000) {
    actions.push({
      id: "business-2",
      title: "Regulatory Registration Assessment",
      description: `Asset value (₦${Math.round(assets).toLocaleString()}) may trigger registration.`,
      impact: "Avoid regulatory penalties",
      actor: "user",
      effort: "medium",
      timeline: "Within 60 days",
      implementation: "Consult with tax advisor on sector-specific registration requirements; complete if needed",
    })
  }

  actions.push({
    id: "business-3",
    title: "Maintain Proper Books",
    description: "Implement accounting system to track income and expenses accurately.",
    impact: "Support tax calculations and audit defense",
    actor: "user",
    effort: "high",
    timeline: "Immediately",
    implementation: "Use QuickBooks/Wave or hire bookkeeper; reconcile monthly",
  })

  actions.push({
    id: "business-4",
    title: "Annual Tax Compliance",
    description: "File complete tax return showing income, deductions, and tax liability.",
    impact: "Maintain compliance status",
    actor: "user",
    effort: "medium",
    timeline: "By March 31 annually",
    implementation: "Prepare financial statements, depreciation schedules, employee payroll reports",
  })

  return actions
}

/**
 * Generate actions for HR/employers
 */
function generateEmployerActions(outcome: Module2OutcomeState, employeeCount: number, avgImpact: number): Action[] {
  return [
    {
      id: "employer-1",
      title: "Payroll System Audit",
      description: "Review payroll system to ensure correct PAYE calculation under new rules.",
      impact: "Compliance across entire employee base",
      actor: "employer",
      effort: "high",
      timeline: "Within 2 weeks",
      implementation: "Run test payroll for representative employees; verify against new tax bands",
    },
    {
      id: "employer-2",
      title: "Employee Communication",
      description: `Inform employees of tax impact (avg ${avgImpact > 0 ? "+" : ""}₦${Math.round(avgImpact).toLocaleString()}/employee/year).`,
      impact: "Transparency and morale",
      actor: "employer",
      effort: "low",
      timeline: "Immediate",
      implementation: "Send email + FAQ + host town hall explaining changes and company response",
    },
    {
      id: "employer-3",
      title: "Budget Impact Assessment",
      description: `Calculate total payroll cost impact: ${employeeCount} employees × avg impact.`,
      impact: "Financial planning for salary adjustments",
      actor: "employer",
      effort: "low",
      timeline: "This week",
      implementation: "Use Module 3 HR batch upload to analyze your specific employee data",
    },
  ]
}

/**
 * Main function to generate all actions
 */
export function generateActions(
  role: ActionRole,
  outcome: Module2OutcomeState,
  income: number,
  oldTax?: number,
  newTax?: number,
  extraData?: any,
): ActionsResult {
  let actions: Action[] = []

  switch (role) {
    case "salary_earner":
      actions = generateSalaryEarnerActions(
        outcome,
        income,
        oldTax || 0,
        newTax || 0,
        extraData?.employerFlexibility || "NONE",
      )
      break
    case "freelancer":
      actions = generateFreelancerActions(outcome, income)
      break
    case "business_owner":
      actions = generateBusinessOwnerActions(outcome, extraData?.turnover || 0, extraData?.assets || 0)
      break
    case "employer_hr":
      actions = generateEmployerActions(outcome, extraData?.employeeCount || 1, extraData?.avgImpact || 0)
      break
  }

  // Determine urgency
  let urgency: "low" | "medium" | "high" = "low"
  if (outcome === "OVERPAYING" || outcome === "AT_RISK") urgency = "high"
  if (outcome === "WORSE_OFF_EMPLOYER_CAN_FIX" || outcome === "WORSE_OFF_SELF_OPTIMIZATION_POSSIBLE") urgency = "medium"

  return {
    role,
    outcome,
    actions,
    summary: `${actions.length} actions for ${role.replace(/_/g, " ")}`,
    urgency,
  }
}
