/**
 * Tax Calculator - Wrapper for old and new system calculations
 * Provides simple, predictable interface for both tax systems
 */

import { calculateOldSystemTax, type TaxCalculationInput as OldSystemInput } from "./tax-old"
import { calculateNewSystemTax, type NewSystemTaxInput } from "./tax-new"
import { TaxCalculationInput } from "./tax-old" // Declaration for TaxCalculationInput

/**
 * Calculate tax under the old system
 * @param grossAnnualIncome - Total income before tax
 * @param totalDeductions - Sum of all allowable deductions
 * @returns Annual tax amount
 */
export function calculateOldTax(grossAnnualIncome: number, totalDeductions: number): number {
  const result = calculateOldSystemTax({
    grossAnnualIncome,
    pensionContribution: totalDeductions * 0.15, // Estimate 15% is pension
    rentRelief: totalDeductions * 0.15, // Estimate 15% is rent
    otherDeductions: totalDeductions * 0.7, // Rest distributed
  })
  return Math.round(result.tax)
}

/**
 * Calculate tax under the new system
 * @param taxableIncome - Income after deductions but before tax calculation
 * @param rentAmount - Annual rent amount for rent relief calculation
 * @returns Annual tax amount
 */
export function calculateNewTax(taxableIncome: number, rentAmount: number = 0): number {
  const result = calculateNewSystemTax({
    grossAnnualIncome: taxableIncome,
    incomeType: "salary",
    rentAmount,
    housingStatus: rentAmount > 0 ? "renting" : "other",
  })
  return Math.round(result.tax)
}

export { calculateOldSystemTax, calculateNewSystemTax }
export type { OldSystemInput, NewSystemTaxInput }
