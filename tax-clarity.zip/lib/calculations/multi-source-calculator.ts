import { IncomeSource, TaxCalculationInput, TaxCalculationResult } from "@/lib/types/income"

/**
 * New PIT bands (2024 onwards)
 * Based on the specification provided
 */
const NEW_PIT_BANDS = [
  { min: 0, max: 300000, rate: 0.07 },
  { min: 300000, max: 600000, rate: 0.11 },
  { min: 600000, max: 1100000, rate: 0.15 },
  { min: 1100000, max: 1600000, rate: 0.19 },
  { min: 1600000, max: 3200000, rate: 0.21 },
  { min: 3200000, max: Infinity, rate: 0.24 },
]

/**
 * Old PIT bands for comparison
 */
const OLD_PIT_BANDS = [
  { min: 0, max: 300000, rate: 0.05 },
  { min: 300000, max: 600000, rate: 0.1 },
  { min: 600000, max: 1100000, rate: 0.15 },
  { min: 1100000, max: 1600000, rate: 0.19 },
  { min: 1600000, max: 3200000, rate: 0.21 },
  { min: 3200000, max: Infinity, rate: 0.24 },
]

/**
 * Calculate progressive tax using bands
 */
function calculateProgressiveTax(taxableIncome: number, bands: typeof NEW_PIT_BANDS): number {
  if (taxableIncome <= 0) return 0

  let tax = 0
  let previousMax = 0

  for (const band of bands) {
    if (taxableIncome <= band.min) break

    const incomeInBand = Math.min(taxableIncome, band.max) - band.min
    tax += incomeInBand * band.rate
    previousMax = band.max

    if (taxableIncome <= band.max) break
  }

  return tax
}

/**
 * Calculate rent relief (capped at 20% of rent or ₦500,000, whichever is lower)
 */
function calculateRentRelief(annualRent: number): number {
  const relief = Math.min(annualRent * 0.2, 500000)
  return Math.max(0, relief)
}

/**
 * Old system CRA calculation: max(₦200k, 1% of GAI) + 20% of GAI
 */
function calculateOldCRA(grossAnnualIncome: number): number {
  const base = Math.max(200000, grossAnnualIncome * 0.01)
  const additional = grossAnnualIncome * 0.2
  return base + additional
}

/**
 * Calculate tax for a single income source (new system)
 */
export function calculateSourceTax(source: IncomeSource, globalDeductions: { rent: number; nhf: number; nhis: number; lifeInsurance: number }): { tax: number; taxableIncome: number } {
  let sourceGAI = source.annualAmount
  let deductions = 0

  // Apply pension if it's salary income
  if (source.type === "salary" && source.details?.pension) {
    deductions += source.details.pension.annualAmount
  }

  // Apply business expenses if freelance/business
  if ((source.type === "freelance" || source.type === "business") && source.details?.businessExpenses) {
    deductions += source.details.businessExpenses
  }

  // Rent relief applies globally only once (not per source)
  // NHF, NHIS, Life Insurance also apply globally

  const sourceDeductions = deductions
  const sourceTI = Math.max(0, sourceGAI - sourceDeductions)

  // Calculate tax on this source's taxable income
  const tax = calculateProgressiveTax(sourceTI, NEW_PIT_BANDS)

  return { tax, taxableIncome: sourceTI }
}

/**
 * Calculate total tax for multiple income sources (new system)
 * Each source is calculated independently, results are summed
 */
export function calculateNewSystemMultiSource(input: TaxCalculationInput): TaxCalculationResult {
  let totalGAI = 0
  let totalTaxableIncome = 0
  let totalTax = 0
  const breakdown: TaxCalculationResult["breakdown"] = []

  // Calculate each source independently
  for (const source of input.incomeSources) {
    if (source.annualAmount <= 0) continue

    const { tax, taxableIncome } = calculateSourceTax(source, input.deductions)

    totalGAI += source.annualAmount
    totalTaxableIncome += taxableIncome
    totalTax += tax

    breakdown.push({
      source: source.label,
      amount: source.annualAmount,
      contribution: tax,
    })
  }

  // Apply global deductions (once, not per source)
  const globalDeductions = input.deductions.rent + input.deductions.nhf + input.deductions.nhis + input.deductions.lifeInsurance
  const totalDeductions = globalDeductions + (input.incomeSources.reduce((sum, s) => sum + (s.details?.pension?.annualAmount || 0), 0) || 0)

  const effectiveRate = totalGAI > 0 ? (totalTax / totalGAI) * 100 : 0

  return {
    grossAnnualIncome: totalGAI,
    totalDeductions,
    taxableIncome: totalTaxableIncome,
    tax: totalTax,
    effectiveRate,
    breakdown,
  }
}

/**
 * Calculate tax for old system
 */
export function calculateOldSystemMultiSource(input: TaxCalculationInput): TaxCalculationResult {
  let totalGAI = 0
  let totalTax = 0
  let totalCRA = 0
  const breakdown: TaxCalculationResult["breakdown"] = []

  // Sum all income
  for (const source of input.incomeSources) {
    totalGAI += source.annualAmount
  }

  // Old system: CRA = max(₦200k, 1% of GAI) + 20% of GAI
  totalCRA = calculateOldCRA(totalGAI)

  // Old system: Pension is deductible, but rent is NOT
  const pensionDeductions = input.incomeSources.reduce((sum, s) => sum + (s.details?.pension?.annualAmount || 0), 0) || 0
  const oldSystemDeductions = totalCRA + pensionDeductions

  const taxableIncome = Math.max(0, totalGAI - oldSystemDeductions)

  // Apply old PIT bands
  totalTax = calculateProgressiveTax(taxableIncome, OLD_PIT_BANDS)

  for (const source of input.incomeSources) {
    if (source.annualAmount <= 0) continue
    // Rough proportional allocation for breakdown
    const proportion = source.annualAmount / totalGAI
    breakdown.push({
      source: source.label,
      amount: source.annualAmount,
      contribution: totalTax * proportion,
    })
  }

  const effectiveRate = totalGAI > 0 ? (totalTax / totalGAI) * 100 : 0

  return {
    grossAnnualIncome: totalGAI,
    totalDeductions: oldSystemDeductions,
    taxableIncome,
    tax: totalTax,
    effectiveRate,
    breakdown,
  }
}
