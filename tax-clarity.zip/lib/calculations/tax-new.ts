/**
 * New Nigerian Tax System Calculator (Corrected)
 * Progressive bands with ALL statutory deductions (NPS, NHF, NHIS, Life Assurance)
 *
 * Tax Bands (corrected):
 * ₦0-₦800,000: 0%
 * ₦800,001-₦3,000,000 (next ₦2.2M): 15%
 * ₦3,000,001-₦12,000,000 (next ₦9M): 18%
 * ₦12,000,001-₦25,000,000 (next ₦13M): 21%
 * ₦25,000,001-₦50,000,000 (next ₦25M): 23%
 * Above ₦50,000,000: 25%
 */

export interface NewSystemTaxInput {
  grossAnnualIncome: number
  incomeType: "salary" | "freelance" | "business" | "multiple"
  pensionContribution?: number
  rentAmount?: number
  businessExpenses?: number
  housingStatus?: "homeowner" | "renting" | "other"
  nsfContribution?: number // National Housing Fund
  nhisContribution?: number // National Health Insurance Scheme
  lifeAssurancePremium?: number
}

export interface DeductionBreakdown {
  pensionContribution: number
  nsfContribution: number
  nhisContribution: number
  lifeAssurancePremium: number
  rentRelief: number
  businessExpenses: number
  totalDeductions: number
}

export interface NewSystemTaxResult {
  grossAnnualIncome: number
  deductions: DeductionBreakdown
  taxableIncome: number
  tax: number
  monthlyTax: number
  takeHome: number
  monthlyTakeHome: number
  breakdownByBand: Array<{
    band: string
    rangeStart: number
    rangeEnd: number
    rate: number
    incomeInBand: number
    tax: number
  }>
}

const TAX_BANDS = [
  { rangeStart: 0, rangeEnd: 800000, rate: 0.0, label: "₦0 - ₦800,000" },
  { rangeStart: 800000, rangeEnd: 3000000, rate: 0.15, label: "₦800,001 - ₦3,000,000" },
  { rangeStart: 3000000, rangeEnd: 12000000, rate: 0.18, label: "₦3,000,001 - ₦12,000,000" },
  { rangeStart: 12000000, rangeEnd: 25000000, rate: 0.21, label: "₦12,000,001 - ₦25,000,000" },
  { rangeStart: 25000000, rangeEnd: 50000000, rate: 0.23, label: "₦25,000,001 - ₦50,000,000" },
  { rangeStart: 50000000, rangeEnd: Number.POSITIVE_INFINITY, rate: 0.25, label: "Above ₦50,000,000" },
]

const RENT_RELIEF_CAP = 500000

export function calculateNewSystemTax(input: NewSystemTaxInput): NewSystemTaxResult {
  const {
    grossAnnualIncome,
    incomeType,
    pensionContribution = 0,
    rentAmount = 0,
    businessExpenses = 0,
    housingStatus = "other",
    nsfContribution = 0,
    nhisContribution = 0,
    lifeAssurancePremium = 0,
  } = input

  // National Pension Scheme (NPS): up to 8% of gross
  const pensionDeduction = Math.min(pensionContribution, grossAnnualIncome * 0.08)

  // National Social Housing Fund (NHF): typically 2% of gross
  const nsfDeduction = Math.min(nsfContribution, grossAnnualIncome * 0.02)

  // National Health Insurance Scheme (NHIS): typically 5% of gross
  const nhisDeduction = Math.min(nhisContribution, grossAnnualIncome * 0.05)

  // Life Assurance Premium: deductible up to limit
  const lifeAssuranceDeduction = Math.min(lifeAssurancePremium, grossAnnualIncome * 0.03)

  let rentRelief = 0
  if (housingStatus === "renting" && rentAmount > 0) {
    const rentReliefCalc = Math.min(rentAmount * 0.2, RENT_RELIEF_CAP)
    rentRelief = Math.min(rentReliefCalc, grossAnnualIncome * 0.2) // Max 20% of income
  }

  // Business expenses (for self-employed/freelance)
  let expenses = 0
  if (incomeType === "freelance" || incomeType === "business") {
    expenses = Math.min(businessExpenses, grossAnnualIncome * 0.3) // Max 30%
  }

  const deductions: DeductionBreakdown = {
    pensionContribution: Math.round(pensionDeduction),
    nsfContribution: Math.round(nsfDeduction),
    nhisContribution: Math.round(nhisDeduction),
    lifeAssurancePremium: Math.round(lifeAssuranceDeduction),
    rentRelief: Math.round(rentRelief),
    businessExpenses: Math.round(expenses),
    totalDeductions: Math.round(
      pensionDeduction + nsfDeduction + nhisDeduction + lifeAssuranceDeduction + rentRelief + expenses,
    ),
  }

  const taxableIncome = Math.max(0, grossAnnualIncome - deductions.totalDeductions)

  let tax = 0
  const breakdownByBand = []
  let remainingIncome = taxableIncome

  for (const band of TAX_BANDS) {
    if (remainingIncome <= 0) break

    // Calculate income that falls in this band
    const bandRangeSize = band.rangeEnd - band.rangeStart
    const incomeInBand = Math.min(remainingIncome, bandRangeSize)
    const bandTax = incomeInBand * band.rate

    tax += bandTax

    if (incomeInBand > 0) {
      breakdownByBand.push({
        band: band.label,
        rangeStart: band.rangeStart,
        rangeEnd: band.rangeEnd,
        rate: band.rate * 100,
        incomeInBand: Math.round(incomeInBand),
        tax: Math.round(bandTax),
      })
    }

    remainingIncome -= incomeInBand
  }

  const monthlyTax = tax / 12
  const takeHome = grossAnnualIncome - tax - pensionDeduction - nsfDeduction - nhisDeduction - lifeAssuranceDeduction
  const monthlyTakeHome = takeHome / 12

  return {
    grossAnnualIncome,
    deductions,
    taxableIncome: Math.round(taxableIncome),
    tax: Math.round(tax),
    monthlyTax: Math.round(monthlyTax),
    takeHome: Math.round(takeHome),
    monthlyTakeHome: Math.round(monthlyTakeHome),
    breakdownByBand,
  }
}

export function calculateRequiredGrossIncrease(
  currentIncome: number,
  currentTaxOld: number,
  currentTaxNew: number,
  input: NewSystemTaxInput,
): number {
  const taxDifference = currentTaxNew - currentTaxOld

  if (taxDifference <= 0) return 0

  let low = currentIncome
  let high = currentIncome * 2
  let bestIncrease = 0

  for (let iteration = 0; iteration < 30; iteration++) {
    const mid = (low + high) / 2
    const increase = mid - currentIncome

    const newInput = { ...input, grossAnnualIncome: mid }
    const newCalc = calculateNewSystemTax(newInput)
    const netGainAfterNewTax = increase - (newCalc.tax - currentTaxNew)

    if (Math.abs(netGainAfterNewTax) < 1) {
      bestIncrease = increase
      break
    }

    if (netGainAfterNewTax < 0) {
      low = mid
    } else {
      high = mid
    }

    bestIncrease = increase
  }

  return Math.round(bestIncrease)
}

// Aliases for simplified interface
export const calculateNewTax = calculateNewSystemTax

// Re-export old system function from tax-old.ts
import { calculateOldSystemTax } from './tax-old'
export const calculateOldTax = calculateOldSystemTax
