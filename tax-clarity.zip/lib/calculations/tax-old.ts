/**
 * Old Nigerian Tax System Calculator (Corrected)
 * CRA = Higher of (₦200,000 or 1% of Gross Income) + 20% of Gross Income
 */

export interface TaxCalculationInput {
  grossAnnualIncome: number
  pensionContribution?: number
  rentRelief?: number
  otherDeductions?: number
  nsfContribution?: number
  nhisContribution?: number
  lifeAssurancePremium?: number
}

export interface DeductionBreakdownOld {
  pensionContribution: number
  nsfContribution: number
  nhisContribution: number
  lifeAssurancePremium: number
  rentRelief: number
  consolidatedReliefAllowance: number
  totalDeductions: number
}

export interface TaxCalculationResult {
  grossAnnualIncome: number
  deductions: DeductionBreakdownOld
  taxableIncome: number
  tax: number
  monthlyTax: number
  takeHome: number
  monthlyTakeHome: number
  breakdownByBand: Array<{
    band: string
    rate: number
    income: number
    tax: number
  }>
}

const TAX_BANDS = [
  { min: 0, max: 300000, rate: 0.07 }, // First 300k @ 7%
  { min: 300000, max: 600000, rate: 0.11 }, // Next 300k @ 11%
  { min: 600000, max: 1100000, rate: 0.15 }, // Next 500k @ 15%
  { min: 1100000, max: 1600000, rate: 0.19 }, // Next 500k @ 19%
  { min: 1600000, max: 3200000, rate: 0.21 }, // Next 1.6M @ 21%
  { min: 3200000, max: Number.POSITIVE_INFINITY, rate: 0.24 }, // Above 3.2M @ 24%
]

export function calculateOldSystemTax(input: TaxCalculationInput): TaxCalculationResult {
  const {
    grossAnnualIncome,
    pensionContribution = 0,
    rentRelief = 0,
    otherDeductions = 0,
    nsfContribution = 0,
    nhisContribution = 0,
    lifeAssurancePremium = 0,
  } = input

  const craFixed = 200000
  const craPercentage = grossAnnualIncome * 0.01
  const craBase = Math.max(craFixed, craPercentage)
  const craTotal = craBase + grossAnnualIncome * 0.2

  // Calculate all deductions (same as new system for consistency)
  const pensionDed = Math.min(pensionContribution, grossAnnualIncome * 0.08)
  const nsfDed = Math.min(nsfContribution, grossAnnualIncome * 0.02)
  const nhisDed = Math.min(nhisContribution, grossAnnualIncome * 0.05)
  const lifeAssuranceDed = Math.min(lifeAssurancePremium, grossAnnualIncome * 0.03)

  const deductions: DeductionBreakdownOld = {
    pensionContribution: Math.round(pensionDed),
    nsfContribution: Math.round(nsfDed),
    nhisContribution: Math.round(nhisDed),
    lifeAssurancePremium: Math.round(lifeAssuranceDed),
    rentRelief: Math.round(rentRelief),
    consolidatedReliefAllowance: Math.round(craTotal),
    totalDeductions: Math.round(
      pensionDed + nsfDed + nhisDed + lifeAssuranceDed + rentRelief + craTotal + otherDeductions,
    ),
  }

  const taxableIncome = Math.max(0, grossAnnualIncome - deductions.totalDeductions)

  // Calculate progressive tax using correct bands
  let tax = 0
  const breakdownByBand = []
  let remainingIncome = taxableIncome

  for (const band of TAX_BANDS) {
    if (remainingIncome <= 0) break

    const bandRange = band.max - band.min
    const incomeInBand = Math.min(remainingIncome, bandRange)
    const bandTax = incomeInBand * band.rate

    tax += bandTax

    if (incomeInBand > 0) {
      breakdownByBand.push({
        band: `₦${band.min.toLocaleString()}-${band.max === Number.POSITIVE_INFINITY ? "∞" : "₦" + band.max.toLocaleString()}`,
        rate: band.rate * 100,
        income: Math.round(incomeInBand),
        tax: Math.round(bandTax),
      })
    }

    remainingIncome -= incomeInBand
  }

  const monthlyTax = tax / 12
  const takeHome = grossAnnualIncome - tax - pensionDed - nsfDed - nhisDed - lifeAssuranceDed
  const monthlyTakeHome = takeHome / 12

  return {
    grossAnnualIncome,
    deductions,
    taxableIncome: Math.round(taxableIncome),
    tax: Math.round(tax),
    monthlyTax: Math.round(monthlyTax),
    takeHome: Math.round(takeHome),
    monthlyTakeHome: Math.round(monthlyTakeHome),
    breakdownByBand,
  }
}
