/**
 * Anonymous session management
 * Creates and manages session IDs for tracking calculations without user authentication
 */

import { v4 as uuidv4 } from "uuid"

const SESSION_STORAGE_KEY = "taxclarity_session_id"
const SESSION_DATA_KEY = "taxclarity_session_data"

export interface SessionData {
  sessionId: string
  createdAt: number
  lastAccessedAt: number
  module1?: {
    input: any
    resultData: any
  }
  module2?: {
    input: any
    resultData: any
  }
  module3?: {
    input: any
    resultData: any
  }
  calculations: Array<{
    id: string
    moduleId: number
    timestamp: number
    inputData: any
    resultData: any
  }>
}

/**
 * Get or create an anonymous session ID
 * Stores in localStorage for persistence across sessions
 */
export function getOrCreateSessionId(): string {
  if (typeof window === "undefined") return uuidv4()

  const stored = localStorage.getItem(SESSION_STORAGE_KEY)
  if (stored) return stored

  const newSessionId = uuidv4()
  localStorage.setItem(SESSION_STORAGE_KEY, newSessionId)
  return newSessionId
}

/**
 * Get the current session ID
 */
export function getSessionId(): string | null {
  if (typeof window === "undefined") return null
  return localStorage.getItem(SESSION_STORAGE_KEY)
}

/**
 * Store a calculation result in session
 */
export function saveCalculationToSession(moduleId: number, inputData: any, resultData: any): string {
  const sessionId = getOrCreateSessionId()
  const calcId = uuidv4()

  if (typeof window === "undefined") return calcId

  const stored = localStorage.getItem(SESSION_DATA_KEY)
  const data: SessionData = stored
    ? JSON.parse(stored)
    : {
        sessionId,
        createdAt: Date.now(),
        lastAccessedAt: Date.now(),
        calculations: [],
      }

  data.calculations.push({
    id: calcId,
    moduleId,
    timestamp: Date.now(),
    inputData,
    resultData,
  })

  if (moduleId === 1) {
    data.module1 = { input: inputData, resultData }
  } else if (moduleId === 2) {
    data.module2 = { input: inputData, resultData }
  } else if (moduleId === 3) {
    data.module3 = { input: inputData, resultData }
  }

  data.lastAccessedAt = Date.now()
  localStorage.setItem(SESSION_DATA_KEY, JSON.stringify(data))

  return calcId
}

/**
 * Get calculation history from session
 */
export function getSessionCalculations(): SessionData["calculations"] {
  if (typeof window === "undefined") return []

  const stored = localStorage.getItem(SESSION_DATA_KEY)
  if (!stored) return []

  const data: SessionData = JSON.parse(stored)
  return data.calculations
}

/**
 * Get a specific calculation from session
 */
export function getCalculationFromSession(calcId: string) {
  const calculations = getSessionCalculations()
  return calculations.find((c) => c.id === calcId)
}

/**
 * Get full session data including module results
 */
export function getSessionData(): SessionData | null {
  if (typeof window === "undefined") return null

  const stored = localStorage.getItem(SESSION_DATA_KEY)
  if (!stored) return null

  return JSON.parse(stored) as SessionData
}

/**
 * Clear session data (for testing)
 */
export function clearSession() {
  if (typeof window === "undefined") return
  localStorage.removeItem(SESSION_STORAGE_KEY)
  localStorage.removeItem(SESSION_DATA_KEY)
}
