// Income source types and data structures for multi-source income handling

export type IncomeSourceType = "salary" | "freelance" | "business" | "investment" | "pos"

export interface IncomeSource {
  id: string
  type: IncomeSourceType
  label: string
  annualAmount: number
  details?: {
    pension?: {
      percentage: number
      annualAmount: number
    }
    rentRelief?: {
      annualAmount: number
    }
    businessExpenses?: number
    turnover?: number
    expenses?: number
  }
}

export interface UserSession {
  roles: IncomeSourceType[]
  incomeSources: IncomeSource[]
  deductions: {
    nhf: number
    nhis: number
    lifeInsurance: number
  }
  createdAt: number
  lastUpdated: number
}

export interface TaxCalculationInput {
  grossAnnualIncome: number
  incomeSources: IncomeSource[]
  deductions: {
    rent: number
    pension: number
    nhf: number
    nhis: number
    lifeInsurance: number
    businessExpenses?: number
  }
}

export interface TaxCalculationResult {
  grossAnnualIncome: number
  totalDeductions: number
  taxableIncome: number
  tax: number
  effectiveRate: number
  breakdown: {
    source: string
    amount: number
    contribution: number
  }[]
}
