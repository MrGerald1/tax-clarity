/**
 * Number and currency formatting utilities for Nigerian Naira
 */

export function formatNaira(amount: number): string {
  return new Intl.NumberFormat("en-NG", {
    style: "currency",
    currency: "NGN",
    minimumFractionDigits: 0,
    maximumFractionDigits: 0,
  }).format(amount)
}

export function formatNumber(amount: number): string {
  return new Intl.NumberFormat("en-NG", {
    minimumFractionDigits: 0,
    maximumFractionDigits: 0,
  }).format(amount)
}

export function formatPercent(percent: number, decimals = 1): string {
  return `${percent.toFixed(decimals)}%`
}

export function calculateTaxDelta(newTax: number, oldTax: number): number {
  if (oldTax === 0) return 0
  return ((newTax - oldTax) / oldTax) * 100
}

export function formatTaxDelta(oldTax: number, newTax: number): string {
  const delta = newTax - oldTax
  const deltaPercent = calculateTaxDelta(newTax, oldTax)

  if (delta > 0) {
    return `+${formatNaira(delta)} (+${formatPercent(deltaPercent)})`
  } else if (delta < 0) {
    return `${formatNaira(delta)} (${formatPercent(deltaPercent)})`
  } else {
    return "No change"
  }
}

export function getOutcomeLabel(delta: number): string {
  if (delta < -5) return "Better Off"
  if (delta > 5) return "Worse Off"
  return "Unaffected"
}

export function getOutcomeColor(delta: number): "green" | "red" | "gray" {
  if (delta < -5) return "green"
  if (delta > 5) return "red"
  return "gray"
}

// Alias for backward compatibility
export const formatCurrency = formatNaira
