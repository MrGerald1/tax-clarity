/**
 * Module 1: Tax Responsibility Finder
 * State machine for questionnaire branching logic
 * Determines one of 5 responsibility outcomes
 */

export type TaxResponsibilityState =
  | "NO_TAX_ACTION_REQUIRED"
  | "EMPLOYER_HANDLES_TAX"
  | "MUST_FILE_ANNUALLY"
  | "EXEMPT_BUT_SHOULD_REGISTER"
  | "AT_RISK_OF_NON_COMPLIANCE"

export interface Module1Input {
  hasIncome: boolean
  incomeType?: "salary" | "freelance" | "business" | "foreign" | "multiple" | "none"
  incomeAmount?: number
  incomeStatus?: "below_threshold" | "above_threshold" | "uncertain"
  businessTurnover?: number
  businessAssets?: number
  employmentStatus?: "employed" | "self_employed" | "business_owner" | "multiple" | "none"
}

export interface Module1Result {
  state: TaxResponsibilityState
  explanation: string
  actionRequired: boolean
  proceedToModule2: boolean
  riskLevel: "low" | "medium" | "high"
}

/**
 * Branching logic for tax responsibility determination
 */
export function determineResponsibilityState(input: Module1Input): Module1Result {
  const { hasIncome, incomeType, incomeAmount = 0, businessTurnover = 0, businessAssets = 0, employmentStatus } = input

  // No income = no tax action required
  if (!hasIncome || incomeType === "none") {
    return {
      state: "NO_TAX_ACTION_REQUIRED",
      explanation:
        "Based on your answers, you have no income requiring tax action. However, if your situation changes, come back and check again.",
      actionRequired: false,
      proceedToModule2: false,
      riskLevel: "low",
    }
  }

  // Salary earner with employer
  if (employmentStatus === "employed" && incomeType === "salary") {
    return {
      state: "EMPLOYER_HANDLES_TAX",
      explanation:
        "Your employer is responsible for calculating and remitting your tax through PAYE. However, you may still benefit from understanding the new tax impact.",
      actionRequired: false,
      proceedToModule2: true,
      riskLevel: "low",
    }
  }

  // Below income threshold
  if (incomeAmount > 0 && incomeAmount < 800000 && incomeType !== "business") {
    return {
      state: "NO_TAX_ACTION_REQUIRED",
      explanation:
        "Your annual income is below the ₦800,000 threshold, so you do not currently have filing obligations. Keep monitoring if income changes.",
      actionRequired: false,
      proceedToModule2: false,
      riskLevel: "low",
    }
  }

  // Self-employed / Freelancer above threshold
  if ((employmentStatus === "self_employed" || incomeType === "freelance") && incomeAmount >= 800000) {
    return {
      state: "MUST_FILE_ANNUALLY",
      explanation:
        "As a freelancer or self-employed person with income above ₦800,000, you must file annual tax returns and are subject to quarterly estimated taxes.",
      actionRequired: true,
      proceedToModule2: true,
      riskLevel: "medium",
    }
  }

  // Business owner with high turnover
  if (employmentStatus === "business_owner" || incomeType === "business") {
    if (businessTurnover >= 100000000) {
      return {
        state: "AT_RISK_OF_NON_COMPLIANCE",
        explanation:
          "Your business turnover exceeds ₦100 million, requiring mandatory registration and compliance with tax authorities. This is a high-priority item.",
        actionRequired: true,
        proceedToModule2: true,
        riskLevel: "high",
      }
    }

    if (businessAssets >= 250000000) {
      return {
        state: "EXEMPT_BUT_SHOULD_REGISTER",
        explanation:
          "Your business assets exceed ₦250 million. While you may have exemptions, regulatory registration is strongly advised.",
        actionRequired: true,
        proceedToModule2: true,
        riskLevel: "high",
      }
    }

    if (incomeAmount >= 800000) {
      return {
        state: "MUST_FILE_ANNUALLY",
        explanation:
          "As a business owner with net profit above ₦800,000, you must file annual returns. You may also have registration obligations depending on turnover.",
        actionRequired: true,
        proceedToModule2: true,
        riskLevel: "medium",
      }
    }
  }

  // Foreign income
  if (incomeType === "foreign") {
    return {
      state: "MUST_FILE_ANNUALLY",
      explanation:
        "Foreign income is taxable in Nigeria. You must declare foreign income and file annual returns, though exclusion rules may apply.",
      actionRequired: true,
      proceedToModule2: true,
      riskLevel: "high",
    }
  }

  // Multiple income streams
  if (incomeType === "multiple") {
    const totalIncome = incomeAmount + (businessTurnover > 0 ? businessTurnover * 0.1 : 0)
    if (totalIncome >= 800000) {
      return {
        state: "MUST_FILE_ANNUALLY",
        explanation:
          "With multiple income streams totaling above ₦800,000, you must file consolidated annual returns covering all income sources.",
        actionRequired: true,
        proceedToModule2: true,
        riskLevel: "medium",
      }
    }
  }

  // Default: uncertain, should file
  return {
    state: "MUST_FILE_ANNUALLY",
    explanation:
      "Based on your situation, it is safest to assume you have filing obligations. Module 2 will help clarify the tax impact.",
    actionRequired: true,
    proceedToModule2: true,
    riskLevel: "medium",
  }
}

/**
 * Get the explanation for each outcome state
 */
export function getStateExplanation(state: TaxResponsibilityState): string {
  const explanations: Record<TaxResponsibilityState, string> = {
    NO_TAX_ACTION_REQUIRED: "You have no filing obligations at this time.",
    EMPLOYER_HANDLES_TAX: "Your employer manages tax withholding; your responsibility is limited.",
    MUST_FILE_ANNUALLY: "You are required to file annual tax returns with the FIRS.",
    EXEMPT_BUT_SHOULD_REGISTER: "You may be exempt but should register for compliance.",
    AT_RISK_OF_NON_COMPLIANCE: "Your situation requires immediate compliance action.",
  }
  return explanations[state]
}

/**
 * Get recommendations for each state
 */
export function getStateRecommendations(state: TaxResponsibilityState): string[] {
  const recommendations: Record<TaxResponsibilityState, string[]> = {
    NO_TAX_ACTION_REQUIRED: [
      "Keep records of your income in case your situation changes",
      "Monitor the ₦800,000 threshold for future years",
    ],
    EMPLOYER_HANDLES_TAX: [
      "Review your payslips to understand PAYE deductions",
      "Check that your employer is withholding correctly",
    ],
    MUST_FILE_ANNUALLY: [
      "Gather required documentation (receipts, bank statements)",
      "File by the March 31 annual deadline",
      "Keep quarterly records for estimated tax payments",
    ],
    EXEMPT_BUT_SHOULD_REGISTER: [
      "Contact your state tax authority for registration",
      "Obtain necessary tax IDs and compliance certificates",
      "Maintain filing records even if temporarily exempt",
    ],
    AT_RISK_OF_NON_COMPLIANCE: [
      "Consult with a tax professional immediately",
      "Ensure all required registrations are current",
      "Implement proper bookkeeping and compliance systems",
    ],
  }
  return recommendations[state]
}
