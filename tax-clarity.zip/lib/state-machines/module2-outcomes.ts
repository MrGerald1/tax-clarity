/**
 * Module 2: Tax Impact Comparator
 * Determines outcome state based on delta between old and new tax
 */

export type Module2OutcomeState =
  | "UNAFFECTED_AND_COMPLIANT"
  | "NET_BENEFICIARY"
  | "WORSE_OFF_EMPLOYER_CAN_FIX"
  | "WORSE_OFF_SELF_OPTIMIZATION_POSSIBLE"
  | "OVERPAYING"
  | "AT_RISK"

export interface Module2OutcomeInput {
  oldTax: number
  newTax: number
  income: number
  incomeType: "salary" | "freelance" | "business"
  employerFlexibility?: "NONE" | "PARTIAL" | "FULL"
  hasDeductionOpportunities?: boolean
  hasComplianceRisks?: boolean
}

export interface Module2OutcomeResult {
  state: Module2OutcomeState
  deltaAmount: number
  deltaPercent: number
  explanation: string
  actionRequired: boolean
  urgency: "low" | "medium" | "high"
  suggestedNextStep: string
}

/**
 * Determine module 2 outcome based on tax delta
 */
export function determineModule2Outcome(input: Module2OutcomeInput): Module2OutcomeResult {
  const {
    oldTax,
    newTax,
    income,
    incomeType,
    employerFlexibility = "NONE",
    hasDeductionOpportunities = false,
    hasComplianceRisks = false,
  } = input

  const deltaAmount = newTax - oldTax
  const deltaPercent = income > 0 ? (deltaAmount / income) * 100 : 0

  // Check if paying more than required under either system
  if (oldTax > income * 0.35 || newTax > income * 0.35) {
    return {
      state: "OVERPAYING",
      deltaAmount,
      deltaPercent,
      explanation:
        "Your calculated tax exceeds 35% of income, which suggests potential over-withholding or calculation errors. Review your deductions immediately.",
      actionRequired: true,
      urgency: "high",
      suggestedNextStep: "Module 3: Review deduction optimization options",
    }
  }

  // Material impact + compliance risks
  if (Math.abs(deltaPercent) > 5 && hasComplianceRisks) {
    return {
      state: "AT_RISK",
      deltaAmount,
      deltaPercent,
      explanation:
        "You face both a significant tax impact and potential compliance risks. Urgent professional consultation recommended.",
      actionRequired: true,
      urgency: "high",
      suggestedNextStep: "Module 3: Consult with a tax advisor",
    }
  }

  // Within tolerance range (±5%)
  if (Math.abs(deltaPercent) <= 5) {
    return {
      state: "UNAFFECTED_AND_COMPLIANT",
      deltaAmount,
      deltaPercent,
      explanation:
        "Your tax impact is minimal under the new system. You remain compliant with no urgent changes needed.",
      actionRequired: false,
      urgency: "low",
      suggestedNextStep: "Module 3: Review compliance reminders",
    }
  }

  // Better off (significant benefit)
  if (deltaPercent < -5) {
    return {
      state: "NET_BENEFICIARY",
      deltaAmount,
      deltaPercent,
      explanation: `Great news! You save ${Math.abs(Math.round(deltaAmount)).toLocaleString()} naira annually under the new system. Consider further optimization.`,
      actionRequired: false,
      urgency: "low",
      suggestedNextStep: "Module 3: Explore additional tax optimization",
    }
  }

  // Worse off - employer can help
  if (deltaPercent > 5 && employerFlexibility !== "NONE") {
    return {
      state: "WORSE_OFF_EMPLOYER_CAN_FIX",
      deltaAmount,
      deltaPercent,
      explanation: `You're worse off by ₦${Math.round(deltaAmount).toLocaleString()}, but your employer has flexibility to adjust compensation without increasing gross cost.`,
      actionRequired: true,
      urgency: "medium",
      suggestedNextStep: "Module 3: Generate employer negotiation proposal",
    }
  }

  // Worse off - self-optimization possible
  if (deltaPercent > 5 && hasDeductionOpportunities) {
    return {
      state: "WORSE_OFF_SELF_OPTIMIZATION_POSSIBLE",
      deltaAmount,
      deltaPercent,
      explanation: `You're worse off by ₦${Math.round(deltaAmount).toLocaleString()}, but deduction optimization could reduce the impact.`,
      actionRequired: true,
      urgency: "medium",
      suggestedNextStep: "Module 3: Optimize deductions and structure",
    }
  }

  // Worse off - no clear path
  return {
    state: "WORSE_OFF_SELF_OPTIMIZATION_POSSIBLE",
    deltaAmount,
    deltaPercent,
    explanation: `You're worse off by ₦${Math.round(deltaAmount).toLocaleString()} under the new system. Explore optimization options in Module 3.`,
    actionRequired: true,
    urgency: "medium",
    suggestedNextStep: "Module 3: Review all available options",
  }
}

/**
 * Get detailed explanation for each outcome
 */
export function getOutcomeExplanation(state: Module2OutcomeState): string {
  const explanations: Record<Module2OutcomeState, string> = {
    UNAFFECTED_AND_COMPLIANT: "Your tax situation remains largely unchanged; continue with current compliance.",
    NET_BENEFICIARY: "You benefit financially from the new tax system; optimize further if possible.",
    WORSE_OFF_EMPLOYER_CAN_FIX: "Your employer can adjust compensation to offset the impact.",
    WORSE_OFF_SELF_OPTIMIZATION_POSSIBLE:
      "You can reduce the impact through deduction optimization or income restructuring.",
    OVERPAYING: "Your tax burden exceeds safe thresholds; investigate immediately.",
    AT_RISK: "You face both financial impact and compliance risks.",
  }
  return explanations[state]
}
