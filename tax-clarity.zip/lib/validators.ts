/**
 * Input validation utilities for tax calculations
 */

export interface ValidationResult {
  valid: boolean
  error?: string
}

export function validateIncome(income: number): ValidationResult {
  if (income < 0) {
    return { valid: false, error: "Income cannot be negative" }
  }
  if (income > 1000000000) {
    return { valid: false, error: "Income exceeds maximum limit" }
  }
  return { valid: true }
}

export function validatePensionContribution(contribution: number, income: number): ValidationResult {
  if (contribution < 0) {
    return { valid: false, error: "Pension contribution cannot be negative" }
  }
  if (contribution > income * 0.1) {
    return { valid: false, error: "Pension contribution cannot exceed 10% of income" }
  }
  return { valid: true }
}

export function validateRentAmount(rent: number): ValidationResult {
  if (rent < 0) {
    return { valid: false, error: "Rent cannot be negative" }
  }
  return { valid: true }
}

export function validateIncomeThreshold(income: number, threshold: number): ValidationResult {
  if (income < 0) {
    return { valid: false, error: "Income cannot be negative" }
  }
  return { valid: true }
}

export function validateBusinessTurnover(turnover: number): ValidationResult {
  if (turnover < 0) {
    return { valid: false, error: "Business turnover cannot be negative" }
  }
  return { valid: true }
}
