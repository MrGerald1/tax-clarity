import Link from "next/link"

export function Footer() {
  return (
    <footer className="bg-background border-t border-border py-12 mt-20">
      <div className="container max-w-6xl mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
          {/* Brand */}
          <div>
            <div className="flex items-center gap-2 mb-4">
              <div className="w-8 h-8 rounded-full bg-primary flex items-center justify-center">
                <span className="text-primary-foreground text-xs font-bold">TC</span>
              </div>
              <span className="font-semibold">TaxClarity NG</span>
            </div>
            <p className="text-sm text-muted-foreground">
              Free tax clarity for Nigerians. Understand how the new tax law affects you.
            </p>
          </div>

          {/* Product */}
          <div>
            <h4 className="font-semibold mb-4 text-foreground">Product</h4>
            <ul className="space-y-2 text-sm">
              <li>
                <Link href="/am-i-taxed" className="text-muted-foreground hover:text-foreground transition-colors">
                  Tax Exposure
                </Link>
              </li>
              <li>
                <Link href="/compare-tax" className="text-muted-foreground hover:text-foreground transition-colors">
                  Tax Impact
                </Link>
              </li>
              <li>
                <Link href="/optimize-income" className="text-muted-foreground hover:text-foreground transition-colors">
                  Tax Optimization
                </Link>
              </li>
            </ul>
          </div>

          {/* Resources */}
          <div>
            <h4 className="font-semibold mb-4 text-foreground">Resources</h4>
            <ul className="space-y-2 text-sm">
              <li>
                <a href="#" className="text-muted-foreground hover:text-foreground transition-colors">
                  Tax Guide
                </a>
              </li>
              <li>
                <a href="#" className="text-muted-foreground hover:text-foreground transition-colors">
                  Blog
                </a>
              </li>
              <li>
                <a href="#" className="text-muted-foreground hover:text-foreground transition-colors">
                  Contact
                </a>
              </li>
            </ul>
          </div>

          {/* Legal */}
          <div>
            <h4 className="font-semibold mb-4 text-foreground">Legal</h4>
            <ul className="space-y-2 text-sm">
              <li>
                <a href="#" className="text-muted-foreground hover:text-foreground transition-colors">
                  Privacy Policy
                </a>
              </li>
              <li>
                <a href="#" className="text-muted-foreground hover:text-foreground transition-colors">
                  Terms of Service
                </a>
              </li>
              <li>
                <a href="#" className="text-muted-foreground hover:text-foreground transition-colors">
                  Disclaimer
                </a>
              </li>
            </ul>
          </div>
        </div>

        {/* Bottom */}
        <div className="border-t border-border pt-8 flex flex-col md:flex-row justify-between items-center gap-4 text-sm text-muted-foreground">
          <p>© 2026 TaxClarity NG. Educational tool, not professional tax advice.</p>
          <p>Built with clarity in mind. For Nigerians, by Nigerians.</p>
        </div>
      </div>
    </footer>
  )
}
