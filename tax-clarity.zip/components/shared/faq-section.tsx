"use client"

import { useState } from "react"
import { Card } from "@/components/ui/card"
import { ChevronDown } from "lucide-react"

const faqs = [
  {
    question: "Is this tool accurate?",
    answer:
      "Yes. Our calculations are verified against the official FIRS tax bands and rules. However, this is an educational tool, not professional tax advice. For complex situations, consult a tax advisor.",
  },
  {
    question: "Do I need to sign up or pay?",
    answer:
      "No. TaxClarity NG is completely free and requires no signup. All three modules are open access. Just click and start exploring.",
  },
  {
    question: "What happens to my data?",
    answer:
      "Your data is stored securely in your browser session only. We do not collect or store any personal information unless you explicitly share results. Your privacy is paramount.",
  },
  {
    question: "Can I share my results?",
    answer:
      "Yes! Each result generates a shareable link. You can send it via WhatsApp, email, or copy the link. People who click will see your scenario and be prompted to run their own.",
  },
  {
    question: "When do I need to file taxes?",
    answer:
      "If Module 1 determines you must file annually, the deadline is March 31 each year. Estimated quarterly taxes may also be due. Check with FIRS for deadlines.",
  },
  {
    question: "What if I disagree with the result?",
    answer:
      "Results are based on current FIRS rules and your inputs. Double-check your income and deductions are accurate. If still unclear, consult a professional tax advisor for guidance.",
  },
]

export function FAQSection() {
  const [openIndex, setOpenIndex] = useState<number | null>(null)

  return (
    <div className="space-y-3">
      <h3 className="text-lg font-semibold mb-4">Frequently Asked Questions</h3>
      {faqs.map((faq, idx) => (
        <Card key={idx} className="bg-card overflow-hidden">
          <button
            onClick={() => setOpenIndex(openIndex === idx ? null : idx)}
            className="w-full text-left p-4 hover:bg-muted/50 transition-colors flex items-center justify-between"
          >
            <h4 className="font-semibold">{faq.question}</h4>
            <ChevronDown
              className={`w-5 h-5 text-muted-foreground transition-transform ${openIndex === idx ? "rotate-180" : ""}`}
            />
          </button>
          {openIndex === idx && (
            <div className="border-t border-border px-4 py-3 bg-muted/30">
              <p className="text-foreground text-sm">{faq.answer}</p>
            </div>
          )}
        </Card>
      ))}
    </div>
  )
}
