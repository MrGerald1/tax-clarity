"use client"

import { Card } from "@/components/ui/card"
import { ChevronDown, ChevronUp } from "lucide-react"
import { useState } from "react"

interface TaxBreakdownDetailsProps {
  oldTaxBreakdown: any
  newTaxBreakdown: any
}

export function TaxBreakdownDetails({ oldTaxBreakdown, newTaxBreakdown }: TaxBreakdownDetailsProps) {
  const [expanded, setExpanded] = useState(false)

  const formatNaira = (value: number) => {
    return `₦${value.toLocaleString()}`
  }

  return (
    <div className="mt-8">
      <Card
        className="p-6 bg-muted/30 border-muted cursor-pointer hover:bg-muted/50 transition-colors"
        onClick={() => setExpanded(!expanded)}
      >
        <div className="flex items-center justify-between">
          <h3 className="text-lg font-semibold text-foreground">Detailed Tax Breakdown</h3>
          {expanded ? (
            <ChevronUp className="w-5 h-5 text-muted-foreground" />
          ) : (
            <ChevronDown className="w-5 h-5 text-muted-foreground" />
          )}
        </div>

        {expanded && (
          <div className="mt-6 space-y-8">
            {/* Old Tax System */}
            <div className="border-b border-border pb-6 last:border-b-0">
              <h4 className="text-base font-semibold mb-4 text-foreground">Old Tax System Breakdown</h4>

              {/* Income Breakdown */}
              <div className="bg-background rounded p-4 mb-4">
                <p className="text-xs font-semibold text-muted-foreground mb-3 uppercase">Income & Deductions</p>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Gross Annual Income</span>
                    <span className="font-medium text-foreground">
                      {formatNaira(oldTaxBreakdown.grossAnnualIncome)}
                    </span>
                  </div>
                  <div className="border-t border-border pt-2 mt-2">
                    {oldTaxBreakdown.deductions.pensionContribution > 0 && (
                      <div className="flex justify-between py-1">
                        <span className="text-muted-foreground">Pension (NPS)</span>
                        <span className="text-red-600">
                          -{formatNaira(oldTaxBreakdown.deductions.pensionContribution)}
                        </span>
                      </div>
                    )}
                    {oldTaxBreakdown.deductions.nsfContribution > 0 && (
                      <div className="flex justify-between py-1">
                        <span className="text-muted-foreground">National Housing Fund (NHF)</span>
                        <span className="text-red-600">-{formatNaira(oldTaxBreakdown.deductions.nsfContribution)}</span>
                      </div>
                    )}
                    {oldTaxBreakdown.deductions.nhisContribution > 0 && (
                      <div className="flex justify-between py-1">
                        <span className="text-muted-foreground">Health Insurance (NHIS)</span>
                        <span className="text-red-600">
                          -{formatNaira(oldTaxBreakdown.deductions.nhisContribution)}
                        </span>
                      </div>
                    )}
                    {oldTaxBreakdown.deductions.lifeAssurancePremium > 0 && (
                      <div className="flex justify-between py-1">
                        <span className="text-muted-foreground">Life Assurance Premium</span>
                        <span className="text-red-600">
                          -{formatNaira(oldTaxBreakdown.deductions.lifeAssurancePremium)}
                        </span>
                      </div>
                    )}
                    {oldTaxBreakdown.deductions.rentRelief > 0 && (
                      <div className="flex justify-between py-1">
                        <span className="text-muted-foreground">Rent Relief</span>
                        <span className="text-red-600">-{formatNaira(oldTaxBreakdown.deductions.rentRelief)}</span>
                      </div>
                    )}
                    <div className="flex justify-between py-1 border-t border-border/50 mt-1 pt-1">
                      <span className="text-muted-foreground">Consolidated Relief Allowance (CRA)</span>
                      <span className="text-red-600">
                        -{formatNaira(oldTaxBreakdown.deductions.consolidatedReliefAllowance)}
                      </span>
                    </div>
                  </div>
                  <div className="flex justify-between py-2 font-semibold border-t border-border pt-2 mt-2">
                    <span>Taxable Income</span>
                    <span className="text-foreground">{formatNaira(oldTaxBreakdown.taxableIncome)}</span>
                  </div>
                </div>
              </div>

              {/* Tax Brackets */}
              {oldTaxBreakdown.breakdownByBand && oldTaxBreakdown.breakdownByBand.length > 0 && (
                <div className="bg-background rounded p-4">
                  <p className="text-xs font-semibold text-muted-foreground mb-3 uppercase">Tax Brackets Applied</p>
                  <div className="space-y-2 text-sm">
                    {oldTaxBreakdown.breakdownByBand.map((band: any, idx: number) => (
                      <div key={idx} className="flex justify-between">
                        <span className="text-muted-foreground">
                          {band.band} @ {band.rate}%
                        </span>
                        <div className="text-right">
                          <div className="text-xs text-muted-foreground">{formatNaira(band.income)}</div>
                          <div className="font-medium text-foreground">{formatNaira(band.tax)}</div>
                        </div>
                      </div>
                    ))}
                    <div className="flex justify-between pt-2 border-t border-border mt-2 font-semibold">
                      <span>Total Tax</span>
                      <span className="text-foreground">{formatNaira(oldTaxBreakdown.tax)}</span>
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* New Tax System */}
            <div>
              <h4 className="text-base font-semibold mb-4 text-primary">New Tax System Breakdown</h4>

              {/* Income Breakdown */}
              <div className="bg-background rounded p-4 mb-4">
                <p className="text-xs font-semibold text-muted-foreground mb-3 uppercase">Income & Deductions</p>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Gross Annual Income</span>
                    <span className="font-medium text-foreground">
                      {formatNaira(newTaxBreakdown.grossAnnualIncome)}
                    </span>
                  </div>
                  <div className="border-t border-border pt-2 mt-2">
                    {newTaxBreakdown.deductions.pensionContribution > 0 && (
                      <div className="flex justify-between py-1">
                        <span className="text-muted-foreground">Pension (NPS)</span>
                        <span className="text-red-600">
                          -{formatNaira(newTaxBreakdown.deductions.pensionContribution)}
                        </span>
                      </div>
                    )}
                    {newTaxBreakdown.deductions.nsfContribution > 0 && (
                      <div className="flex justify-between py-1">
                        <span className="text-muted-foreground">National Housing Fund (NHF)</span>
                        <span className="text-red-600">-{formatNaira(newTaxBreakdown.deductions.nsfContribution)}</span>
                      </div>
                    )}
                    {newTaxBreakdown.deductions.nhisContribution > 0 && (
                      <div className="flex justify-between py-1">
                        <span className="text-muted-foreground">Health Insurance (NHIS)</span>
                        <span className="text-red-600">
                          -{formatNaira(newTaxBreakdown.deductions.nhisContribution)}
                        </span>
                      </div>
                    )}
                    {newTaxBreakdown.deductions.lifeAssurancePremium > 0 && (
                      <div className="flex justify-between py-1">
                        <span className="text-muted-foreground">Life Assurance Premium</span>
                        <span className="text-red-600">
                          -{formatNaira(newTaxBreakdown.deductions.lifeAssurancePremium)}
                        </span>
                      </div>
                    )}
                    {newTaxBreakdown.deductions.rentRelief > 0 && (
                      <div className="flex justify-between py-1">
                        <span className="text-muted-foreground">Rent Relief (capped ₦500k)</span>
                        <span className="text-red-600">-{formatNaira(newTaxBreakdown.deductions.rentRelief)}</span>
                      </div>
                    )}
                    {newTaxBreakdown.deductions.businessExpenses > 0 && (
                      <div className="flex justify-between py-1">
                        <span className="text-muted-foreground">Business Expenses</span>
                        <span className="text-red-600">
                          -{formatNaira(newTaxBreakdown.deductions.businessExpenses)}
                        </span>
                      </div>
                    )}
                  </div>
                  <div className="flex justify-between py-2 font-semibold border-t border-border pt-2 mt-2">
                    <span>Taxable Income</span>
                    <span className="text-foreground">{formatNaira(newTaxBreakdown.taxableIncome)}</span>
                  </div>
                </div>
              </div>

              {/* Tax Brackets */}
              {newTaxBreakdown.breakdownByBand && newTaxBreakdown.breakdownByBand.length > 0 && (
                <div className="bg-background rounded p-4">
                  <p className="text-xs font-semibold text-muted-foreground mb-3 uppercase">Tax Brackets Applied</p>
                  <div className="space-y-2 text-sm">
                    {newTaxBreakdown.breakdownByBand.map((band: any, idx: number) => (
                      <div key={idx} className="flex justify-between">
                        <span className="text-muted-foreground">
                          {band.band} @ {band.rate}%
                        </span>
                        <div className="text-right">
                          <div className="text-xs text-muted-foreground">{formatNaira(band.incomeInBand)}</div>
                          <div className="font-medium text-foreground">{formatNaira(band.tax)}</div>
                        </div>
                      </div>
                    ))}
                    <div className="flex justify-between pt-2 border-t border-border mt-2 font-semibold">
                      <span>Total Tax</span>
                      <span className="text-foreground">{formatNaira(newTaxBreakdown.tax)}</span>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
        )}
      </Card>
    </div>
  )
}
