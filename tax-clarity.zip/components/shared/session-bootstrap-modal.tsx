"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { AlertCircle } from "lucide-react"

interface SessionBootstrapModalProps {
  onComplete: (data: { grossAnnualIncome: number; roles: string[] }) => void
  title?: string
  description?: string
}

export function SessionBootstrapModal({
  onComplete,
  title = "We need your information to continue",
  description = "Let's gather some basic details so we can help you understand your tax situation.",
}: SessionBootstrapModalProps) {
  const [income, setIncome] = useState("")
  const [roles, setRoles] = useState<string[]>([])
  const [error, setError] = useState("")

  const handleRoleToggle = (role: string) => {
    setRoles((prev) => (prev.includes(role) ? prev.filter((r) => r !== role) : [...prev, role]))
  }

  const handleSubmit = () => {
    setError("")

    if (!income || parseFloat(income) <= 0) {
      setError("Please enter a valid gross annual income")
      return
    }

    if (roles.length === 0) {
      setError("Please select at least one income source")
      return
    }

    onComplete({
      grossAnnualIncome: parseFloat(income),
      roles,
    })
  }

  const roleOptions = [
    { value: "salary", label: "Salary/Employment" },
    { value: "freelance", label: "Freelance/Contract" },
    { value: "business", label: "Business" },
    { value: "pos", label: "POS Agent" },
    { value: "investment", label: "Investment" },
  ]

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
      <Card className="w-full max-w-2xl p-8">
        <div className="mb-6">
          <h2 className="text-2xl font-bold text-foreground mb-2">{title}</h2>
          <p className="text-muted-foreground">{description}</p>
        </div>

        {error && (
          <Alert className="mb-6 border-destructive bg-destructive/10">
            <AlertCircle className="h-4 w-4 text-destructive" />
            <AlertDescription className="text-destructive">{error}</AlertDescription>
          </Alert>
        )}

        <div className="space-y-6">
          {/* Income Input */}
          <div>
            <label className="block text-sm font-medium text-foreground mb-3">Gross Annual Income (₦)</label>
            <input
              type="number"
              value={income}
              onChange={(e) => setIncome(e.target.value)}
              placeholder="Enter your total gross annual income"
              className="w-full px-4 py-3 rounded-lg border border-border bg-card text-foreground placeholder-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary"
              step="1000"
            />
            <p className="text-xs text-muted-foreground mt-2">
              This is your total income before tax and deductions (salary, freelance, business, etc.)
            </p>
          </div>

          {/* Role Selection */}
          <div>
            <label className="block text-sm font-medium text-foreground mb-3">Income Sources (Select all that apply)</label>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {roleOptions.map((option) => (
                <button
                  key={option.value}
                  onClick={() => handleRoleToggle(option.value)}
                  className={`p-3 rounded-lg border-2 transition-all text-left ${
                    roles.includes(option.value)
                      ? "border-primary bg-primary/5"
                      : "border-border hover:border-primary/50 bg-card"
                  }`}
                >
                  <p className="font-medium text-foreground">{option.label}</p>
                </button>
              ))}
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex gap-3 pt-4">
            <Button onClick={handleSubmit} size="lg" className="flex-1">
              Continue
            </Button>
          </div>
        </div>
      </Card>
    </div>
  )
}
