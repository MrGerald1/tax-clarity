"use client"

import { useState } from "react"
import { IncomeSource, IncomeSourceType } from "@/lib/types/income"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { formatNaira } from "@/lib/formatters"
import { X, Plus, ChevronDown } from "lucide-react"

interface MultiSourceIncomeInputProps {
  selectedRoles: IncomeSourceType[]
  incomeSources: IncomeSource[]
  onSourcesChange: (sources: IncomeSource[]) => void
}

const ROLE_LABELS: Record<IncomeSourceType, string> = {
  salary: "Salary from Employer",
  freelance: "Freelance/Contract Work",
  business: "Business Ownership",
  investment: "Investment Income",
  pos: "POS Commission",
}

export function MultiSourceIncomeInput({
  selectedRoles,
  incomeSources,
  onSourcesChange,
}: MultiSourceIncomeInputProps) {
  const [expandedSource, setExpandedSource] = useState<string | null>(null)

  // Initialize sources for selected roles if missing
  const sources = selectedRoles.map((role) => {
    const existing = incomeSources.find((s) => s.type === role)
    if (existing) return existing

    return {
      id: `${role}-${Date.now()}`,
      type: role,
      label: ROLE_LABELS[role],
      annualAmount: 0,
      details: {},
    } as IncomeSource
  })

  const handleAmountChange = (id: string, amount: number) => {
    const updated = sources.map((s) => (s.id === id ? { ...s, annualAmount: amount } : s))
    onSourcesChange(updated)
  }

  const handlePensionChange = (id: string, percentage: number) => {
    const updated = sources.map((s) => {
      if (s.id !== id) return s
      const amount = (s.annualAmount * percentage) / 100
      return {
        ...s,
        details: {
          ...s.details,
          pension: { percentage, annualAmount: Math.round(amount) },
        },
      }
    })
    onSourcesChange(updated)
  }

  const handleRemoveSource = (id: string) => {
    const updated = sources.filter((s) => s.id !== id)
    onSourcesChange(updated)
  }

  const totalIncome = sources.reduce((sum, s) => sum + s.annualAmount, 0)

  return (
    <div className="space-y-6">
      {/* Income Source Cards */}
      <div className="space-y-4">
        {sources.map((source) => (
          <Card key={source.id} className="p-6 border border-border">
            <div className="flex items-start justify-between mb-4">
              <div>
                <h3 className="font-semibold text-foreground">{source.label}</h3>
                <p className="text-sm text-muted-foreground">Annual gross income</p>
              </div>
              {selectedRoles.length > 1 && (
                <button
                  onClick={() => handleRemoveSource(source.id)}
                  className="text-muted-foreground hover:text-destructive transition-colors"
                  aria-label={`Remove ${source.label}`}
                >
                  <X className="w-5 h-5" />
                </button>
              )}
            </div>

            {/* Amount Input */}
            <div className="mb-4">
              <label className="block text-sm font-medium text-foreground mb-2">₦ Annual Amount</label>
              <input
                type="number"
                value={source.annualAmount}
                onChange={(e) => handleAmountChange(source.id, parseFloat(e.target.value) || 0)}
                placeholder="0"
                className="w-full px-4 py-3 rounded-lg border border-border bg-card text-foreground placeholder-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary"
                step="1000"
              />
              {source.annualAmount > 0 && (
                <p className="text-xs text-muted-foreground mt-1">{formatNaira(source.annualAmount)}</p>
              )}
            </div>

            {/* Role-specific details */}
            {source.type === "salary" && (
              <div>
                <button
                  onClick={() => setExpandedSource(expandedSource === source.id ? null : source.id)}
                  className="flex items-center gap-2 text-sm font-medium text-primary hover:text-primary/80 transition-colors"
                >
                  <ChevronDown
                    className={`w-4 h-4 transition-transform ${expandedSource === source.id ? "rotate-180" : ""}`}
                  />
                  Salary Details
                </button>

                {expandedSource === source.id && (
                  <div className="mt-4 space-y-4 pt-4 border-t border-border">
                    <div>
                      <label className="block text-sm font-medium text-foreground mb-2">Pension Contribution %</label>
                      <div className="flex gap-3">
                        <input
                          type="range"
                          min="0"
                          max="30"
                          step="0.5"
                          value={source.details?.pension?.percentage || 8}
                          onChange={(e) => handlePensionChange(source.id, parseFloat(e.target.value))}
                          className="flex-1"
                        />
                        <input
                          type="number"
                          value={source.details?.pension?.percentage || 8}
                          onChange={(e) => handlePensionChange(source.id, parseFloat(e.target.value) || 0)}
                          min="0"
                          max="30"
                          step="0.5"
                          className="w-16 px-2 py-1 text-sm border border-border rounded bg-card text-foreground"
                        />
                        <span className="text-sm text-muted-foreground self-center">%</span>
                      </div>
                      {source.details?.pension && (
                        <p className="text-xs text-muted-foreground mt-2">
                          Annual: {formatNaira(source.details.pension.annualAmount)}
                        </p>
                      )}
                    </div>
                  </div>
                )}
              </div>
            )}

            {source.type === "freelance" && (
              <div>
                <button
                  onClick={() => setExpandedSource(expandedSource === source.id ? null : source.id)}
                  className="flex items-center gap-2 text-sm font-medium text-primary hover:text-primary/80 transition-colors"
                >
                  <ChevronDown
                    className={`w-4 h-4 transition-transform ${expandedSource === source.id ? "rotate-180" : ""}`}
                  />
                  Business Expenses
                </button>

                {expandedSource === source.id && (
                  <div className="mt-4 pt-4 border-t border-border">
                    <label className="block text-sm font-medium text-foreground mb-2">Allowable Expenses</label>
                    <input
                      type="number"
                      value={source.details?.businessExpenses || 0}
                      onChange={(e) => {
                        const updated = sources.map((s) =>
                          s.id === source.id
                            ? {
                                ...s,
                                details: { ...s.details, businessExpenses: parseFloat(e.target.value) || 0 },
                              }
                            : s
                        )
                        onSourcesChange(updated)
                      }}
                      placeholder="0"
                      className="w-full px-4 py-2 text-sm border border-border rounded bg-card text-foreground"
                    />
                    <p className="text-xs text-muted-foreground mt-1">Equipment, internet, office supplies, etc.</p>
                  </div>
                )}
              </div>
            )}

            {source.type === "business" && (
              <div>
                <button
                  onClick={() => setExpandedSource(expandedSource === source.id ? null : source.id)}
                  className="flex items-center gap-2 text-sm font-medium text-primary hover:text-primary/80 transition-colors"
                >
                  <ChevronDown
                    className={`w-4 h-4 transition-transform ${expandedSource === source.id ? "rotate-180" : ""}`}
                  />
                  Business Details
                </button>

                {expandedSource === source.id && (
                  <div className="mt-4 space-y-4 pt-4 border-t border-border">
                    <div>
                      <label className="block text-sm font-medium text-foreground mb-2">Total Turnover</label>
                      <input
                        type="number"
                        value={source.details?.turnover || 0}
                        onChange={(e) => {
                          const updated = sources.map((s) =>
                            s.id === source.id
                              ? { ...s, details: { ...s.details, turnover: parseFloat(e.target.value) || 0 } }
                              : s
                          )
                          onSourcesChange(updated)
                        }}
                        placeholder="0"
                        className="w-full px-4 py-2 text-sm border border-border rounded bg-card text-foreground"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-foreground mb-2">Allowable Expenses</label>
                      <input
                        type="number"
                        value={source.details?.expenses || 0}
                        onChange={(e) => {
                          const updated = sources.map((s) =>
                            s.id === source.id ? { ...s, details: { ...s.details, expenses: parseFloat(e.target.value) || 0 } } : s
                          )
                          onSourcesChange(updated)
                        }}
                        placeholder="0"
                        className="w-full px-4 py-2 text-sm border border-border rounded bg-card text-foreground"
                      />
                    </div>
                  </div>
                )}
              </div>
            )}
          </Card>
        ))}
      </div>

      {/* Total Income Summary */}
      <Card className="p-6 bg-secondary/5 border border-secondary/20">
        <p className="text-sm text-muted-foreground mb-1">Total Gross Annual Income</p>
        <p className="text-3xl font-bold text-foreground">{formatNaira(totalIncome)}</p>
      </Card>
    </div>
  )
}
