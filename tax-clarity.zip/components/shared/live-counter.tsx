"use client"

import { useState, useEffect } from "react"
import { Activity } from "lucide-react"

export function LiveCounter() {
  const [count, setCount] = useState(2847)

  useEffect(() => {
    // Simulate real-time updates
    const interval = setInterval(() => {
      setCount((prev) => prev + Math.floor(Math.random() * 3))
    }, 5000)

    return () => clearInterval(interval)
  }, [])

  return (
    <div className="flex items-center gap-2 px-4 py-2 rounded-full bg-secondary/10 border border-secondary/20 w-fit mx-auto">
      <Activity className="w-4 h-4 text-secondary animate-pulse" />
      <span className="text-sm text-muted-foreground">
        <span className="font-semibold text-foreground">{count.toLocaleString()}</span> scenarios analyzed today
      </span>
    </div>
  )
}
