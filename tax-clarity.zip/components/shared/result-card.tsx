import type React from "react"
import { Card } from "@/components/ui/card"
import { CheckCircle2, AlertCircle } from "lucide-react"

interface ResultCardProps {
  title: string
  description: string
  value?: string | number
  icon?: "check" | "alert"
  color?: "green" | "blue" | "yellow" | "red"
  children?: React.ReactNode
}

const colorClasses = {
  green: "bg-green-50 dark:bg-green-950 border-green-200 dark:border-green-800",
  blue: "bg-blue-50 dark:bg-blue-950 border-blue-200 dark:border-blue-800",
  yellow: "bg-yellow-50 dark:bg-yellow-950 border-yellow-200 dark:border-yellow-800",
  red: "bg-red-50 dark:bg-red-950 border-red-200 dark:border-red-800",
}

const iconClasses = {
  green: "text-green-600",
  blue: "text-blue-600",
  yellow: "text-yellow-600",
  red: "text-red-600",
}

export function ResultCard({ title, description, value, icon = "check", color = "blue", children }: ResultCardProps) {
  return (
    <Card className={`p-6 border-2 ${colorClasses[color]}`}>
      <div className="flex items-start gap-4">
        <div className={iconClasses[color]}>
          {icon === "check" ? <CheckCircle2 className="w-6 h-6" /> : <AlertCircle className="w-6 h-6" />}
        </div>
        <div className="flex-1">
          <h3 className="font-semibold text-lg mb-1">{title}</h3>
          <p className="text-muted-foreground text-sm mb-3">{description}</p>
          {value && <p className="text-2xl font-bold text-foreground">{value}</p>}
          {children}
        </div>
      </div>
    </Card>
  )
}
