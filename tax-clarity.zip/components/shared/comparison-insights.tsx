"use client"

import { Card } from "@/components/ui/card"
import { TrendingDown, TrendingUp, Minus } from "lucide-react"

interface Insight {
  title: string
  value: string
  trend: "positive" | "negative" | "neutral"
  color: "green" | "red" | "gray"
}

const insights: Insight[] = [
  {
    title: "Average tax change for ₦2-3M earners",
    value: "-₦180,000",
    trend: "positive",
    color: "green",
  },
  {
    title: "Salary earners seeing a benefit",
    value: "62%",
    trend: "positive",
    color: "green",
  },
  {
    title: "Freelancers paying more",
    value: "38%",
    trend: "negative",
    color: "red",
  },
  {
    title: "Most common outcome",
    value: "Unaffected",
    trend: "neutral",
    color: "gray",
  },
]

export function ComparisonInsights() {
  return (
    <div>
      <h3 className="text-lg font-semibold mb-4">What Others Found</h3>
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {insights.map((insight, idx) => (
          <Card key={idx} className="p-4 bg-card">
            <div className="flex items-start gap-2 mb-2">
              {insight.trend === "positive" && <TrendingDown className="w-4 h-4 text-green-600" />}
              {insight.trend === "negative" && <TrendingUp className="w-4 h-4 text-red-600" />}
              {insight.trend === "neutral" && <Minus className="w-4 h-4 text-gray-600" />}
            </div>
            <p className="text-xs text-muted-foreground mb-1 line-clamp-2">{insight.title}</p>
            <p
              className={`text-lg font-bold ${insight.color === "green" ? "text-green-600" : insight.color === "red" ? "text-red-600" : "text-gray-600"}`}
            >
              {insight.value}
            </p>
          </Card>
        ))}
      </div>
    </div>
  )
}
