"use client"

import Link from "next/link"
import { Button } from "@/components/ui/button"

export function Navbar() {
  return (
    <nav className="sticky top-0 z-50 w-full border-b border-border bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="max-w-7xl mx-auto flex h-16 items-center justify-between px-4 sm:px-6">
        {/* Logo */}
        <Link href="/" className="flex items-center gap-2 font-bold text-base sm:text-lg flex-shrink-0">
          <div className="w-8 h-8 rounded-lg bg-primary flex items-center justify-center">
            <span className="text-primary-foreground text-xs font-bold">TC</span>
          </div>
          <span className="hidden sm:inline text-foreground">TaxClarity</span>
        </Link>

        {/* Navigation */}
        <div className="flex items-center gap-1 sm:gap-2">
          <Link href="/">
            <Button variant="ghost" size="sm" className="text-xs sm:text-sm h-9 px-2 sm:px-3">
              Home
            </Button>
          </Link>
          <Link href="/tax-impact">
            <Button variant="ghost" size="sm" className="text-xs sm:text-sm h-9 px-2 sm:px-3">
              Tax Impact
            </Button>
          </Link>
          <Link href="/tax-optimization">
            <Button variant="ghost" size="sm" className="text-xs sm:text-sm h-9 px-2 sm:px-3">
              Optimize
            </Button>
          </Link>
          <Link href="/tax-guide">
            <Button variant="ghost" size="sm" className="text-xs sm:text-sm h-9 px-2 sm:px-3">
              Guide
            </Button>
          </Link>
        </div>
      </div>
    </nav>
  )
}
