"use client"

import { Button } from "@/components/ui/button"
import { Share2, MessageCircle, Mail, Copy, Check } from "lucide-react"
import { useState } from "react"
import { formatNaira } from "@/lib/formatters"

interface ShareButtonsProps {
  title?: string
  text: string
  url?: string
  resultAmount?: number
  isBetterOff?: boolean
}

export function ShareButtons({
  title = "My Tax Impact",
  text,
  url = "",
  resultAmount,
  isBetterOff,
}: ShareButtonsProps) {
  const [copied, setCopied] = useState(false)
  const [shareStatus, setShareStatus] = useState<string | null>(null)

  const shareUrl = url || (typeof window !== "undefined" ? window.location.href : "")
  const fullShareText = resultAmount
    ? `${text} ${isBetterOff ? `I save ${formatNaira(Math.abs(resultAmount))}` : `I pay ${formatNaira(Math.abs(resultAmount))} more`}. Check yours: ${shareUrl}`
    : `${text} ${shareUrl}`

  const handleWhatsApp = () => {
    const encoded = encodeURIComponent(fullShareText)
    window.open(`https://wa.me/?text=${encoded}`, "_blank")
  }

  const handleTwitter = () => {
    const encoded = encodeURIComponent(`${text}\n\n${shareUrl}`)
    window.open(`https://twitter.com/intent/tweet?text=${encoded}`, "_blank")
  }

  const handleEmail = () => {
    const subject = encodeURIComponent(title)
    const body = encodeURIComponent(fullShareText)
    window.open(`mailto:?subject=${subject}&body=${body}`, "_blank")
  }

  const handleCopyLink = () => {
    navigator.clipboard.writeText(shareUrl)
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  const handleNativeShare = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: title,
          text: fullShareText,
          url: shareUrl,
        })
      } catch (error: any) {
        if (error.name !== "AbortError") {
          setShareStatus("Use the buttons below to share")
          setTimeout(() => setShareStatus(null), 3000)
        }
      }
    } else {
      handleCopyLink()
      setShareStatus("Link copied! Share from your app.")
      setTimeout(() => setShareStatus(null), 2000)
    }
  }

  return (
    <div className="space-y-4">
      {shareStatus && (
        <div className="p-3 bg-blue-50 dark:bg-blue-950 border border-blue-200 dark:border-blue-800 rounded-lg text-sm text-blue-700 dark:text-blue-300">
          {shareStatus}
        </div>
      )}
      <div className="flex flex-wrap gap-2">
        <Button
          variant="outline"
          size="sm"
          onClick={handleWhatsApp}
          className="gap-2 bg-transparent"
          title="Share on WhatsApp"
        >
          <MessageCircle className="w-4 h-4" />
          WhatsApp
        </Button>

        <Button
          variant="outline"
          size="sm"
          onClick={handleTwitter}
          className="gap-2 bg-transparent"
          title="Share on Twitter"
        >
          <Share2 className="w-4 h-4" />
          Twitter
        </Button>

        <Button
          variant="outline"
          size="sm"
          onClick={handleEmail}
          className="gap-2 bg-transparent"
          title="Share via Email"
        >
          <Mail className="w-4 h-4" />
          Email
        </Button>

        <Button
          variant="outline"
          size="sm"
          onClick={handleCopyLink}
          className="gap-2 bg-transparent"
          title="Copy link to clipboard"
        >
          {copied ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
          {copied ? "Copied!" : "Copy Link"}
        </Button>
      </div>
    </div>
  )
}
