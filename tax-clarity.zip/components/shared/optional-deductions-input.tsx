"use client"

import { useState } from "react"
import { formatNaira } from "@/lib/formatters"

interface DeductionOption {
  id: string
  label: string
  description: string
  value: number
}

interface OptionalDeductionsInputProps {
  deductions: Record<string, { enabled: boolean; amount: number }>
  onDeductionsChange: (deductions: Record<string, { enabled: boolean; amount: number }>) => void
  options?: {
    id: string
    label: string
    description: string
  }[]
}

const DEFAULT_DEDUCTIONS = [
  {
    id: "nhf",
    label: "National Housing Fund (NHF)",
    description: "Mandatory 2.5% contribution to help with housing",
  },
  {
    id: "nhis",
    label: "National Health Insurance Scheme (NHIS)",
    description: "Health insurance contribution",
  },
  {
    id: "lifeInsurance",
    label: "Life Assurance Premiums",
    description: "Life insurance policy premiums",
  },
  {
    id: "rentRelief",
    label: "Rent Relief",
    description: "Deductible rent (capped at 20% or ₦500,000)",
  },
]

export function OptionalDeductionsInput({
  deductions,
  onDeductionsChange,
  options = DEFAULT_DEDUCTIONS,
}: OptionalDeductionsInputProps) {
  const handleToggle = (id: string) => {
    const current = deductions[id] || { enabled: false, amount: 0 }
    onDeductionsChange({
      ...deductions,
      [id]: { ...current, enabled: !current.enabled },
    })
  }

  const handleAmountChange = (id: string, amount: number) => {
    const current = deductions[id] || { enabled: true, amount: 0 }
    onDeductionsChange({
      ...deductions,
      [id]: { ...current, amount: Math.max(0, amount) },
    })
  }

  const totalDeductions = Object.values(deductions).reduce((sum, d) => (d.enabled ? sum + d.amount : sum), 0)

  return (
    <div className="space-y-4">
      {options.map((option) => {
        const current = deductions[option.id] || { enabled: false, amount: 0 }

        return (
          <div key={option.id} className="border border-border rounded-lg p-4">
            <div className="flex items-start gap-3 mb-3">
              <label className="flex items-center cursor-pointer">
                <input
                  type="checkbox"
                  checked={current.enabled}
                  onChange={() => handleToggle(option.id)}
                  className="w-4 h-4 rounded border-border cursor-pointer"
                  aria-label={`Enable ${option.label}`}
                />
                <span className="ml-3">
                  <p className="font-medium text-foreground text-sm">{option.label}</p>
                  <p className="text-xs text-muted-foreground">{option.description}</p>
                </span>
              </label>
            </div>

            {current.enabled && (
              <div className="ml-7">
                <label className="block text-xs font-medium text-foreground mb-2">Amount (₦)</label>
                <input
                  type="number"
                  value={current.amount}
                  onChange={(e) => handleAmountChange(option.id, parseFloat(e.target.value) || 0)}
                  placeholder="0"
                  className="w-full px-3 py-2 text-sm border border-border rounded bg-card text-foreground placeholder-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary"
                  step="1000"
                  min="0"
                />
                {current.amount > 0 && (
                  <p className="text-xs text-muted-foreground mt-1">{formatNaira(current.amount)}</p>
                )}
              </div>
            )}
          </div>
        )
      })}

      {/* Total */}
      {totalDeductions > 0 && (
        <div className="bg-muted/30 rounded-lg p-4 mt-6">
          <p className="text-sm text-muted-foreground mb-1">Total Deductions</p>
          <p className="text-2xl font-bold text-foreground">{formatNaira(totalDeductions)}</p>
        </div>
      )}
    </div>
  )
}
